/**
 * @file City Decoration support
 * @copyright 2022, Firaxis Games
 * @description City Decoration support for interface modes (city-selected, city-production, city-growth, city-info)
 */
import { ComponentID } from '/core/ui/utilities/utilities-component-id.js';
export var CityDecorationSupport;
(function (CityDecorationSupport) {
    // TODO: Pull from assets/engine so there is an opportunity to get color correct values (HDR, colorblind, etc...)
    let HighlightColors;
    (function (HighlightColors) {
        HighlightColors[HighlightColors["citySelection"] = 2155199716] = "citySelection"; //8075BCE4
        HighlightColors[HighlightColors["urbanSelection"] = 2160041082] = "urbanSelection"; //80BF9C7A
        HighlightColors[HighlightColors["ruralSelection"] = 2152576268] = "ruralSelection"; //804DB50C
		HighlightColors[HighlightColors["citySelectionEdge"] = 4284453573] = "citySelectionEdge"; //FF5F92C5
        HighlightColors[HighlightColors["urbanSelectionEdge"] = 4288247637] = "urbanSelectionEdge"; //FF997755
        HighlightColors[HighlightColors["ruralSelectionEdge"] = 4281894412] = "ruralSelectionEdge"; //FF38860C
    })(HighlightColors = CityDecorationSupport.HighlightColors || (CityDecorationSupport.HighlightColors = {}));
    class Instance {
        constructor() {
			this.BUILD_SLOT_SPRITE_PADDING = 12;
            this.cityOverlayGroup = null;
            this.cityOverlay = null;
			this.cityOverlaySpriteGrid = null;
            this.beforeUnloadListener = () => { this.onUnload(); };
        }
        initializeOverlay() {
            this.cityOverlayGroup = WorldUI.createOverlayGroup("CityOverlayGroup", 1);
            this.cityOverlay = this.cityOverlayGroup.addPlotOverlay();
			this.cityOverlaySpriteGrid = WorldUI.createSpriteGrid("CityOverlay_SpriteGroup", true);
			this.cityOverlaySpriteGrid.setVisible(true);
            engine.on('BeforeUnload', this.beforeUnloadListener);
        }
        decoratePlots(cityID) {
            this.cityOverlayGroup?.clearAll();
			this.cityOverlaySpriteGrid?.clear();
            const city = Cities.get(cityID);
            if (!city) {
                console.error(`City Decoration support: Failed to find city (${ComponentID.toLogString(cityID)})!`);
                return;
            }
            this.cityOverlay?.addPlots(city.location, { fillColor: HighlightColors.citySelection, edgeColor: HighlightColors.citySelectionEdge });
			const d = Districts.getAtLocation(city.location);
			if (d) {
				this.realizeBuildSlots(d);
			} 
            const cityDistricts = city.Districts;
            if (cityDistricts) {
                // Highlight the rural districts
                const districtIdsRural = cityDistricts.getIdsOfType(DistrictTypes.RURAL);
                if (districtIdsRural.length > 0) {
                    const locations = Districts.getLocations(districtIdsRural);
                    if (locations.length > 0) {
                        this.cityOverlay?.addPlots(locations, { fillColor: HighlightColors.ruralSelection, edgeColor: HighlightColors.ruralSelectionEdge });
						
						for (let i = 0; i < locations.length; i++) {
							const district = Districts.getAtLocation(locations[i]);
							if (district) {
								this.realizeBuildSlots(district);
							}
						}
                    }
                }
                // Highlight the urban districts
                const districtIdsUrban = cityDistricts.getIdsOfType(DistrictTypes.URBAN);
                if (districtIdsUrban.length > 0) {
                    const locations = Districts.getLocations(districtIdsUrban);
                    if (locations.length > 0) {
                        this.cityOverlay?.addPlots(locations, { fillColor: HighlightColors.urbanSelection, edgeColor: HighlightColors.urbanSelectionEdge });
						
						for (let i = 0; i < locations.length; i++) {
							const district = Districts.getAtLocation(locations[i]);
							if (district) {
								this.realizeBuildSlots(district);
							}
						}
                    }
                }
            }
        }
		realizeBuildSlots(district) {
        const districtDefinition = GameInfo.Districts.lookup(district.type);
        if (!districtDefinition) {
            console.error("building-placement-layer: Unable to retrieve a valid DistrictDefinition with DistrictType: " + district.type);
            return;
        }
        const constructibles = MapConstructibles.getConstructibles(district.location.x, district.location.y);
        const buildingSlots = [];
        for (let i = 0; i < constructibles.length; i++) {
            const constructibleID = constructibles[i];
            const existingConstructible = Constructibles.getByComponentID(constructibleID);
            if (!existingConstructible) {
                console.error("building-placement-layer: Unable to find a valid Constructible with ComponentID: " + ComponentID.toLogString(constructibleID));
                continue;
            }
            const constructibleDefinition = GameInfo.Constructibles.lookup(existingConstructible.type);
            if (!constructibleDefinition) {
                console.error("building-placement-layer: Unable to find a valid ConstructibleDefinition with type: " + existingConstructible.type);
                continue;
            }
            //TODO: add completion turns to in progress buildings once asset is implemented
            //TODO: add replaceable once asset is implemented
            const iconString = UI.getIconBLP(constructibleDefinition.ConstructibleType);
            buildingSlots.push({ iconURL: iconString ? iconString : "" });
        }
        for (let i = 0; i < districtDefinition.MaxConstructibles; i++) {
            const groupWidth = (districtDefinition.MaxConstructibles - 1) * this.BUILD_SLOT_SPRITE_PADDING;
            const xPos = (i * this.BUILD_SLOT_SPRITE_PADDING) + (groupWidth / 2) - groupWidth;
            this.cityOverlaySpriteGrid.addSprite(district.location, UI.getIconBLP('BUILDING_UNFILLED'), { x: xPos, y: -28, z: 0 });
            if (buildingSlots[i]) {
                this.cityOverlaySpriteGrid.addSprite(district.location, buildingSlots[i].iconURL, { x: xPos, y: -27.5, z: 0 }, { scale: 0.7 });
            }
        }
    }
        onUnload() {
            this.clearDecorations();
        }
        clearDecorations() {
            this.cityOverlayGroup?.clearAll();
			this.cityOverlaySpriteGrid?.clear();
			this.cityOverlaySpriteGrid.setVisible(true);
        }
    }
    CityDecorationSupport.manager = new Instance();
})(CityDecorationSupport || (CityDecorationSupport = {}));

//# sourceMappingURL=file:///base-standard/ui/interface-modes/support-city-decoration.js.map
