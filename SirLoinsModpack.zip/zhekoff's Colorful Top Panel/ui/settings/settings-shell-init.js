import { colorfulTopPanelSettings } from 'fs://game/colorful-top-panel/ui/settings/settings.js';

// Export the settings to the global scope
window.ctpSettings = {
    ctpSettings: colorfulTopPanelSettings
};
