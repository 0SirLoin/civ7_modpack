import config from '../../mod.config.json' with { type: 'json' }
import { ModConfig } from '../../utils/modinfo/types'

export default config as ModConfig
