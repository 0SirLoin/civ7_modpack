/**
 * Decorate the tech civic complete screen per https://forums.civfanatics.com/threads/additive-ui-elements.695406/
 */
// force import of the screen so we can update its control styles
import '/base-standard/ui/tech-civic-complete/screen-tech-civic-complete.js';

import { WonderTrackerInstance } from '/claimed-wonders-notation/code/wonder-tracker.js';

export class TechWonder_ScreenTechCivicCompleteDecorator {
    constructor(val) {
        this._item = val;
    }

    beforeAttach() {
    }

    afterAttach() {
        let unlocks = this._item.unlockedItemsContainer.children;
        for (let item of unlocks)
        {
            let src = item.style.backgroundImage;
            if (WonderTrackerInstance.IsCompletedIconUrl(src))
            {
                item.classList.add('completed-wonder-icon');
            }
        }
    }

    beforeDetach() { }

    afterDetach() { }

    onAttributeChanged(name, prev, next) { }
}

Controls.decorate('screen-tech-civic-complete', (val) => new TechWonder_ScreenTechCivicCompleteDecorator(val));

if (!Controls.getDefinition('screen-tech-civic-complete').hasOwnProperty('styles'))
{
    Controls.getDefinition('screen-tech-civic-complete').styles = [];
}
Controls.getDefinition('screen-tech-civic-complete').styles.push("fs://game/claimed-wonders-notation/data/wonder-icon.css");