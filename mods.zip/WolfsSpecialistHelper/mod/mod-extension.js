import WolfsSpecialistTooltipModExport from "/mod/wolfs-specialist-tooltip-mod.js";

class ModExtensionClass {

    constructor() {
        this.actions = {};
    }

    registerMods() {
        WolfsSpecialistTooltipModExport.registerMod();
    }

    registerAction(type, action) {
        if (!this.actions[type]) {
            this.actions[type] = [];
        }
        this.actions[type].push(action);
    }

    invokeAction(type, instance) {
        const actionList = this.actions[type];
        if (actionList) {
            actionList.forEach(action => action(instance));
        }
    }
}

const ModExtension = new ModExtensionClass();
ModExtension.registerMods();
export {ModExtension as default};