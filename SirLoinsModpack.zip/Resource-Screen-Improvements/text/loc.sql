INSERT OR REPLACE INTO LocalizedText
    (Tag,	Language,	Text)
VALUES
    ('LOC_TRADE_LENS_SORT_BY_RESOURCE',		'en_US',	'Search'),
    ('LOC_TRADE_LENS_SORT_BY_YIELD',		'en_US',	'Yield '),
    ('LOC_TRADE_LENS_SORT_DEFAULT',		'en_US',	'Count '),
    ('LOC_TRADE_LENS_SORT_BY_LEADER',		'en_US',	'Leader'),
    ('LOC_TRADE_LENS_DESCRIPTION_ALT',		'en_US',	'Create a Trade Route with:'),
    ('LOC_TRADE_LENS_DESCRIPTION',		'en_US',	'Possible Trade Routes:'),
    ('LOC_SLTH_TRADE_TICKBOX',		'en_US',	'Prioritise Eligible'),
    ('LOC_TRADE_LENS_TITLE', 'en_US', 'Trade Routes')
    ;