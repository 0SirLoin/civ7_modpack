--=============================================================================================================
-- Stylish Text (Font Icons)
-- By: Pokiehl
--=============================================================================================================
-- Age
-- To avoid catching words that include "age" in them, let's make these replacements for specific phrases
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "per Age", "per [icon:NOTIFICATION_AGE_TRANSITION] Age")
WHERE   Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "each Age", "each [icon:NOTIFICATION_AGE_TRANSITION] Age")
WHERE   Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "every Age", "every [icon:NOTIFICATION_AGE_TRANSITION] Age")
WHERE   Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "all Ages", "all [icon:NOTIFICATION_AGE_TRANSITION] Ages")
WHERE   Language = 'en_US';

UPDATE 	LocalizedText -- accommodate typo for Ada's UA
SET 	Text = replace(Text, "each age", "each [icon:NOTIFICATION_AGE_TRANSITION] Age")
WHERE   Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Alliance
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Alliance", "[icon:NOTIFICATION_DIPLOMATIC_RESPONSE_REQUIRED] Alliance")
WHERE   Text NOT LIKE	'%[icon:NOTIFICATION_DIPLOMATIC_RESPONSE_REQUIRED]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Attributes
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Attribute", "[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Attribute")
WHERE	Text NOT LIKE 	'%[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL]%'
/*AND		Text NOT LIKE	'%Wildcard Attribute%'
AND		Text NOT LIKE	'%Wildcard Point%'
AND		Text NOT LIKE	'%Cultural Attribute%'
AND		Text NOT LIKE	'%Cultural Point%'
AND		Text NOT LIKE	'%Diplomatic Attribute%'
AND		Text NOT LIKE	'%Diplomatic Point%'
AND		Text NOT LIKE	'%Economic Attribute%'
AND		Text NOT LIKE	'%Economic Point%'
AND		Text NOT LIKE	'%Expansionist Attribute%'
AND		Text NOT LIKE	'%Expansionist Point%'
AND		Text NOT LIKE	'%Militaristic Attribute%'
AND		Text NOT LIKE	'%Militaristic Point%'
AND		Text NOT LIKE	'%Scientific Attribute%'
AND		Text NOT LIKE	'%Scientific Point%'*/
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Capital
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Capital", "[icon:NOTIFICATION_CAPITAL_RECLAIMED] Capital")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_CAPITAL_RECLAIMED]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Celebration
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Celebration", "[icon:NOTIFICATION_GOVT_HAPPINESS] Celebration")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_GOVT_HAPPINESS]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Civics
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Civic", "[icon:NOTIFICATION_CHOOSE_CULTURE_NODE] Civic")
WHERE  	Text NOT LIKE	'%[icon:NOTIFICATION_CULTURE_TREE_REVEALED]%'
AND		Text NOT LIKE	'%[icon:NOTIFICATION_CHOOSE_CULTURE_NODE]%' 
AND		Text NOT LIKE	'%[icon:NOTIFICATION_FREE_CIVIC_AWARDED]%' 
AND		Text NOT LIKE	'%[icon:NOTIFICATION_CIVIC_BOOST_AWARDED]%' 
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Combat Strength
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Combat Strength", "[icon:NOTIFICATION_UNIT_ATTACKED] Combat Strength")
WHERE   Text NOT LIKE	'%[icon:NOTIFICATION_UNIT_ATTACKED]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Commanders
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Commander", "[icon:NOTIFICATION_COMMANDER_RESPAWNED] Commander")
WHERE	Text NOT LIKE '%[NOTIFICATION_COMMANDER_RESPAWNED%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND   	Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "Army [icon:NOTIFICATION_COMMANDER_RESPAWNED] Commander", "[icon:NOTIFICATION_COMMANDER_RESPAWNED] Army Commander")
WHERE   Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "Fleet [icon:NOTIFICATION_COMMANDER_RESPAWNED] Commander", "[icon:NOTIFICATION_COMMANDER_RESPAWNED] Fleet Commander")
WHERE   Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "Aircraft [icon:NOTIFICATION_COMMANDER_RESPAWNED] Commander", "[icon:NOTIFICATION_COMMANDER_RESPAWNED] Aircraft Commander")
WHERE   Language = 'en_US';

-- Levels
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Level", "[icon:NOTIFICATION_UNIT_PROMOTION_AVAILABLE] Level")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_UNIT_PROMOTION_AVAILABLE]%'
AND     Tag NOT LIKE 'LOC_PROFILE%' 											-- "level" is used in the meta-progression system
AND     Tag NOT LIKE 'LOC_METAPROGRESSION_CHALLENGE_MEMENTO_UNLOCKED_TEXT%'	-- "level" is used in the meta-progression system
AND     Tag NOT LIKE 'LOC_CREATE_GAME%'										-- "level" is used in the meta-progression system
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND   Language = 'en_US';

-- Frederich edge case
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Merit Commendation", "[icon:NOTIFICATION_UNIT_PROMOTION_AVAILABLE] Merit Commendation")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_UNIT_PROMOTION_AVAILABLE]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Diplomatic Actions
---------------------------------------------------------------------------------------------------------------
-- Diplomatic Action
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Diplomatic Action", "[icon:NOTIFICATION_DIPLOMACY_SESSION] Diplomatic Action")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_DIPLOMACY_SESSION]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND   	Language = 'en_US';

-- Endeavor
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Endeavor", "[icon:NOTIFICATION_DIPLOMATIC_ACTION_AWARD] Endeavor")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_DIPLOMATIC_ACTION_AWARD]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND   	Language = 'en_US';

-- Espionage
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Espionage", "[icon:NOTIFICATION_DIPLOMATIC_ACTION_ESPIONAGE] Espionage")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_DIPLOMATIC_ACTION_ESPIONAGE]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND   	Language = 'en_US';

-- Sanction
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Sanction", "[icon:NOTIFICATION_DIPLOMATIC_ACTION_LOW] Sanction")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_DIPLOMATIC_ACTION_LOW]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Distant Lands
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Distant Land", "[icon:NOTIFICATION_DISCOVER_CONTINENT] Distant Land")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_DISCOVER_CONTINENT]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Government
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Government", "[icon:NOTIFICATION_CHOOSE_GOVERNMENT] Government")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_CHOOSE_GOVERNMENT]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Great Works
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Great Work", "[icon:NOTIFICATION_GREAT_WORK_CREATED] Great Work")
WHERE   Text NOT LIKE	'%[icon:NOTIFICATION_GREAT_WORK_CREATED]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Growth
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Growth", "[icon:YIELD_FOOD] Growth")
WHERE	(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Narrative Events
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Narrative Event", "[icon:NOTIFICATION_CHOOSE_NARRATIVE_STORY_DIRECTION] Narrative Event")
WHERE   Text NOT LIKE	'%[icon:NOTIFICATION_CHOOSE_NARRATIVE_STORY_DIRECTION]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Natural Wonders
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Natural Wonder", "[icon:NOTIFICATION_DISCOVER_NATURAL_WONDER] Natural Wonder")
WHERE   Text NOT LIKE	'%[icon:NOTIFICATION_DISCOVER_NATURAL_WONDER]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Pantheon
---------------------------------------------------------------------------------------------------------------
-- Avoid updating the main UI text for this
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Pantheon", "[icon:NOTIFICATION_CHOOSE_BELIEF] Pantheon")
WHERE 	Tag NOT LIKE 	'%LOC_BELIEF_CLASS_PANTHEON_NAME%'
AND		Text NOT LIKE	'%[icon:NOTIFICATION_CHOOSE_BELIEF]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Population: TBD
---------------------------------------------------------------------------------------------------------------
--UPDATE 	LocalizedText
--SET 	Text = replace(Text, "Population", "[]Population")
--WHERE   Text NOT LIKE	'%[%'
--WHERE    Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Resources
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Resource", "[icon:NOTIFICATION_DISCOVER_RESOURCE] Resource")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_DISCOVER_RESOURCE]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Settlement (TBD)
---------------------------------------------------------------------------------------------------------------
--UPDATE 	LocalizedText
--SET 	Text = replace(Text, "Settlement", "[] Settlement")
--WHERE   Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Specialist
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Specialist", "[icon:NOTIFICATION_CHOOSE_TOWN_PROJECT] Specialist")
WHERE   Text NOT LIKE	'%[icon:NOTIFICATION_CHOOSE_TOWN_PROJECT]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Techs
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Technology", "[icon:NOTIFICATION_CHOOSE_TECH] Technology")
WHERE  	Text NOT LIKE	'%[icon:NOTIFICATION_TECH_DISCOVERED]%' 
AND 	Text NOT LIKE 	'%[icon:NOTIFICATION_TECH_BOOST_AWARDED]%'
AND 	Text NOT LIKE 	'%[icon:NOTIFICATION_FREE_TECH_AWARDED]%'
AND 	Text NOT LIKE 	'%[icon:NOTIFICATION_CHOOSE_TECH]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Traditions
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Tradition", "[icon:NOTIFICATION_TRADITIONS_AVAILABLE] Tradition")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_TRADITIONS_AVAILABLE]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Trade Routes
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Trade Route", "[icon:NOTIFICATION_TRADE_RESOURCES_GAINED] Trade Route")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_TRADE_ROUTE_TO_YOU]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- War
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Formal War", "[icon:NOTIFICATION_DECLARE_WAR] Formal War")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_DECLARE_WAR]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';

-- War Support
UPDATE 	LocalizedText
SET 	Text = replace(Text, "War Support", "[icon:NOTIFICATION_DECLARE_WAR] War Support")
WHERE	Text NOT LIKE '%[icon:NOTIFICATION_DECLARE_WAR]%'
AND		(Tag LIKE '%DESCRIPTION%'								
OR		Tag LIKE '%REWARD%'
OR		Tag LIKE '%TOOLTIP%')
AND    	Language = 'en_US';
