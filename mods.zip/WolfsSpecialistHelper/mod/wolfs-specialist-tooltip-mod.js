/**
 * Wolf's Specialist Tooltip Mod
 * @copyright 2025, Wolf
 * @description Adds Specialist information to Plot Tooltips
 */
import PlotWorkersManager from '/base-standard/ui/plot-workers/plot-workers-manager.js';
import ModExtension from '/mod/mod-extension.js';

class WolfsSpecialistTooltipMod {
    constructor() {
        this.container = undefined;
    }

    registerMod() {
        ModExtension.registerAction("plot-tooltip-yields-flexbox", this.addPlotSpecialistInformation.bind(this));
    }

    addPlotSpecialistInformation(plotTooltip) {
        this.container = plotTooltip.container;
        const location = plotTooltip.plotCoord;
        const playerID = GameContext.localPlayerID;

        let totalYields = 0
        GameInfo.Yields.forEach(yield_define => {
            const yield_amount = GameplayMap.getYield(location.x, location.y, yield_define.YieldType, playerID);
            if (yield_amount > 0) {
                totalYields += yield_amount
            }
        });
        const info = PlotWorkersManager.allWorkerPlots.find((element) => {
            return element.PlotIndex == GameplayMap.getIndexFromLocation(location);
        });
        if (!info) {
            return;
        }
        let totalYieldChanges = 0;
        info.NextYields.forEach((yieldNum, i) => {
            const netYieldChange = Math.round((yieldNum - info.CurrentYields[i]) * 10) / 10;
            if (netYieldChange != 0) {
                totalYieldChanges += netYieldChange;
            }
        });

        const owningCityId = GameplayMap.getOwningCityFromXY(location.x, location.y);
        if (!owningCityId) {
            return;
        }
        const researchThreshold = 40
        const city = Cities.get(owningCityId);
        const cityWorkers = city.Workers;
        const cityWorkerCap = cityWorkers.getCityWorkerCap();
        const numWorkers = info.NumWorkers;
        const totalYieldsAfterChanges = totalYieldChanges + totalYields;
        let specialistInfoText;
        const workersNeeded = Math.ceil((researchThreshold - totalYields) / totalYieldChanges);
        if (totalYieldsAfterChanges >= researchThreshold && numWorkers < cityWorkerCap) {
            if (totalYieldsAfterChanges > researchThreshold) {
                specialistInfoText = Locale.compose('LOC_WOLF_REACHED_RESEARCH');
            } else {
                specialistInfoText = Locale.compose('LOC_WOLF_ADD_FOR_RESEARCH');
            }
        } else {
            if (numWorkers + workersNeeded > cityWorkerCap) {
                specialistInfoText = Locale.compose('LOC_WOLF_NOT_REACHABLE', workersNeeded, cityWorkerCap);
            } else {
                specialistInfoText = Locale.compose('LOC_WOLF_WORKERS_NEEDED', workersNeeded, numWorkers, workersNeeded + numWorkers);
            }
        }

        if (
            this.container.lastElementChild
            && this.container.lastElementChild.textContent
            && !this.container.lastElementChild.textContent.includes(Locale.compose('LOC_ATTR_TOTAL_YIELD'))
        ) {
            this.addHorizontalSpace();
            this.addTextLine(Locale.compose('LOC_ATTR_TOTAL_YIELD') + ': ' + totalYields);
            this.addHorizontalSpace();
        }
        this.addTitle(Locale.compose('LOC_UI_SPECIALISTS_SUBTITLE'));
        this.addTextLine(Locale.compose('LOC_UI_SPECIALIST_SUBTITLE') + ' ' + Locale.compose('LOC_UI_MINI_MAP_YIELDS') + ': ' + totalYieldChanges);
        this.addTextLine(Locale.compose('LOC_WOLF_SUM_YIELD_SPECIALIST', totalYieldsAfterChanges));
        this.addTextLine(specialistInfoText);
    }

    addHorizontalSpace(heightVal) {
        let height = heightVal ? heightVal : 0.44444;
        const toolTipHorizontalRule = document.createElement("div");
        toolTipHorizontalRule.style.width = "100%"
        toolTipHorizontalRule.style.height = height + "rem"
        this.container.appendChild(toolTipHorizontalRule);
    }

    addTitle(titleText) {
        const toolTipTitle = document.createElement('div');
        toolTipTitle.classList.add("plot-tooltip__TitleLineFlex");
        const titleLeftSeparator = document.createElement("div");
        titleLeftSeparator.classList.add("plot-tooltip__TitleLineleft");
        toolTipTitle.appendChild(titleLeftSeparator);

        const tooltipTitleText = document.createElement("div");
        tooltipTitleText.classList.add("plot-tooltip__ImprovementName");
        tooltipTitleText.innerHTML = titleText;
        toolTipTitle.appendChild(tooltipTitleText);

        const titleRightSeparator = document.createElement("div");
        titleRightSeparator.classList.add("plot-tooltip__TitleLineRight");
        toolTipTitle.appendChild(titleRightSeparator);
        this.container.appendChild(toolTipTitle);
    }

    addTextLine(text) {
        const textBox = document.createElement("div");
        textBox.classList.add("plot-tooltip__owner-civ-text");
        textBox.innerHTML = text;
        this.container.appendChild(textBox);
    }
}

const WolfsSpecialistTooltipModExport = new WolfsSpecialistTooltipMod();
export {WolfsSpecialistTooltipModExport as default};