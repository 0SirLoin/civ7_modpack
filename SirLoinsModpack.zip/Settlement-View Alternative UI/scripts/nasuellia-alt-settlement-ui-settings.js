﻿// ============================================================================
// Nasuellia Settings Manager - An Options Framework for Civilization 7 Mods
// ============================================================================
// Author: nasuellia
// License: Public Domain - AKA: do whatever you want with this code and use at your own risk!
// Version: 0.1 (unreleased, just embedded into nasuellia's mods)
// 
// Overview:
// This file provides a self-contained, reusable class for managing mod settings in
// Civilization 7. It allows modders to define options with a single configuration,
// automatically generating UI options, storage, and confirm/cancel behavior that
// matches the game's vanilla options system. Options are displayed under a "Mods"
// category in the game's settings menu, and the system is designed to avoid conflicts
// with other settings APIs.
//
// Features:
// - Single source of truth for option definitions (settingsConfig)
// - Automatic generation of getters/setters, default values, and UI options
// - Support for confirm/cancel behavior (changes apply only on "Confirm")
// - Compatibility with other mods and settings APIs
// - Storage in localStorage under a mod-specific key
//
// Usage:
// 1. Copy this file into your mod's scripts directory (e.g., scripts/author-modname-settings.js).
// 2. Update the modSettingsKey and modGroup to unique values for your mod.
// 3. Define your options in settingsConfig (see below for format).
// 4. Add the file to your .modinfo (either or both):
//    - <UIScripts> for shell scope (main menu)
//    - <ImportFiles> for game scope (in-game)
// 5. Import getSettings in your mod scripts to access settings values.
//
// Example import in your mod script:
// import { getSettings } from '/scripts/author-modname-settings.js';
// const getCurrentSettings = () => getSettings("yourModSettingsKey");
// console.log(getCurrentSettings().YourVariable);
// ============================================================================




// ============================================================================
// Customization: Mod-Specific Identifiers
// ============================================================================
// Define a unique key for your mod's settings in localStorage to avoid conflicts
// with other mods. Also set a group identifier for your options in the UI, which
// helps organize options within the "Mods" category.
//
// Variables:
// - modSettingsKey: A unique string for your mod (e.g., "yourModNameSettingsKey").
// - modGroup: Localization string for your mod's group in the settings screen.
const modSettingsKey = "nasuelliaAltSettlementViewSettingsKey";
const modGroup = "NASUELLIA_ALT_SETTLEMENT_VIEW";
// ============================================================================




// ============================================================================
// Imports: Core Game Modules for Options System
// ============================================================================
// These imports bring in the necessary modules from Civilization 7 to interact
// with the game's options system. 
// Do not modify these unless you know what you're doing.
import { Options, OptionType } from '/core/ui/options/model-options.js';
import { CategoryType, CategoryData } from '/core/ui/options/options-helpers.js';
import '/core/ui/options/options.js';
const proto = Object.getPrototypeOf(Options);
// ============================================================================




// ============================================================================
// Category Setup: Adding "Mods" Category
// ============================================================================
// This section safely adds a "Mods" category to the options UI, ensuring compatibility
// with other mods that may also define this category. If the category already exists
// (e.g., defined by another API), it skips redefinition to avoid conflicts. Options
// will fall back to the "Game" category if "Mods" is unavailable. 
// Do not modify these unless you know what you're doing.
if (!CategoryType.Mods) {
    CategoryType.Mods = "mods";
    CategoryData[CategoryType.Mods] = {
        title: "LOC_UI_CONTENT_MGR_SUBTITLE",
        description: "LOC_UI_CONTENT_MGR_SUBTITLE_DESCRIPTION",
    };
}
const modCategory = CategoryType.Mods || CategoryType.Game;
// ============================================================================




// ============================================================================
// Settings Configuration: Define All Options Here
// ============================================================================
// This is the single source of truth for your mod's settings. Each entry defines
// a setting, its default value, and its UI properties. The system automatically
// generates getters/setters, default values, and UI options from this configuration.
//
// Format:
// - name: The setting name (e.g., "ModSettingName"). Used for getters/setters.
// - defaultValue: The default value for the setting (e.g., true).
// - id: A unique identifier for the UI option (e.g., "modname-setting-name").
// - type: The UI option type (e.g., OptionType.Checkbox, OptionType.Dropdown.
// - label: Localization string for the option's label (e.g., "MOD_SETTING_NAME_LABEL").
// - description: Localization string for the option's description (e.g., "MOD_SETTING_NAME_DESCRIPTION").
// - extraProps: Optional properties for advanced option types (currently unsupported).
//
// Example for a Checkbox:
// {
//     name: 'EnableFeature',
//     defaultValue: true,
//     id: "modname-enable-feature",
//     type: OptionType.Checkbox,
//     label: "ENABLE_FEATURE_LABEL",
//     description: "ENABLE_FEATURE_DESCRIPTION"
// }
//
// - Dropdown: A dropdown menu with selectable items.
// {
//     name: 'FeatureMode',
//     defaultValue: "normal",
//     id: "modname-feature-mode",
//     type: OptionType.Dropdown,
//     label: "FEATURE_MODE_LABEL",
//     description: "FEATURE_MODE_DESCRIPTION",
//     extraProps: {
//         dropdownItems: [
//             { setting: "easy", label: "EASY_MODE_LABEL" },
//             { setting: "normal", label: "NORMAL_MODE_LABEL" },
//             { setting: "hard", label: "HARD_MODE_LABEL" }
//         ]
//     }
// }
const settingsConfig = [
    {
        name: 'ShowCompletedProduction',
        defaultValue: true,
        id: "nasuellia-alt-settlement-view-show-completed-production",
        type: OptionType.Checkbox,
        label: "SHOW_COMPLETED_PRODUCTION_LABEL",
        description: "SHOW_COMPLETED_PRODUCTION_DESCRIPTION"
    },
    {
        name: 'HideAdvisorIcons',
        defaultValue: true,
        id: "nasuellia-alt-settlement-view-hide-advisor-icons",
        type: OptionType.Checkbox,
        label: "HIDE_ADVISOR_ICONS_LABEL",
        description: "HIDE_ADVISOR_ICONS_DESCRIPTION"
    },
    {
        name: 'PreventAutoClose',
        defaultValue: true,
        id: "nasuellia-alt-settlement-view-prevent-auto-close",
        type: OptionType.Checkbox,
        label: "PREVENT_AUTO_CLOSE_LABEL",
        description: "PREVENT_AUTO_CLOSE_DESCRIPTION"
    },
    {
        name: 'AltVisualLanguage',
        defaultValue: true,
        id: "nasuellia-alt-settlement-view-alt-visual-language",
        type: OptionType.Checkbox,
        label: "ALT_VISUAL_LANGUAGE_LABEL",
        description: "ALT_VISUAL_LANGUAGE_DESCRIPTION"
    }
];
// ============================================================================




// ============================================================================
// Default Settings: Generated from settingsConfig
// ============================================================================
// Automatically generates the default settings object used by getSettings and
// createSettings. This ensures consistency between default values and the settings
// configuration. 
// Do not modify these unless you know what you're doing.
const defaultSettings = {};
settingsConfig.forEach(setting => {
    defaultSettings[setting.name] = setting.defaultValue;
});
// ============================================================================




// ============================================================================
// ModSettingsManager: Persistent Storage for Settings
// ============================================================================
// Manages the storage of settings in localStorage under a single key ("modSettings"),
// namespaced by modSettingsKey. This ensures settings are isolated per mod and
// prevents conflicts with other mods. 
// Do not modify these unless you know what you're doing.
const ModSettingsManager = {
    save(key, data) {
        const modSettings = JSON.parse(localStorage.getItem("modSettings") || '{}');
        modSettings[key] = data;
        localStorage.setItem("modSettings", JSON.stringify(modSettings));
    },
    read(key) {
        const modSettings = localStorage.getItem("modSettings");
        try {
            if (modSettings) {
                const data = JSON.parse(modSettings || '{}')[key];
                if (data) return data;
            }
            return null;
        } catch (e) {
            console.error(`[ModSettingsManager][${key}] Error loading settings`, e);
        }
        return null;
    }
};
// ============================================================================




// ============================================================================
// getSettings: Access Committed Settings Values
// ============================================================================
// Exported function for other scripts to access the mod's settings. Returns the
// committed settings values (from localStorage) or the default settings if none
// are saved. Note that this reflects only confirmed changes, not pending ones.
// Do not modify these unless you know what you're doing.
export function getSettings(key = modSettingsKey) {
    return ModSettingsManager.read(key) || defaultSettings;
}
// ============================================================================


// ============================================================================
// createSettings: Dynamic Settings Class Factory
// ============================================================================
// Creates a settings class with dynamically generated getters and setters for each
// setting defined in settingsConfig. Manages both committed (_data) and pending
// (_pendingData) values to support the confirm/cancel behavior.
// Do not modify these unless you know what you're doing.
//
// Methods:
// - commit(): Applies pending changes to committed data and saves to localStorage.
// - restore(): Reverts pending changes to the last committed values.
// - save(): Saves the committed data to localStorage (called by commit()).
// - resetToDefaults(): Resets all settings to their default values and saves.
function createSettings(modSettingsKey) {
    const settingsClass = class {
        _data = { ...defaultSettings };
        _pendingData = { ...this._data };

        constructor() {
            const savedData = ModSettingsManager.read(modSettingsKey);
            if (savedData) {
                this._data = savedData;
                this._pendingData = { ...savedData };
            }
        }

        commit() {
            this._data = { ...this._pendingData };
            this.save();
        }

        restore() {
            this._pendingData = { ...this._data };
        }

        save() {
            ModSettingsManager.save(modSettingsKey, this._data);
        }
        
        resetToDefaults() {
            this._data = { ...defaultSettings };
            this._pendingData = { ...this._data };
            this.save();
        }
        
    };

    // Dynamically add getters and setters
    settingsConfig.forEach(setting => {
        Object.defineProperty(settingsClass.prototype, setting.name, {
            get() {
                return this._pendingData[setting.name];
            },
            set(value) {
                this._pendingData[setting.name] = value;
            },
            enumerable: true,
            configurable: true
        });
    });

    return new settingsClass();
}
const modSettings = createSettings(modSettingsKey);
// ============================================================================




// ============================================================================
// optionsConfig: Generated UI Options Configuration
// ============================================================================
// Automatically generates the configuration for UI options from settingsConfig.
// This defines how each setting appears in the game's options menu, including
// its type, label, description, and other properties.
// Do not modify these unless you know what you're doing.
const optionsConfig = settingsConfig.map(setting => ({
    setting: setting.name,
    id: setting.id,
    type: setting.type,
    label: setting.label,
    description: setting.description,
    // Add any extraProps if needed in the future
    ...(setting.extraProps ? { extraProps: setting.extraProps } : {})
}));
// ============================================================================




// ============================================================================
// Confirm/Cancel Hooks: Integration with Game UI
// ============================================================================
// Overrides the game's Options.commitOptions and Options.restore methods to
// integrate with the confirm/cancel flow. This ensures changes are applied only
// when the user clicks "Confirm" and discarded on "Cancel."
// Note: These overrides chain to the original methods, ensuring compatibility
// with other mods that may also override these methods.
// Do not modify these unless you know what you're doing.
const commitOptions = proto.commitOptions;
proto.commitOptions = function(...args) {
    commitOptions.apply(this, args);
    modSettings.commit();
};

const restore = proto.restore;
proto.restore = function(...args) {
    restore.apply(this, args);
    modSettings.restore();
};

const resetOptionsToDefault = proto.resetOptionsToDefault;
proto.resetOptionsToDefault = function(...args) {
    resetOptionsToDefault.apply(this, args);
    modSettings.resetToDefaults();
};
// ============================================================================




// ============================================================================
// Options Registration: Adding Options to the Game UI
// ============================================================================
// Registers all options with the game's options system using Options.addInitCallback.
// Each option is configured with initListener and updateListener to handle UI
// interactions, buffering changes in modSettings until confirmed.
// The options are placed in the "Mods" category (or "Game" as a fallback) and
// grouped by modGroup for organization in the UI.
// Do not modify these unless you know what you're doing.
Options.addInitCallback(() => {
    optionsConfig.forEach(opt => {
        let initListener;
        let updateListener;

        // Default handling for various option types.
        switch (opt.type) {
            case OptionType.Checkbox:
                initListener = (optionInfo) => {
                    optionInfo.currentValue = modSettings[opt.setting];
                };
                updateListener = (optionInfo, value) => {
                    optionInfo.currentValue = value;
                    modSettings[opt.setting] = value;
                };
                break;
            case OptionType.Dropdown:
                initListener = (optionInfo) => {
                    const currentValue = modSettings[opt.setting];
                    if (optionInfo.dropdownItems && Array.isArray(optionInfo.dropdownItems)) {
                        const index = optionInfo.dropdownItems.findIndex(item => item.setting === currentValue);
                        optionInfo.selectedItemIndex = index >= 0 ? index : 0;
                    }
                };
                updateListener = (optionInfo, value) => {
                    if (optionInfo.dropdownItems && Array.isArray(optionInfo.dropdownItems)) {
                        modSettings[opt.setting] = optionInfo.dropdownItems[value].setting;
                    }
                };
                break;
            default:
                console.error(
                    `NASUDEBUG: Unsupported option type "${opt.type}" for option "${opt.id}". ` +
                    `Only OptionType.Checkbox and OptionType.Dropdown are supported. ` +
                    `This option will be skipped.`
                );
                return;
        }

        // Build the option object.
        const optionObj = {
            category: opt.category || modCategory,
            group: opt.group || modGroup,
            type: opt.type,
            id: opt.id,
            initListener: initListener,
            updateListener: updateListener,
            label: opt.label,
            description: opt.description
        };

        // Merge any extra properties (such as dropdownItems, min, max, steps, etc.).
        if (opt.extraProps) {
            Object.assign(optionObj, opt.extraProps);
        }

        Options.addOption(optionObj);
    });
});
// ============================================================================