/**
 * @file appeal-layer
 * @copyright 2022, Firaxis Games
 * @description Lens layer to show settling appeal of a plots
 */
import { InterfaceMode } from '/core/ui/interface-modes/interface-modes.js';
import LensManager from '/core/ui/lenses/lens-manager.js';
import { sibTransparentAppealOptions, SibTransparentAppealTheme } from '/sib-transparent-appeal/ui/options/sib-transparent-appeal-options.js';


const HexToFloat4 = (hex, alpha = 1) => {
    const r = (hex >> 16) & 0xff;
    const g = (hex >> 8) & 0xff;
    const b = hex & 0xff;
    return { x: r / 255, y: g / 255, z: b / 255, w: Math.min(1, Math.max(0, alpha)) };
};

// Common colors
const SETTLEMENT_BLOCKED_COLOR = HexToFloat4(0x690909, .3); 
const SETTLEMENT_REVEALED_BLOCKED_COLOR = HexToFloat4(0x690909, .6); 

const RESOURCE_PLOT_COLOR = HexToFloat4(0xFF33AA, .1); 
const RESOURCE_REVEALED_PLOT_COLOR = HexToFloat4(0xFF33AA, .4); 

const WONDER_PLOT_COLOR = HexToFloat4(0x7A1EFF, .3);
const WONDER_REVEALED_PLOT_COLOR = HexToFloat4(0x7A1EFF, .4); 

//Get theme colours from options menu
function _getOkayColor() {
  const theme = sibTransparentAppealOptions.data.theme;
  if (theme === SibTransparentAppealTheme.CIV6) {
    return HexToFloat4(0xc6c6c6, .1); // Civ6 style
  } else {
    return HexToFloat4(0xb49e28, .1); // Base-game style
  }
}

function _getRevealedOkayColor() {
  const theme = sibTransparentAppealOptions.data.theme;
  return theme === SibTransparentAppealTheme.CIV6
    ? HexToFloat4(0xc6c6c6, .4) // Civ6 style
    : HexToFloat4(0xb49e28, .4); // Base-game style
}

function _getGoodColor() {
  const theme = sibTransparentAppealOptions.data.theme;
  return theme === SibTransparentAppealTheme.CIV6
    ? HexToFloat4(0x196319, .2) // Civ6 style
    : HexToFloat4(0x26eebe, .1); // Base-game style
}

function _getRevealedGoodColor() {
  const theme = sibTransparentAppealOptions.data.theme;
  return theme === SibTransparentAppealTheme.CIV6
    ? HexToFloat4(0x196319, .5) // Civ6 style
    : HexToFloat4(0x26eebe, .4); // Base-game style
}

class AppealLensLayer {
    constructor() {
        this.cityAddedToMapListener = () => { this.onCityAddedToMap(); };
        this.appealOverlayGroup = WorldUI.createOverlayGroup("AppealOverlayGroup", 1);
        this.appealOverlay = this.appealOverlayGroup.addPlotOverlay();
        this.blockedPlots = [];
		this.revealedBlockedPlots = [];
        this.bestPlots = [];
		this.revealedBestPlots = [];
        this.okayPlots = [];
		this.revealedOkayPlots = [];
		this.resourcePlots = [];
        this.revealedResourcePlots = [];
		this.wonderPlots = [];
        this.revealedWonderPlots = [];
    }
    clearOverlay() {
        this.appealOverlayGroup.clearAll();
        this.appealOverlay.clear();
        this.blockedPlots = [];
		this.revealedBlockedPlots = [];
        this.bestPlots = [];
		this.revealedBestPlots = [];
        this.okayPlots = [];
		this.revealedOkayPlots = [];
        this.resourcePlots = [];
        this.revealedResourcePlots = [];
		this.wonderPlots = [];
        this.revealedWonderPlots = [];

        engine.off('CityInitialized', this.cityAddedToMapListener);
    }
    initLayer() {
    }
    applyLayer() {
    this.clearOverlay();
        engine.on('CityInitialized', this.cityAddedToMapListener);
        const localPlayer = Players.get(GameContext.localPlayerID);
        const localPlayerDiplomacy = localPlayer?.Diplomacy;
        if (!localPlayerDiplomacy) {
            console.error("appeal-layer: Unable to find local player diplomacy!");
            return;
        }
        const isInPlacementMode = InterfaceMode.isInInterfaceMode("INTERFACEMODE_BONUS_PLACEMENT");
        const width = GameplayMap.getGridWidth();
        const height = GameplayMap.getGridHeight();
        for (let x = 0; x < width; x++) {
            for (let y = 0; y < height; y++) {
                const plotCoord = { x, y };
                // Detect resources
                if (GameplayMap.getResourceType(x, y) !== -1) {
                    if (GameplayMap.getRevealedState(GameContext.localPlayerID, x, y) == RevealedStates.VISIBLE) {
                        this.revealedResourcePlots.push(plotCoord);
                    } else {
                        this.resourcePlots.push(plotCoord);
                    }
                }
				// Detect natural wonders
                if (GameplayMap.isNaturalWonder(x, y)) {
                    if (GameplayMap.getRevealedState(GameContext.localPlayerID, x, y) == RevealedStates.VISIBLE) {
                        this.revealedWonderPlots.push(plotCoord);
                    } else {
                        this.wonderPlots.push(plotCoord);
                    }
                }
                if (isInPlacementMode) {
                    if (!GameplayMap.isPlotInAdvancedStartRegion(GameContext.localPlayerID, x, y)) {
                        if (GameplayMap.isWater(x, y)) {
						continue;
						}
						if (GameplayMap.getRevealedState(GameContext.localPlayerID, x, y) == RevealedStates.VISIBLE ) {
							this.revealedBlockedPlots.push(plotCoord);
							continue;
						}
						this.blockedPlots.push(plotCoord);
                        continue;
                    }
                }
                // Not a valid land claim location
                if (!localPlayerDiplomacy.isValidLandClaimLocation(plotCoord, true)) {
                    if (GameplayMap.isWater(x, y)) {
						continue;
                    }
					if (GameplayMap.getRevealedState(GameContext.localPlayerID, x, y) == RevealedStates.VISIBLE ) {
						this.revealedBlockedPlots.push(plotCoord);
						continue;
					}
                    this.blockedPlots.push(plotCoord);
                    continue;
                }
                // Too Close to Village -- DISABLE FOR NOW (EFB 3/7/23), may want to add non-colored UI overlay (such as Loyalty in VI)
                // const distanceToNearestIndependentPower: number = Game.IndependentPowers.getDistanceToNearestIndependent(plotCoord);
                // if (distanceToNearestIndependentPower <= this.villageLowerAffinityRange) {
                // 	this.okayPlots.push(plotCoord);
                // 	continue;
                // }
                if (GameplayMap.isFreshWater(x, y)){
					if (GameplayMap.getRevealedState(GameContext.localPlayerID, x, y) == RevealedStates.VISIBLE ){
						this.revealedBestPlots.push(plotCoord);
						continue;
					} 
                    this.bestPlots.push(plotCoord);
                    continue;
                }
				if (GameplayMap.getRevealedState(GameContext.localPlayerID, x, y) == RevealedStates.VISIBLE ){
						this.revealedOkayPlots.push(plotCoord);
						continue;
				}
                this.okayPlots.push(plotCoord);
            }
        }
        
		this.appealOverlay.addPlots(this.blockedPlots, { fillColor: SETTLEMENT_BLOCKED_COLOR });
		this.appealOverlay.addPlots(this.revealedBlockedPlots, { fillColor: SETTLEMENT_REVEALED_BLOCKED_COLOR });
		
        this.appealOverlay.addPlots(this.okayPlots,           { fillColor: _getOkayColor() });
		this.appealOverlay.addPlots(this.revealedOkayPlots,   { fillColor: _getRevealedOkayColor() });
		this.appealOverlay.addPlots(this.bestPlots,           { fillColor: _getGoodColor() });
		this.appealOverlay.addPlots(this.revealedBestPlots,   { fillColor: _getRevealedGoodColor() });
		
		this.appealOverlay.addPlots(this.resourcePlots, { fillColor: RESOURCE_PLOT_COLOR });
        this.appealOverlay.addPlots(this.revealedResourcePlots, { fillColor: RESOURCE_REVEALED_PLOT_COLOR });
		this.appealOverlay.addPlots(this.wonderPlots, { fillColor: WONDER_PLOT_COLOR });
        this.appealOverlay.addPlots(this.revealedWonderPlots, { fillColor: WONDER_REVEALED_PLOT_COLOR });
		
    }
    onCityAddedToMap() {
        this.applyLayer();
    }
    removeLayer() {
        this.clearOverlay();
    }
}
LensManager.registerLensLayer('fxs-appeal-layer', new AppealLensLayer());

//# sourceMappingURL=file:///base-standard/ui/lenses/layer/appeal-layer.js.map