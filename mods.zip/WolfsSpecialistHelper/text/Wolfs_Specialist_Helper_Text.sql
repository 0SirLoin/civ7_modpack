--========================================================================================================================
--========================================================================================================================
        INSERT OR REPLACE INTO LocalizedText
			(Tag,	Language,	Text)
		VALUES
			('LOC_WOLF_REACHED_RESEARCH',	    'de_DE',	"40 Erträge bereits erreicht"),
			('LOC_WOLF_ADD_FOR_RESEARCH',	    'de_DE',	"Hinzufügen für mindestens 40 Erträge"),
			('LOC_WOLF_NOT_REACHABLE',		    'de_DE',	"40 Erträge nicht erreichbar benötige {1}/{2} Spezialisten"),
			('LOC_WOLF_WORKERS_NEEDED',		    'de_DE',	"40 Erträge mit {1} Spezialisten erreichbar derzeit {2}/{3}"),
			('LOC_WOLF_SUM_YIELD_SPECIALIST',   'de_DE',	"Erträge nach Spezialist: {1}"),
--========================================================================================================================
--========================================================================================================================
			('LOC_WOLF_REACHED_RESEARCH',	    'en_US',	"40 yields already reached"),
			('LOC_WOLF_ADD_FOR_RESEARCH',	    'en_US',	"Add for at least 40 yields"),
			('LOC_WOLF_NOT_REACHABLE',		    'en_US',	"40 yields unreachable need {1}/{2} specialists"),
			('LOC_WOLF_WORKERS_NEEDED',		    'en_US',	"40 yields reachable with {1} specialists, currently {2}/{3}"),
			('LOC_WOLF_SUM_YIELD_SPECIALIST',   'en_US',	"Yields after specialist: {1}");
--========================================================================================================================
--========================================================================================================================