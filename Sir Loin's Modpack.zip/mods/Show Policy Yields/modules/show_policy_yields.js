import GreatWorks from '/base-standard/ui/great-works/model-great-works.js';
import AttributeTrees from '/base-standard/ui/attribute-trees/model-attribute-trees.js';
import PoliciesData from '/base-standard/ui/policies/model-policies.js';

const initFunction = () => {
    let cachedCities = [];
    let cachedPlots = [];
    let cachedUnits = [];

    function overwriteInitialization() {
        const originalFunction = Controls.getDefinition("screen-policies").createInstance.prototype.buildPolicyWindow;

        Controls.getDefinition("screen-policies").createInstance.prototype.buildPolicyWindow = function() {
            let player = Players.get(GameContext.localPlayerID);            
            cachedCities = player.Cities.getCities();
            cachedPlots = cachedCities
                                .map(c => c.getPurchasedPlots().map(p => GameplayMap.getLocationFromIndex(p)))
                                .flat();
            cachedUnits = player.Units.getUnits();

            originalFunction.apply(this);
        }
    }

    function overwriteScreenPolicies() {
        const originalFunction = Controls.getDefinition("screen-policies").createInstance.prototype.createPolicyNode;
    
        Controls.getDefinition("screen-policies").createInstance.prototype.createPolicyNode = function(policy, isSelectable) {
            var original = originalFunction.apply(this, [policy, isSelectable]);
            original.TraditionType = policy.TraditionType;
            return original;
        }
    }
    
    function overwritePolicyChooserItem() {
        const originalFunction = Controls.getDefinition("policy-chooser-item").createInstance.prototype.render;
    
        Controls.getDefinition("policy-chooser-item").createInstance.prototype.render = function() {
            originalFunction.apply(this, []);
            
            this.Root.children[this.Root.children.length - 1].style.flexGrow = "1";
            
            const node = this.policyChooserNode;

            let player = Players.get(GameContext.localPlayerID);

            let trad = node.TraditionType;
            let tradMods = GameInfo.TraditionModifiers.filter(tm => tm.TraditionType == trad).map(tm => tm.ModifierId);
            let increasedYields = {};
            for (let tradModId of tradMods)
                calculateModYields(tradModId, player, cachedCities, cachedPlots, cachedUnits, increasedYields);

            var cardEffect = document.createElement("div");
            cardEffect.classList.add("policy-card-body-text", "w-full", "pl-4", "text-accent-4", "font-body-sm", "z-1");
            cardEffect.setAttribute("data-l10n-id", `<p cohinline>${getIncreasedYieldsAsText(increasedYields)}</p>`);
            this.Root.appendChild(cardEffect);
        }
    }
    
    function calculateModYields(tradModId, player, playerCities, playerPlots, playerUnits, increasedYields){
        let mod = GameInfo.Modifiers.find(m => m.ModifierId == tradModId);
        let dynMod = GameInfo.DynamicModifiers.find(dm => dm.ModifierType == mod.ModifierType);
        let args = GameInfo.ModifierArguments.filter(ma => ma.ModifierId == mod.ModifierId).reduce((map, object) => {
            map[object.Name] = object.Value;
            return map;
        }, {});

        if (mod.OwnerRequirementSetId){
            console.error("POLICY HAS ONWER REQUIREMENT SET ID");
            console.error(JSON.stringify(mod));
        }
        
        if (dynMod.CollectionType == "COLLECTION_PLAYER_CAPITAL_CITY") {
            playerCities = getPlayerCapital(playerCities, false);
            playerPlots = getPlotsFromCities(playerCities, playerPlots);
        }

        if (mod.SubjectRequirementSetId) {
            let reqIds = GameInfo.RequirementSetRequirements.filter(r => r.RequirementSetId == mod.SubjectRequirementSetId).map(r => r.RequirementId);
            
            for (var reqId of reqIds) {
                let requirement = GameInfo.Requirements.find(r => r.RequirementId == reqId);
                let reqArgs = GameInfo.RequirementArguments.filter(ra => ra.RequirementId == reqId).reduce((map, object) => {
                    map[object.Name] = object.Value;
                    return map;
                }, {});
                
                let inverse = requirement.Inverse;

                switch (requirement.RequirementType) {
                    case "REQUIREMENT_CITY_IS_CITY":
                        playerCities = getPlayerCities(playerCities, inverse);
                        break;
                    case "REQUIREMENT_CITY_IS_TOWN":
                        playerCities = getPlayerTowns(playerCities, inverse);
                        break;
                    case "REQUIREMENT_REQUIREMENTSET_IS_MET":
                        if (reqArgs.RequirementSetId == "REQSET_ONLY_TOWNS")
                            playerCities = getPlayerTowns(playerCities, inverse);
                        else if (reqArgs.RequirementSetId == "REQSET_ONLY_CITIES")
                            playerCities = getPlayerCities(playerCities, inverse);
                        break;
                    case "REQUIREMENT_CITY_IS_CAPITAL":
                        playerCities = getPlayerCapital(playerCities, inverse);
                        break;
                    case "REQUIREMENT_CITY_HAS_BUILDING":
                        if (reqArgs.BuildingType)
                            playerCities = getSettlementsWithBuildingType(playerCities, reqArgs.BuildingType, inverse);
                        else if (reqArgs.Tag)
                            playerCities = getSettlementsWithBuildingTag(playerCities, reqArgs.Tag, inverse);
                        break;
                    case "REQUIREMENT_CITY_IS_ORIGINAL_OWNER":
                        playerCities = getOriginallyOwnedSettlements(playerCities, inverse);
                        break;
                    case "REQUIREMENT_PLOT_ADJACENT_TO_COAST":
                        if (dynMod.CollectionType == "COLLECTION_PLAYER_CITIES") {
                            playerCities = getCoastalSettlements(playerCities, inverse);
                        }
                        else if (dynMod.CollectionType == "COLLECTION_PLAYER_PLOT_YIELDS")
                            playerPlots = playerPlots.filter(p => GameplayMap.isCoastalLand(p.x, p.y));
                        break;
                    case "REQUIREMENT_CITY_POPULATION":
                        if (reqArgs.MinUrbanPopulation)
                            playerCities = playerCities.filter(c => c.urbanPopulation >= Number(reqArgs.MinUrbanPopulation));
                        break;
                    case "REQUIREMENT_PLAYER_IS_AT_PEACE_WITH_ALL_MAJORS":
                        let players = Players.getAlive().filter(p => p.isMajor && p.id != player.id);
                        let peaceWith = players.filter(p => !player.Diplomacy.isAtWarWith(p.id));
                        if ((players.length != peaceWith.length) - inverse)
                            playerCities = [];
                        break;
                    case "REQUIREMENT_CITY_HAS_PROJECT":
                        if (reqArgs.HasAnyProject == "true")
                            playerCities = playerCities.filter(c => c.Growth.projectType != -1);
                        else if (reqArgs.ProjectType) {
                            let projectHash = GameInfo.Types.find(t => t.Type == reqArgs.ProjectType).Hash;
                            playerCities = playerCities.filter(c => c.Growth.projectType == projectHash);
                        }
                        break;
                    case "REQUIREMENT_PLOT_RESOURCE_VISIBLE":
                        playerPlots = playerPlots.filter(p => GameplayMap.getResourceType(p.x, p.y) != -1);
                        break;
                    case "REQUIREMENT_PLOT_IS_QUARTER":
                        playerPlots = playerPlots.filter(p => {
                            let city = playerCities.find(c => c.id.id == GameplayMap.getOwningCityFromXY(p.x, p.y).id);
                            let constructiblesAt = city.Constructibles.getIdsAtLocation(p);
                            for(var conId of constructiblesAt) {
                                let con = Constructibles.getByComponentID(conId);
                                let building = GameInfo.Constructibles.lookup(con.type);
                                let isFullTile = GameInfo.TypeTags.find(tt => tt.Type == building.ConstructibleType && tt.Tag == "FULL_TILE");
                                if (isFullTile) return true;
                            }
                            return constructiblesAt.length >= 2;
                        });
                        break;
                    case "REQUIREMENT_PLOT_HAS_NUM_CONSTRUCTIBLES":
                        playerPlots = playerPlots.filter(p => {
                            let city = playerCities.find(c => c.id.id == GameplayMap.getOwningCityFromXY(p.x, p.y).id);
                            let constructiblesAt = city.Constructibles.getIdsAtLocation({"x": p.x, "y": p.y});
                            return constructiblesAt.length >= Number(reqArgs.Amount);
                        });
                        break;
                    case "REQUIREMENT_PLOT_HAS_CONSTRUCTIBLE":
                        playerPlots = playerPlots.filter(p => {
                            let city = playerCities.find(c => c.id.id == GameplayMap.getOwningCityFromXY(p.x, p.y).id);
                            let constructiblesAt = city.Constructibles.getIdsAtLocation({"x": p.x, "y": p.y});
                            for (let cid of constructiblesAt) { 
                                if (reqArgs.Tag) {
                                    if (getConstructibleTags(cid).includes(reqArgs.Tag))
                                        return true;
                                }
                                else if (reqArgs.ConstructibleType) {
                                    if (getConstructibleType(cid) == reqArgs.ConstructibleType)
                                        return true;
                                }
                            }
                            
                            return false;
                        });
                        break;
                    case "REQUIREMENT_PLOT_FEATURE_TYPE_MATCHES":
                        playerPlots = playerPlots.filter(p => GameInfo.FeatureClasses.lookup(GameplayMap.getFeatureClassType(p.x, p.y))?.FeatureClassType == reqArgs.FeatureClassType);
                        break;
                    case "REQUIREMENT_PLOT_DISTRICT_CLASS":
                        playerPlots = playerPlots.filter(p => {
                            let district = Districts.getAtLocation(p);
                            if (!district) 
                                return false - inverse;

                            let districtClass = GameInfo.Districts.lookup(district.type).DistrictClass;
                            for (var searchedForDistrict of reqArgs.DistrictClass.split(",").map(d => d.replace(" ", ""))){
                                if (searchedForDistrict == districtClass || (searchedForDistrict == "URBAN" && district.isUrbanCore))
                                    return true - inverse;
                            }
                            return false - inverse;
                        });
                        break;
                    default:
                        // console.error(JSON.stringify(playerCities[0].Districts, null, 2));
                }
            }
        }
        
        playerPlots = getPlotsFromCities(playerCities, playerPlots);

        let effect = dynMod.EffectType;
        if (!args.YieldType) {
            switch (effect) {
                case "EFFECT_CITY_ADJUST_BUILDING_MAINTENANCE_EFFICIENCY":
                    // LIVING STANDARDS card says "+25% gold and happiness towards maintaining buildings"
                    // yet the percent for this effect IS SET TO "-25" THAT MAKES NO SENSE
                    for(var city of playerCities) {
                        for(var conId of city.Constructibles.getIds()) {
                            let con = Constructibles.getByComponentID(conId);
                            let building = GameInfo.Constructibles.lookup(con.type);
                            let maintenances = GameInfo.Constructible_Maintenances
                                                .filter(cm => cm.ConstructibleType == building.ConstructibleType)
                                                .reduce((map, object) => {
                                                    map[object.YieldType] = object.Amount;
                                                    return map;
                                                }, {});
                            let base_happiness = maintenances["YIELD_HAPPINESS"] ?? 0;
                            let base_gold = maintenances["YIELD_GOLD"] ?? 0;
                            let changed_happiness = calculateEffectiveness(base_happiness, args.Percent);
                            let changed_gold = calculateEffectiveness(base_gold, args.Percent);
                            addYields(increasedYields, "YIELD_HAPPINESS", changed_happiness);
                            addYields(increasedYields, "YIELD_GOLD", changed_gold);
                        }
                    }
                    break;
                case "EFFECT_MODIFY_PLAYER_TRADE_YIELD_CONVERSION":
                    // this returns 0 for all cities dunno why => city.Yields.getTradeYields()
                    break;
                case "EFFECT_ATTACH_MODIFIERS":
                    calculateModYields([args.ModifierId], player, playerCities, playerPlots, playerUnits, increasedYields);
                    break;
                case "EFFECT_PLAYER_ADJUST_UNIT_MAINTENANCE_EFFICIENCY":
                    let units = playerUnits.filter(u => {
                        if (!args.UnitDomain && !args.UnitTag && !args.UnitClass) {
                            return true;
                        }
                        let unit = GameInfo.Units.lookup(u.type);
                        // let unit = GameInfo.Units.find(ud => ud.UnitType == GameInfo.Types.find(t => t.Hash == u.type).Type);
                        if (args.UnitDomain && unit.Domain == args.UnitDomain)
                            return true;

                        let tags = [];
                        
                        if (args.UnitClass)
                            tags.push(...args.UnitClass.split(",").map(s => s.replace(" ", "")))
                        if (args.UnitTag)
                            tags.push(...args.UnitTag.split(",").map(s => s.replace(" ", "")));

                        for (let unitTag of tags){
                            if (GameInfo.TypeTags.find(tt => tt.Type == unit.UnitType && tt.Tag == unitTag))
                                return true;
                        }
                        return false;
                    });
                    addYields(increasedYields, "YIELD_GOLD", units.length * args.Amount);
                    break;
                default:
                    // console.error(effect);
                    break;
            }
            return increasedYields;
        }
        
        // YieldType has sometimes multiple types like "YIELD_FOOD, YIELD_GOLD, YIELD_CULTURE"
        // split it and make a loop
        let yieldTypes = args.YieldType.split(",").map(s => s.replace(" ", ""))
        for (let yieldType of yieldTypes) {
            switch (effect) {
                case "EFFECT_CITY_ADJUST_CONSTRUCTIBLE_YIELD": 
                case "EFFECT_PLAYER_ADJUST_CONSTRUCTIBLE_YIELD":
                    let buildingCount = 0;
                    if (args.ConstructibleType)
                        buildingCount = countBuildings(playerCities, args.ConstructibleType);
                    else if (args.Tag)
                        buildingCount = countBuildingsByTag(playerCities, args.Tag);
                    else {
                        console.error(`Tag and ConstructibleType not found in effect EFFECT_PLAYER_ADJUST_CONSTRUCTIBLE_YIELD`);
                        console.error(JSON.stringify(mod));
                    }
                    addYields(increasedYields, yieldType, buildingCount * args.Amount);
                    break;
                case "EFFECT_CITY_ADJUST_YIELD":
                    if (args.Amount)
                        addYields(increasedYields, yieldType, playerCities.length * args.Amount);
                    else if (args.Percent)
                        addYields(increasedYields, yieldType, getSettlementsYields(playerCities, yieldType)
                                                                .reduce((a,b) => a+b, 0) * Number(args.Percent) / 100);
                    else {
                        console.error(`Amount and Percent not found in effect EFFECT_CITY_ADJUST_YIELD`);
                        console.error(JSON.stringify(mod));
                    }
                    break;
                case "EFFECT_PLAYER_ADJUST_YIELD_PER_NUM_CITIES":
                    if (args.Cities == "true")
                        addYields(increasedYields, yieldType, getPlayerCities(playerCities).length * args.Amount);
                    if (args.Towns == "true") 
                        addYields(increasedYields, yieldType, getPlayerTowns(playerCities).length * args.Amount);
                    break;
                case "EFFECT_CITY_ADJUST_YIELD_PER_SURPLUS_HAPPINESS":
                    addYields(increasedYields, yieldType, getSettlementsYields(playerCities, "YIELD_HAPPINESS")
                                                            .map(y => Math.floor(y / Number(args.Divisor)))
                                                            .reduce((a, b) => a+b, 0) * args.Amount);
                    break;
                case "EFFECT_PLAYER_ADJUST_YIELD_PER_SUZERAIN":
                    addYields(increasedYields, yieldType, args.Amount * player.Influence.numTributaries);
                    break;
                case "EFFECT_CITY_ADJUST_YIELD_PER_SUZERAIN":
                    addYields(increasedYields, yieldType, playerCities.length * args.Amount * player.Influence.numTributaries);
                    break;
                case "EFFECT_CITY_ADJUST_YIELD_PER_RESOURCE":
                    addYields(increasedYields, yieldType, playerCities.map(c => getAssignedResources(c).length * args.Amount)
                                                                        .reduce((a, b) => a+b, 0));
                    break;
                case "EFFECT_CITY_ADJUST_WORKER_YIELD":
                    addYields(increasedYields, yieldType, playerCities.map(c => getNumWorkers(c) * args.Amount)
                                                            .reduce((a, b) => a + b, 0));
                    break;
                case "EFFECT_CITY_ADJUST_YIELD_PER_GREAT_WORK":
                    addYields(increasedYields, yieldType, (GreatWorks.TotalGreatWorks - GreatWorks.WorksInArchive) * args.Amount);
                    break;
                case "EFFECT_CITY_ADJUST_YIELD_PER_ATTRIBUTE":
                    addYields(increasedYields, yieldType, getSpentAttributePoints(args.AttributeType) * playerCities.length * args.Amount);
                    break;
                case "EFFECT_CITY_ADJUST_YIELD_PER_POPULATION":
                    if (args.Urban == "true")
                        addYields(increasedYields, yieldType, playerCities.map(c => c.urbanPopulation * args.Amount / args.Divisor)
                                                                            .reduce((a, b) => a+b, 0));
                    if (args.Rural == "true")
                        addYields(increasedYields, yieldType, playerCities.map(c => c.ruralPopulation * args.Amount / args.Divisor)
                                                                            .reduce((a, b) => a+b, 0));
                    break;
                case "EFFECT_PLAYER_ADJUST_YIELD_PER_NUM_TRADE_ROUTES":
                    addYields(increasedYields, yieldType, player.Trade.countPlayerTradeRoutes() * args.Amount);
                    break;
                case "EFFECT_PLAYER_ADJUST_YIELD_PER_RESOURCE":
                    if (args.Imported == "true")
                        addYields(increasedYields, yieldType, player.Resources.getCountImportedResources() * args.Amount);
                    else
                        addYields(increasedYields, yieldType, player.Resources.getResources().length * args.Amount);
                    break;
                case "EFFECT_PLAYER_ADJUST_YIELD_PER_ACTIVE_TRADITION":
                    addYields(
                        increasedYields,
                        yieldType,
                        PoliciesData.activePolicies.filter(ap => ap.TraitType).length * args.Amount
                    );
                    break;
                case "EFFECT_CITY_ADJUST_YIELD_PER_ACTIVE_TRADITION":
                    addYields(
                        increasedYields,
                        yieldType,
                        PoliciesData.activePolicies.filter(ap => ap.TraitType).length * playerCities.length * args.Amount
                    );
                    break;
                case "EFFECT_PLAYER_ADJUST_CONSTRUCTIBLE_YIELD_BY_ATTRIBUTE":
                    addYields(
                        increasedYields,
                        yieldType,
                        countBuildings(playerCities, args.ConstructibleType) * getSpentAttributePoints(args.AttributeType) * args.Amount
                    )
                    break;
                case "EFFECT_PLOT_ADJUST_YIELD":
                    addYields(increasedYields, yieldType, playerPlots.length * args.Amount);
                    break;
                case "EFFECT_CITY_ADJUST_WORKER_MAINTENANCE_EFFICIENCY":
                    let change = playerCities.map(c => getNumWorkers(c) * calculateEffectiveness(2, args.Percent) ).reduce((a, b) => a + b, 0);
                    addYields(increasedYields, yieldType, change);
                    break;
                default:
                    // console.error(effect);
                    break;
            }
        }

        return increasedYields;
    }

    function getPlotsFromCities(playerCities, playerPlots) {
        let plots = [];
        for(let city of playerCities) {
            let cityPlots = city.getPurchasedPlots().map(p => GameplayMap.getLocationFromIndex(p));
            for (let cityPlot of cityPlots) {
                for (let playerPlot of playerPlots) {
                    if (cityPlot.x == playerPlot.x && cityPlot.y == playerPlot.y) {
                        plots.push(playerPlot);
                        break;
                    }
                }
            }
        }
        return plots;
    }

    function calculateEffectiveness(base, effMod) {
        let eff = 1 + effMod / 100;
        // the game says that -50% efficiency is +50% specialist food maintenance
        // i no longer have any idea how it is supposed to work
        return base - (base / eff);
    }
    
    function addYields(yields, yieldType, amount) {
        if (yields[yieldType] == undefined)
            yields[yieldType] = 0;
        
        yields[yieldType] += amount;
    }
    
    function getSpentAttributePoints(attribute) {
        let attributeIndex = GameInfo.Attributes.find(a => a.AttributeType == attribute).$index;
        if (attributeIndex == undefined) {
            return 0;
        }
        
        let sum = 0;
        
        for (var l of AttributeTrees._attributes[attributeIndex].treeGrid._grid) {
            for(var k of l) {
                if (k.isCompleted)
                    sum += 1;
                if (k.isRepeatable)
                    sum += k.repeatedDepth;
            }
        }
        
        return sum;
    }
    
    function getNumWorkers(settlement) {
        return settlement.Workers.GetAllPlacementInfo().reduce((b, s) => s.NumWorkers + b, 0);
    }
    
    function getAssignedResources(settlement) {
        return settlement.Resources.getAssignedResources();
    }
    
    function getCoastalSettlements(settlements, inverse) {
        return settlements.filter(s => GameplayMap.isCoastalLand(s.location.x, s.location.y) - inverse);
    }
    
    function getSettlementsYields(settlements, _yield) {
        if (!YieldTypes[_yield])
            return -100000;

        
        return settlements.map(s => s.Yields?.getYield(YieldTypes[_yield]));
    }
    
    function getOriginallyOwnedSettlements(settlements, inverse){
        return settlements.filter(s => (s.originalOwner == s.owner) - inverse);
    }
    
    function getSettlementsWithBuildingTag(settlements, tag, inverse) {
        return settlements.filter(s => (countBuildingsByTag([s], tag) > 0) - inverse);
    }
    
    function getSettlementsWithBuildingType(settlements, type, inverse) {
        return settlements.filter(s => (countBuildings([s], type) > 0) - inverse);
    }
    
    function getPlayerCapital(playerSettlements, inverse) {
        // i don't know if isCapital gets removed after capturing enemy capital
        // so i will handle it in case it doesn't
        return playerSettlements.filter(c => (c.isCapital && (c.originalOwner == c.owner)) - inverse);
    }
    
    function getPlayerCities(playerSettlements, inverse = false) {
        return playerSettlements.filter(c => !c.isTown - inverse);
    }
    
    function getPlayerTowns(playerSettlements, inverse = false) {
        return playerSettlements.filter(c => c.isTown - inverse);
    }
    
    function getIncreasedYieldsAsText(increasedYields) {
        let text = "";
        for (let [key, value] of Object.entries(increasedYields)) {
            value = Math.floor(value);
            
            //if (value == 0) 
            //    continue;
            
            text += `${value >= 0 ? "+" : ""}${value}<fxs-font-icon data-icon-id="${key}" data-icon-context="icon"></fxs-font-icon>&nbsp; `;
        }
        return text;
    }
    
    function getConstructibleTags(id) {
        let con = Constructibles.getByComponentID(id);
        let building = GameInfo.Constructibles.lookup(con.type);
        return GameInfo.TypeTags.filter(tt => tt.Type == building.ConstructibleType).map(tt => tt.Tag);
    }
    
    function getConstructibleType(id) {
        let con = Constructibles.getByComponentID(id);
        let building = GameInfo.Constructibles.lookup(con.type);
        return building.ConstructibleType;
    }
    
    function countBuildingsByTag(playerCities, tag) {
        let sum = 0;
        for (var city of playerCities) {
            for(var conId of city.Constructibles.getIds()) {
                let con = Constructibles.getByComponentID(conId);
                let building = GameInfo.Constructibles.lookup(con.type);
                let isTagged = GameInfo.TypeTags.filter(tt => tt.Type == building.ConstructibleType && tt.Tag == tag).length > 0;
                if (isTagged) 
                    sum += 1; 
            }
        }
        
        return sum;
    }
    
    function countBuildings(playerCities, buildingType) {
        let sum = 0;
        for (var city of playerCities) {
            for(var conId of city.Constructibles.getIds()) {
                let con = Constructibles.getByComponentID(conId);
                let building = GameInfo.Constructibles.lookup(con.type);
                if (building.ConstructibleType == buildingType) 
                    sum += 1; 
            }
        }
        
        return sum;
    }
    
    overwriteScreenPolicies();
    overwritePolicyChooserItem();
    overwriteInitialization();
};

engine.whenReady.then(initFunction);
