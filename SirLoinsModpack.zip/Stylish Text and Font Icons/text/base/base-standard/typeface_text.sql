--=============================================================================================================
-- Better Text and Font Icons
-- Consistent use of bold typeface for trait text strings
--=============================================================================================================
-- Age
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Age", "[B]Age[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Age'
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Buildings
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Buildings", "[B]Buildings[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Buildings'
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- City/Cities
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "City", "[B]City[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]City'
AND    	Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "Cities", "[B]Cities[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Cities'
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Civics
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Civic Mastery", "[B]Civic Mastery[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Civic Mastery'
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Commanders
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Army Commander", "[B]Army Commander[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Army Commander'
AND    	Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "Fleet Commander", "[B]Fleet Commander[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Fleet Commander'
AND    	Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "Aircraft Commander", "[B]Aircraft Commander[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Aircraft Commander'
AND    	Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "Commander", "[B]Commander[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Commander'
AND		Text NOT LIKE '[B]Army Commander'
AND		Text NOT LIKE '[B]Fleet Commander'
AND		Text NOT LIKE '[B]Aircraft Commander'
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Government
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Government", "[B]Government[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Government'
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Leaders
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Leaders", "[B]Leaders[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Leaders'
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Relationship
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Relationship", "[B]Relationship[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Relationship'
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Settlements
-- Since some text strings have both "Settlement" and "Settlements" at once, had to get a little creative 
-- to not apply the bolding twice to the same word. So, plural first, then singular, specified by space or period.
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Settlements", "[B]Settlements[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Settlements'
AND    	Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "Settlement ", "[B]Settlement [/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		(Text NOT LIKE '[B]Settlement[/B]'
OR		Text NOT LIKE '[B]Settlement [/B]')
AND    	Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "Settlement.", "[B]Settlement[/B].")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		(Text NOT LIKE '[B]Settlement[/B].'
OR		Text NOT LIKE '[B]Settlement [/B].')
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Suzerain
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Suzerain", "[B]Suzerain[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Suzerain'
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Technologies
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Technology Mastery", "[B]Technology Mastery[/B]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND		Text NOT LIKE '[B]Technology Mastery'
AND    	Language = 'en_US';