# Choose Starting Layers

A Civ VII mod that adds options to the game settings menu to choose to show or hide the hexgrid and/or tile yields when the game loads.

## Installation Instructions
1. You can download the latest stable release at [Civfanatics](https://forums.civfanatics.com/resources/[TODO - placeholder]/)
2. Extract to the corresponding mods folder
    * Windows: `%localappdata%\Firaxis Games\Sid Meier's Civilization VII\Mods`
    * MacOS: `~/Library/Application Support/Civilization VII/Mods`
    * Steam Deck\Linux: `~/My Games/Sid Meier's Civilization VII/Mods/`
3. Also requires installation of the [Options API mod](https://forums.civfanatics.com/resources/[TODO - placeholder]/)