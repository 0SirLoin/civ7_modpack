import { ActionActivateEvent } from '/core/ui/components/fxs-activatable.js';
export class FxsTextareaValidateVirtualKeyboard extends CustomEvent {
    constructor(detail) {
        super('fxs-textarea-validate-virtual-keyboard', { bubbles: false, cancelable: true, detail });
    }
}
export class FxsTextarea extends ChangeNotificationComponent {
    constructor() {
        super(...arguments);
        this.textInput = document.createElement('textarea');
        this.textInputListener = this.onTextInput.bind(this);
        this.textInputFocusListener = this.onTextInputFocus.bind(this);
        this.focusListener = this.onFocus.bind(this);
        this.focusOutListener = this.onFocusOut.bind(this);
        this.engineInputListener = this.onEngineInput.bind(this);
        this.handleDoubleClick = this.onDoubleClick.bind(this);
        this.placeholder = "";
        this.isPlaceholderActive = true;
        this.overrideText = true;
        this.showKeyboardOnActivate = true;
    }

    onInitialize() {
        this.Root.classList.add("flow-row", "flex-auto", "items-center", "bg-accent-6", "pointer-events-auto");
        this.textInput.classList.add("py-1", "px-1\\.5", "flex-auto", "border-1", "border-primary-1", "hover\\:border-secondary", "focus\\:border-secondary", "transition-border-color", "bg-transparent");
        this.textInput.setAttribute('consume-input', 'true');
        this.textInput.rows = this.Root.getAttribute('rows') ?? "4";
        this.Root.appendChild(this.textInput);
        this.Root.role = "textarea";
    }
    onAttach() {
        super.onAttach();
        this.Root.addEventListener('mouseenter', this.playSound.bind(this, 'data-audio-focus', 'data-audio-focus-ref'));
        this.textInput.addEventListener("input", this.textInputListener);
        this.textInput.addEventListener("focus", this.textInputFocusListener);
        this.Root.addEventListener("focusout", this.focusOutListener);
        this.Root.addEventListener("focus", this.focusListener);
        this.Root.addEventListener('engine-input', this.engineInputListener);
        this.Root.ondblclick = this.handleDoubleClick;
    }
    onDetach() {
        this.textInput.removeEventListener("input", this.textInputListener);
        this.textInput.removeEventListener("focus", this.textInputFocusListener);
        this.Root.removeEventListener("focusout", this.focusOutListener);
        this.Root.removeEventListener("focus", this.focusListener);
        this.Root.removeEventListener('engine-input', this.engineInputListener);
        super.onDetach();
    }
    onEngineInput(inputEvent) {
        if (inputEvent.detail.status != InputActionStatuses.FINISH) {
            return;
        }
        if (inputEvent.detail.name == 'mousebutton-left' || inputEvent.detail.name == 'accept' || inputEvent.detail.name == 'touch-tap') {
            this.onActivate(inputEvent);
        }
    }
    onDoubleClick() {
        // selection of all characters within the textfield (0 - start index, -1 - end index)
        if (this.textInput.style.pointerEvents != "none") {
            this.textInput.setSelectionRange(0, -1);
        }
    }
    onTextInput() {
        this.overrideText = false;
        this.Root.setAttribute("value", this.value);
    }
    onTextInputFocus(_event) {
        this.tryRemovePlaceholder();
    }
    tryRemovePlaceholder() {
        if (this.isPlaceholderActive) {
            this.textInput.value = "";
        }
        this.isPlaceholderActive = false;
    }
    tryFallbackOnPlaceholderValue() {
        if (this.value != "") {
            // Keep the value entered by the user
            return;
        }
        this.textInput.value = this.placeholder;
        this.isPlaceholderActive = true; // reset
    }
    onFocus() {
        this.textInput.classList.add('border-secondary');
    }
    onFocusOut() {
        this.textInput.classList.remove('border-secondary');
        this.tryFallbackOnPlaceholderValue();
    }
    onActivate(inputEvent) {
        this.playSound('data-audio-activate', 'data-audio-activate-ref');
        this.tryRemovePlaceholder();
        // Register Virtual Keyboard callbacks
        if (UI.canDisplayKeyboard() && this.showKeyboardOnActivate) {
            engine.on("IMEValidated", this.onVirtualKeyboardTextEntered, this);
            engine.on("IMECanceled", this.clearVirtualKeyboardCallbacks, this);
            UI.displayKeyboard(this.value, this.textInput.getAttribute("type") == "password");
        }
        window.dispatchEvent(new SetActivatedComponentEvent(null));
        if (inputEvent) {
            this.Root.dispatchEvent(new ActionActivateEvent(inputEvent.detail.x, inputEvent.detail.y));
            inputEvent.stopPropagation();
            inputEvent.preventDefault();
        }
        this.Root.removeAttribute('activated'); // reset
    }
    onVirtualKeyboardTextEntered(text) {
        // for now text is GenericData<std::string>
        const value = UI.getIMEConfirmationValueLocation() == IMEConfirmationValueLocation.Element ? this.textInput.value : text.data;
        this.Root.setAttribute("value", value);
        this.Root.dispatchEvent(new FxsTextareaValidateVirtualKeyboard({ value }));
        // we the text and IME will close, clear callbacks now
        this.clearVirtualKeyboardCallbacks();
    }
    clearVirtualKeyboardCallbacks() {
        engine.off("IMEValidated", this.onVirtualKeyboardTextEntered, this);
        engine.off("IMECanceled", this.clearVirtualKeyboardCallbacks, this);
    }
    onAttributeChanged(name, oldValue, newValue) {
        switch (name) {
            case "type":
                this.textInput.type = newValue ?? "text";
                break;
            case "value":
                this.isPlaceholderActive = false;
                //we don't want to set the value of the text if we're just typing stuff in
                //if we set this value then the view of the textbox goes to the beginning
                //which causes the view of the text box to not follow the cursor as we type
                if (this.overrideText) {
                    this.textInput.value = newValue ?? "";
                }
                this.overrideText = true;
                if (oldValue != newValue) {
                    this.sendValueChange(new CustomEvent("component-value-changed", {
                        bubbles: true,
                        cancelable: true,
                        detail: {
                            value: newValue,
                        }
                    }));
                }
                break;
            case "placeholder":
                this.placeholder = newValue ?? "";
                if (this.isPlaceholderActive) {
                    this.textInput.value = this.placeholder;
                } // Else: keep the value entered by the user
                break;
            case "activated":
                if (newValue === "true") {
                    this.onActivate();
                }
                break;
            case "maxLength":
                this.textInput.maxLength = Number(newValue);
                break;
            case "enabled":
                this.textInput.readOnly = (newValue == "true");
                this.textInput.style.pointerEvents = (newValue == "true") ? "auto" : "none";
                if (newValue == "true") {
                    this.textInput.focus();
                    this.textInput.setSelectionRange(0, -1);
                }
                break;
            case "has-border":
                this.textInput.classList.toggle("border-1", newValue != "false");
                this.textInput.classList.toggle("border-0", newValue == "false");
                break;
            case 'has-background':
                this.Root.classList.toggle("bg-accent-6", newValue != "false");
                this.Root.classList.toggle("bg-transparent", newValue == "false");
                this.Root.classList.toggle("no-background", newValue == "false");
                break;
            case "show-keyboard-on-activate":
                this.showKeyboardOnActivate = (newValue == "true");
                break;
            case "rows":
                this.textInput.rows = Number(newValue) || 4;
                break;
        }
    }
    get value() {
        return this.textInput.value;
    }
}


//# sourceMappingURL=file:///core/ui/components/fxs-textarea.js.map
