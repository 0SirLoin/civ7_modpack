--=============================================================================================================
-- Stylish Text and Font Icons
--=============================================================================================================
-- Age
-- To avoid catching words that include "age" in them, let's make these replacements for specific phrases
--=============================================================================================================
/*UPDATE 	LocalizedText
SET 	Text = replace(Text, "per Age", "per [icon:NOTIFICATION_AGE_TRANSITION] Age")
WHERE   Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "each Age", "each [icon:NOTIFICATION_AGE_TRANSITION] Age")
WHERE   Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "every Age", "every [icon:NOTIFICATION_AGE_TRANSITION] Age")
WHERE   Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "all Ages", "all [icon:NOTIFICATION_AGE_TRANSITION] Ages")
WHERE   Language = 'en_US';

UPDATE 	LocalizedText -- accommodate typo for Ada's UA
SET 	Text = replace(Text, "each age", "each [icon:NOTIFICATION_AGE_TRANSITION] Age")
WHERE   Language = 'en_US';

UPDATE	LocalizedText
SET		Text = '[BLIST][LI]+1[icon:YIELD_FOOD]Food +1[icon:ATTRIBUTE_WILDCARD]Wildcard Attribute(no spaces)
		[LI]+1[icon:YIELD_FOOD] Food +1[icon:ATTRIBUTE_WILDCARD] Wildcard Attribute (Civ 7 standard)
		[LI]+1 [icon:YIELD_FOOD] Food +1 [icon:ATTRIBUTE_WILDCARD] Wildcard Attribute (Civ 6 standard)'
WHERE	Tag = 'LOC_TRAIT_LEADER_CHARLEMAGNE_ABILITY_DESCRIPTION';*/
--=============================================================================================================--=============================================================================================================
-- ALLIANCES
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Alliance", "[icon:NOTIFICATION_DIPLOMATIC_RESPONSE_REQUIRED] Alliance")
WHERE   Text NOT LIKE	"%[icon:NOTIFICATION_DIPLOMATIC_RESPONSE_REQUIRED] Alliance%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
--=============================================================================================================
-- ATTRIBUTES
--=============================================================================================================
-- Attribute 
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Attribute", "[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Attribute")
WHERE	Text NOT LIKE	"%[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Attribute%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Wildcard Attribute
--------------------------------------------------------------------------------------------------------------- 
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Wildcard [icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Attribute", "[icon:ATTRIBUTE_WILDCARD] Wildcard Attribute")
WHERE	Text NOT LIKE	"%[icon:ATTRIBUTE_WILDCARD] Wildcard Attribute%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';

-- I don't love how these look, so let's hold off for now and allow the default one above to take their place.
---------------------------------------------------------------------------------------------------------------
-- Diplomatic Attribute
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Diplomatic [icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Attribute", "[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Diplomatic Attribute")
WHERE	Text NOT LIKE	"%[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Diplomatic Attribute%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Economic Attribute
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Economic [icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Attribute", "[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Economic Attribute")
WHERE	Text NOT LIKE	"%[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Economic Attribute%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Expansionist Attribute
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Expansionist [icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Attribute", "[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Expansionist Attribute")
WHERE	Text NOT LIKE	"%[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Expansionist Attribute%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Militaristic Attribute
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Militaristic [icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Attribute", "[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Militaristic Attribute")
WHERE	Text NOT LIKE	"%[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Militaristic Attribute%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Scientific Attribute
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Scientific [icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Attribute", "[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Scientific Attribute")
WHERE	Text NOT LIKE	"%[icon:NOTIFICATION_CAN_BUY_ATTRIBUTE_SKILL] Scientific Attribute%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
--=============================================================================================================
-- CAPITAL
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Capital", "[icon:NOTIFICATION_CAPITAL_RECLAIMED] Capital")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_CAPITAL_RECLAIMED] Capital%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
--=============================================================================================================
-- CELEBRATION
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Celebration", "[icon:NOTIFICATION_GOVT_HAPPINESS] Celebration")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_GOVT_HAPPINESS] Celebration%"
AND		(Tag LIKE		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 								-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 								-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'									-- Combat Preview UI text
-- Need all specific description tags to exclude from the Government UI screen
-- TODO: Update if new Governments are added
AND     Tag NOT LIKE 	'%LOC_UI_CELEBRATION_DESC%'						
AND     Tag NOT LIKE	'LOC_GOVERNMENT_CLASSICAL_REPUBLIC_DESCRIPTION'	
AND     Tag NOT LIKE	'LOC_GOVERNMENT_DESPOTISM_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_OLIGARCHY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_FEUDAL_MONARCHY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_PLUTOCRACY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_THEOCRACY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_REVOLUTIONARY_AUTHORITARIANISM_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_CONSTITUTIONAL_MONARCHY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_REVOLUTIONARY_REPUBLIC_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_AUTHORITARIANISM_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_BUREAUCRATIC_MONARCHY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_ELECTIVE_REPUBLIC_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_REVOLUCION_DESCRIPTION'		-- Mexico's unique Government
AND    	Language = 'en_US';
--=============================================================================================================
-- CIVICS
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Civic", "[icon:NOTIFICATION_CHOOSE_CULTURE_NODE] Civic")
WHERE  	Text NOT LIKE	"%[icon:NOTIFICATION_CHOOSE_CULTURE_NODE] Civic%"			
AND		Text NOT LIKE	"%[icon:NOTIFICATION_CULTURE_TREE_REVEALED] Civic%" 
AND		Text NOT LIKE	"%[icon:NOTIFICATION_FREE_CIVIC_AWARDED] Civic%" 
AND		Text NOT LIKE	"%[icon:NOTIFICATION_CIVIC_BOOST_AWARDED] Civic%" 
AND		(Tag LIKE 	'%DESCRIPTION%'								
OR		Tag LIKE 	'%REWARD%'
OR		Tag LIKE 	'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
-- Need all specific description tags to exclude from the Government UI screen
-- TODO: Update if new Governments are added
AND     Tag NOT LIKE 	'%LOC_UI_CELEBRATION_DESC%'						
AND     Tag NOT LIKE	'LOC_GOVERNMENT_CLASSICAL_REPUBLIC_DESCRIPTION'	
AND     Tag NOT LIKE	'LOC_GOVERNMENT_DESPOTISM_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_OLIGARCHY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_FEUDAL_MONARCHY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_PLUTOCRACY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_THEOCRACY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_REVOLUTIONARY_AUTHORITARIANISM_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_CONSTITUTIONAL_MONARCHY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_REVOLUTIONARY_REPUBLIC_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_AUTHORITARIANISM_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_BUREAUCRATIC_MONARCHY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_ELECTIVE_REPUBLIC_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_REVOLUCION_DESCRIPTION'		-- Mexico's unique Government
AND    	Language = 'en_US';
--=============================================================================================================
-- COMMANDERS
--=============================================================================================================
-- Commanders 
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Commander", "[icon:NOTIFICATION_COMMANDER_RESPAWNED] Commander")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_COMMANDER_RESPAWNED] Commander%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Army Commanders
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Army [icon:NOTIFICATION_COMMANDER_RESPAWNED] Commander", "[icon:NOTIFICATION_COMMANDER_RESPAWNED] Army Commander")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_COMMANDER_RESPAWNED] Army Commander%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Fleet Commanders
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Fleet [icon:NOTIFICATION_COMMANDER_RESPAWNED] Commander", "[icon:NOTIFICATION_COMMANDER_RESPAWNED] Fleet Commander")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_COMMANDER_RESPAWNED] Fleet Commander%"
AND		(Tag LIKE		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Aircraft Commanders
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Aircraft [icon:NOTIFICATION_COMMANDER_RESPAWNED] Commander", "[icon:NOTIFICATION_COMMANDER_RESPAWNED] Aircraft Commander")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_COMMANDER_RESPAWNED] Aircraft Commander%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
--=============================================================================================================
-- DIPLOMATIC ACTIONS
--=============================================================================================================
	-- Diplomatic Actions (standalone)
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Diplomatic Action", "[icon:NOTIFICATION_DIPLOMACY_SESSION] Diplomatic Action")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_DIPLOMACY_SESSION] Diplomatic Action%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Endeavors
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Endeavor", "[icon:NOTIFICATION_DIPLOMATIC_ACTION_AWARD] Endeavor")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_DIPLOMATIC_ACTION_AWARD] Endeavor%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Espionage
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Espionage", "[icon:NOTIFICATION_DIPLOMATIC_ACTION_ESPIONAGE] Espionage")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_DIPLOMATIC_ACTION_ESPIONAGE] Espionage%"
AND		(Tag LIKE		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Sanctions
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Sanction", "[icon:NOTIFICATION_DIPLOMATIC_ACTION_LOW] Sanction")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_DIPLOMATIC_ACTION_LOW] Sanction%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
--=============================================================================================================
-- DISTANT LANDS
--=============================================================================================================
-- There's no corresponding Home Lands icon...commenting this out for now.
/*UPDATE 	LocalizedText
SET 	Text = replace(Text, "Distant Land", "[icon:NOTIFICATION_DISCOVER_CONTINENT] Distant Land")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_DISCOVER_CONTINENT] Distant Land%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 				-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';*/
--=============================================================================================================
-- GOVERNMENT
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Government", "[icon:NOTIFICATION_CHOOSE_GOVERNMENT] Government")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_CHOOSE_GOVERNMENT] Government%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 				-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 				-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'					-- Combat Preview UI text
AND     Tag NOT LIKE 	'%LOC_UI_CELEBRATION_DESC%'		-- Government UI text
-- Need all specific description tags to exclude from the Government UI screen
-- TODO: Update if new Governments are added
AND     Tag NOT LIKE 	'%LOC_UI_CELEBRATION_DESC%'						
AND     Tag NOT LIKE	'LOC_GOVERNMENT_CLASSICAL_REPUBLIC_DESCRIPTION'	
AND     Tag NOT LIKE	'LOC_GOVERNMENT_DESPOTISM_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_OLIGARCHY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_FEUDAL_MONARCHY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_PLUTOCRACY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_THEOCRACY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_REVOLUTIONARY_AUTHORITARIANISM_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_CONSTITUTIONAL_MONARCHY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_REVOLUTIONARY_REPUBLIC_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_AUTHORITARIANISM_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_BUREAUCRATIC_MONARCHY_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_ELECTIVE_REPUBLIC_DESCRIPTION'
AND     Tag NOT LIKE	'LOC_GOVERNMENT_REVOLUCION_DESCRIPTION'		-- Mexico's unique Government
AND    	Language = 'en_US';
--=============================================================================================================
-- GREAT WORKS
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Great Work", "[icon:NOTIFICATION_GREAT_WORK_CREATED] Great Work")
WHERE   Text NOT LIKE	"%[icon:NOTIFICATION_GREAT_WORK_CREATED] Great Work%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 				-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
--=============================================================================================================
-- GROWTH
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Growth", "[icon:YIELD_FOOD] Growth")
WHERE   Text NOT LIKE	"%[icon:YIELD_FOOD] Growth%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
--=============================================================================================================
-- NARRATIVE EVENTS
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Narrative Event", "[icon:NOTIFICATION_CHOOSE_NARRATIVE_STORY_DIRECTION] Narrative Event")
WHERE   Text NOT LIKE	"%[icon:NOTIFICATION_CHOOSE_NARRATIVE_STORY_DIRECTION] Narrative Event%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
--=============================================================================================================
-- NATURAL WONDERS
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Natural Wonder", "[icon:NOTIFICATION_DISCOVER_NATURAL_WONDER] Natural Wonder")
WHERE   Text NOT LIKE	"%[icon:NOTIFICATION_DISCOVER_NATURAL_WONDER] Natural Wonder%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
--=============================================================================================================
-- POPULATION
--=============================================================================================================
/*UPDATE 	LocalizedText
SET 	Text = replace(Text, "Population", "[icon:NOTIFICATION_NEW_POPULATION] Population")
WHERE   Text NOT LIKE	"%[icon:NOTIFICATION_NEW_POPULATION] Population%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';*/
--=============================================================================================================
-- PROMOTIONS
--=============================================================================================================
-- Merit Commendation (specific case for Friedrich)
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Merit Commendation", "[icon:NOTIFICATION_UNIT_PROMOTION_AVAILABLE] Merit Commendation")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_UNIT_PROMOTION_AVAILABLE] Merit Commendation%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Initiative Promotion (specific case for Persia)
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Initiative Promotion", "[icon:NOTIFICATION_UNIT_PROMOTION_AVAILABLE] Initiative Promotion")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_UNIT_PROMOTION_AVAILABLE] Initiative Promotion%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- LEVELS
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Level", "[icon:NOTIFICATION_UNIT_PROMOTION_AVAILABLE] Level")
WHERE	Text NOT LIKE	"%[icon:NOTIFICATION_UNIT_PROMOTION_AVAILABLE] Level%"									
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
-- Also exceptions for the meta-progression text
AND     Tag NOT LIKE 	'LOC_PROFILE%' 											
AND     Tag NOT LIKE 	'LOC_METAPROGRESSION_CHALLENGE_MEMENTO_UNLOCKED_TEXT%'		
AND     Tag NOT LIKE 	'LOC_CREATE_GAME%'											
AND   Language = 'en_US';
--=============================================================================================================
-- RELIGION
--=============================================================================================================
-- Right now these are all the same icon despite the different names...maybe they'll update these later.
--=============================================================================================================
-- Pantheon
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Pantheon", "[icon:NOTIFICATION_CHOOSE_PANTHEON] Pantheon")
WHERE	Text NOT LIKE	"%[icon:NOTIFICATION_CHOOSE_PANTHEON] Pantheon%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Religion
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Religion", "[icon:NOTIFICATION_CHOOSE_RELIGION] Religion")
WHERE	Text NOT LIKE	"%[icon:NOTIFICATION_CHOOSE_RELIGION] Religion%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Belief
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Belief", "[icon:NOTIFICATION_CHOOSE_BELIEF] Belief")
WHERE	Text NOT LIKE	"%[icon:NOTIFICATION_CHOOSE_RELIGION] Belief%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
--=============================================================================================================
-- RESOURCES
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Resource", "[icon:NOTIFICATION_DISCOVER_RESOURCE] Resource")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_DISCOVER_RESOURCE] Resource%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
-- Other specific exceptions
AND     Tag NOT LIKE 	'%RESOURCE%'			-- Redundancy in Resource descriptions
AND    	Language = 'en_US';
--=============================================================================================================
-- SPECIALIST
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Specialist", "[icon:NOTIFICATION_CHOOSE_TOWN_PROJECT] Specialist")
WHERE   Text NOT LIKE	"%[icon:NOTIFICATION_CHOOSE_TOWN_PROJECT] Specialist%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
--=============================================================================================================
-- TECHNOLOGIES
--=============================================================================================================
-- Now we can add the font icon
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Tech", "[icon:NOTIFICATION_CHOOSE_TECH] Tech")
WHERE  	Text NOT LIKE	"%[icon:NOTIFICATION_CHOOSE_TECH] Tech%" 
AND 	Text NOT LIKE 	"%[icon:NOTIFICATION_TECH_BOOST_AWARDED] Tech%"
AND 	Text NOT LIKE 	"%[icon:NOTIFICATION_FREE_TECH_AWARDED] Tech%"
AND 	Text NOT LIKE 	"%[icon:NOTIFICATION_TECH_DISCOVERED] Tech%" 
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
--=============================================================================================================
-- TRADITIONS
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Tradition", "[icon:NOTIFICATION_TRADITIONS_AVAILABLE] Tradition")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_TRADITIONS_AVAILABLE] Tradition%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
--=============================================================================================================
-- TRADE ROUTES
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Trade Route", "[icon:NOTIFICATION_TRADE_RESOURCES_GAINED] Trade Route")
WHERE	Text NOT LIKE "%[icon:NOTIFICATION_TRADE_RESOURCES_GAINED] Trade Route%"
AND   	Text NOT LIKE "%[icon:NOTIFICATION_TRADE_ROUTE_PLUNDERED] Trade Route%"
AND   	Text NOT LIKE "%[icon:NOTIFICATION_TRADE_RESOURCES_LOST] Trade Route%"
AND   	Text NOT LIKE "%[icon:NOTIFICATION_TRADE_ROUTE_TO_YOU] Trade Route%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 				-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
--=============================================================================================================
-- UNIT PROPERTIES
--=============================================================================================================
-- HP
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "HP", "[icon:CHAT_HEART] HP")
WHERE   Text NOT LIKE	"%[icon:CHAT_HEART] HP%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Combat Strength
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Combat Strength", "[icon:POK_COMBAT_STRENGTH] Combat Strength")
WHERE   Text NOT LIKE	"%[icon:POK_COMBAT_STRENGTH] Combat Strength%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Defense Strength
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Defense Strength", "[icon:POK_DEFENSE_STRENGTH] Defense Strength")
WHERE   Text NOT LIKE	"%[icon:POK_COMBAT_STRENGTH] Defense Strength%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Defense Preview UI text
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Bombard Strength
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Bombard Strength", "[icon:POK_BOMBARD_STRENGTH] Bombard Strength")
WHERE   Text NOT LIKE	"%[icon:POK_COMBAT_STRENGTH] Bombard Strength%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Bombard Preview UI text
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Charge
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Charge", "[icon:POK_BUILD_CHARGE] Charge")
WHERE   Text NOT LIKE	"%[icon:POK_BUILD_CHARGE] Charge%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Movement
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Movement", "[icon:POK_MOVEMENT] Movement")
WHERE   Text NOT LIKE	"%[icon:POK_MOVEMENT] Movement%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "Sight", "[icon:POK_SIGHT] Sight")
WHERE   Text NOT LIKE	"%[icon:POK_SIGHT] Sight%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
--=============================================================================================================
-- YIELDS: Work in progress
--=============================================================================================================
-- Fixing some missing edgecases for specific strings
UPDATE  LocalizedText
SET     Text = "[icon:YIELD_GOLD] Gold Treasury"
WHERE   Tag = 'LOC_YIELD_GOLD_TREASURY';

UPDATE  LocalizedText
SET     Text = "Accumulated [icon:YIELD_DIPLOMACY] Influence"
WHERE   Tag = 'LOC_YIELD_DIPLOMACY_TREASURY';

-- Let's consistently apply the appropriate yield icons for their matching building types
---------------------------------------------------------------------------------------------------------------
-- Food Buildings
---------------------------------------------------------------------------------------------------------------
/*UPDATE 	LocalizedText
SET 	Text = replace(Text, "Food", "[icon:YIELD_FOOD] Food")
WHERE	Text NOT LIKE 	"%[icon:YIELD_FOOD]%Food%"
AND     Text LIKE 		"%Building%"
AND		(Tag LIKE		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Production Buildings
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Production", "[icon:YIELD_PRODUCTION] Production")
WHERE	Text NOT LIKE 	"%[icon:YIELD_PRODUCTION]%Production%"
AND     Text LIKE 		"%Building%"
AND		(Tag LIKE		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Gold Buildings
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Gold", "[icon:YIELD_GOLD] Gold")
WHERE	Text NOT LIKE 	"%[icon:YIELD_GOLD]%Gold%"
AND     Text LIKE 		"%Building%"
AND		(Tag LIKE		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Science Buildings
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Science", "[icon:YIELD_SCIENCE] Science")
WHERE	Text NOT LIKE 	"%[icon:YIELD_SCIENCE]%Science%"
AND     Text LIKE 		"%Building%"
AND		(Tag LIKE		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Culture Buildings
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Culture", "[icon:YIELD_CULTURE] Culture")
WHERE	Text NOT LIKE 	"%[icon:YIELD_CULTURE]%Culture%"
AND     Text LIKE 		"%Building%"
AND		(Tag LIKE		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Happiness Buildings
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Happiness", "[icon:YIELD_HAPPINESS] Happiness")
WHERE	Text NOT LIKE 	"%[icon:YIELD_HAPPINESS]%Happiness%"
AND     Text LIKE 		"%Building%"
AND		(Tag LIKE		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Military Buildings
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Military", "[icon:POK_COMBAT_STRENGTH] Military")
WHERE	Text NOT LIKE 	"%[icon:POK_COMBAT_STRENGTH]%Military%"
AND     Text LIKE 		"%Building%"
AND		(Tag LIKE		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Diplomacy Buildings
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Diplomacy", "[icon:YIELD_DIPLOMACY] Diplomacy")
WHERE	Text NOT LIKE 	"%[icon:YIELD_DIPLOMACY]%Diplomacy%"
AND     Text LIKE 		"%Building%"
AND		(Tag LIKE		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND   	Language = 'en_US';*/
--=============================================================================================================
-- WAR
--=============================================================================================================
-- Formal War
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Formal War", "[icon:DIPLOMACY_DECLARE_FORMAL_WAR_ICON] Formal War")
WHERE	Text NOT LIKE 	"%[icon:NOTIFICATION_DECLARE_WAR] Formal War%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- Surprise War
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Surprise War", "[icon:DIPLOMACY_DECLARE_SURPRISE_WAR_ICON] Surprise War")
WHERE	Text NOT LIKE 	"%[icon:DIPLOMACY_DECLARE_SURPRISE_WAR_ICON] Surprise War%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- War Support
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, "War Support", "[icon:DIPLOMACY_DECLARE_FORMAL_WAR_ICON] War Support")
WHERE	Text NOT LIKE 	"%[icon:DIPLOMACY_DECLARE_FORMAL_WAR_ICON] War Support%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE	 'LOC_ABILITY%'			-- Combat Preview UI text
AND    	Language = 'en_US';
--=============================================================================================================
-- WONDERS
--=============================================================================================================
-- Add the Wonder font icon exclusively for the Associated Wonder bonus part of Civ abilities
UPDATE 	LocalizedText
SET 	Text = replace(Text, "towards constructing the [B]", "towards constructing the [B][icon:CITY_WONDERS_LIST] ")
WHERE	Text NOT LIKE 	"%[icon:CITY_WONDERS_LIST]%"
AND     Text NOT LIKE   "%towards constructing%uilding%"
AND     Text NOT LIKE   "%towards constructing%onders%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
AND    	Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "towards constructing [B]", "towards constructing [B][icon:CITY_WONDERS_LIST] ")
WHERE	Text NOT LIKE 	"%[icon:CITY_WONDERS_LIST]%"
AND     Text NOT LIKE   "%towards constructing%uilding%"
AND     Text NOT LIKE   "%towards constructing%onders%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
AND    	Language = 'en_US';


-- Hardcoded fixes for edge cases in which "constructing Buildings" is part of the general ability text. 
-- Britain + Battersea
UPDATE 	LocalizedText
SET 	Text = replace(Text, "towards constructing [B]Battersea Power Station[/B]", "towards constructing [B][icon:CITY_WONDERS_LIST] Battersea Power Station[/B]")
WHERE	Text NOT LIKE 	"%[icon:CITY_WONDERS_LIST]%"
AND     Text NOT LIKE   "%towards constructing%uilding%"
AND     Text NOT LIKE   "%towards constructing%onders%"
AND		(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
AND    	Language = 'en_US';