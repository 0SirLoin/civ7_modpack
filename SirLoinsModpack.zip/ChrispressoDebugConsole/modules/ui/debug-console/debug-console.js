import * as globals from '/base-standard/maps/map-globals.js';
import Panel from '/core/ui/panel-support.js';
import { InputEngineEvent, InputEngineEventName } from '/core/ui/input/input-support.js';
import { MustGetElement } from '/core/ui/utilities/utilities-dom.js';
import FocusManager from '/core/ui/input/focus-manager.js';
import ContextManager from '/core/ui/context-manager/context-manager.js';
import ViewManager from '/core/ui/views/view-manager.js';


// Bring in completion stuff
import { CompletionItem, globalCompletions } from './completions.js';

// Bring in some stuff specifically for the console
import { UnitFlagManager } from '/base-standard/ui/unit-flags/unit-flag-manager.js';
import { ComponentID } from '/core/ui/utilities/utilities-component-id.js';

window.globals = globals;


// We need a custom replacer for self-referencing json objects
//https://stackoverflow.com/questions/10392293/stringify-convert-to-json-a-javascript-object-with-circular-reference
function refReplacer() {
    let m = new Map(), v= new Map(), init = null;
  
    return function(field, value) {
        let p = m.get(this) + (Array.isArray(this) ? `[${field}]` : '.' + field); 
        let isComplex = value===Object(value)
        
        if (isComplex) m.set(value, p);  
        
        let pp = v.get(value)||'';
        let path = p.replace(/undefined\.\.?/,'');
        let val = pp ? `#REF:${pp[0]=='[' ? '$':'$.'}${pp}` : value;
        
        !init ? (init=value) : (val===init ? val="#REF:$" : 0);
        if(!pp && isComplex) v.set(value, path);
        
        return val;
    }
}


class DebugConsolePanel extends Panel {
    // track where the console was last - preserves between closing/opening since we push/pop
    static lastPosition = { x: null, y: null };
    static lastDimensions = { width: null, height: null };

    static knownGlobals = new Set(Object.keys(window));
    static knownLocals = new Set();

    static commandHistory = [];
    static replContext = {};  // Persistent context for REPL
    static historyPosition = -1;

    constructor(root) {
        super(root);
        this.focusTimeout = null;
        this.animateInType = this.animateOutType = 7; // AnchorType.RelativeToRight
        this.onEngineInputListener = this.onEngineInput.bind(this);
        this.keyDownListener = this.onKeyDown.bind(this);
        this.completions = [];
        this.selectedCompletionIndex = -1;

        this.historyPosition = -1;
        this._clipboard = '';

        // For some reason KeyboardEvent.shiftKey and other modifiers don't get set.
        // Instead, just look at the keycode during down/up events.
        this.shiftKey = false;
        this.ctrlKey = false;
        this.metaKey = false;
        this.keyUpListener = this.onKeyUp.bind(this);

        // Create autocomplete popup
        this.autocompletePopup = document.createElement('div');
        this.autocompletePopup.classList.add('debug-console-autocomplete');
        this.Root.appendChild(this.autocompletePopup);
        this.hideAutoComplete(); // Initially hidden

        this.isVisible = true;

        this.isDragging = false;
        this.isResizing = false;
        this.dragOffset = { x: 0, y: 0 };
        
    }

    onInitialize() {
        this.output = MustGetElement("#console-output", this.Root);
        this.input = MustGetElement("#console-input", this.Root);
        const clearButton = MustGetElement(".clear-button", this.Root);
        clearButton.addEventListener('click', () => this.clearConsole());
    }

    initializeDragAndResize() {
        const header = this.Root.querySelector('.header');
        
        // Create resize handle
        this.resizer = document.createElement('div');
        this.resizer.classList.add('resizer');
        this.Root.appendChild(this.resizer);

        // Drag handlers
        const onDragStart = (e) => {
            if (!header.contains(e.target)) return;
            
            this.isDragging = true;
            const rect = this.Root.getBoundingClientRect();
            this.dragOffset = {
                x: e.clientX - rect.left,
                y: e.clientY - rect.top
            };
            
            e.preventDefault();
            e.stopPropagation();
        };

        const onDragMove = (e) => {
            if (!this.isDragging && !this.isResizing) return;

            if (this.isDragging) {
                const x = e.clientX - this.dragOffset.x;
                const y = e.clientY - this.dragOffset.y;
                
                this.Root.style.left = `${x}px`;
                this.Root.style.top = `${y}px`;
            }

            if (this.isResizing) {
                const rect = this.Root.getBoundingClientRect();
                const width = Math.max(700, e.clientX - rect.left);
                const height = Math.max(350, e.clientY - rect.top);

                this.input.style.width = `${width - 18}px`;
                
                this.Root.style.width = `${width}px`;
                this.Root.style.height = `${height}px`;
            }

            e.preventDefault();
            e.stopPropagation();
        };

        const onDragEnd = () => {
            this.isDragging = false;
            this.isResizing = false;
        };

        // Resize handlers
        const onResizeStart = (e) => {
            if (!e.target.classList.contains('resizer')) return;
            
            this.isResizing = true;
            e.preventDefault();
            e.stopPropagation();
        };

        // Add event listeners
        header.addEventListener('mousedown', onDragStart);
        this.resizer.addEventListener('mousedown', onResizeStart);
        document.addEventListener('mousemove', onDragMove);
        document.addEventListener('mouseup', onDragEnd);

        // Store cleanup function
        this.cleanupDragAndResize = () => {
            header.removeEventListener('mousedown', onDragStart);
            this.resizer.removeEventListener('mousedown', onResizeStart);
            document.removeEventListener('mousemove', onDragMove);
            document.removeEventListener('mouseup', onDragEnd);
            this.resizer.remove();
        };
    }

    clearConsole() {
        // Clear 
        this.output.innerHTML = '';
        DebugConsolePanel.commandHistory = [];
        this.historyPosition = -1;
        this.input.value = '';
        this.hideAutoComplete();
        this.input.focus();
    }

    // Get any possible completions for the current input
    getCompletionsForInput(text) {
        // Get cursor position and text up to cursor
        const cursorPos = this.input.selectionStart;
        const textToCursor = text.substring(0, cursorPos);
        
        // Find last non-identifier character (including parentheses, operators, etc)
        const lastDelimiterMatch = textToCursor.match(/[^a-zA-Z0-9_.$]+([a-zA-Z0-9_.$]*)$/);
        const relevantText = lastDelimiterMatch ? 
            lastDelimiterMatch[1] : 
            textToCursor;
    
        // If we have a dot, handle property completions
        if (relevantText.includes('.')) {
            const lastDotIndex = relevantText.lastIndexOf('.');
            const objPath = relevantText.substring(0, lastDotIndex);
            const propPrefix = relevantText.substring(lastDotIndex + 1);
            
            const obj = globalCompletions[objPath];
            if (obj && obj.properties) {
                return Object.entries(obj.properties)
                    .filter(([key]) => key.toLowerCase().startsWith(propPrefix.toLowerCase()))
                    .map(([key, value]) => ({
                        text: key,
                        properties: value.properties,
                        params: value.params,
                        returns: value.returns,
                        description: value.description,
                        type: value.type
                    }));
            }
            return [];
        }
    
        // Show filtered top-level completions based on text at cursor
        return Object.entries(globalCompletions)
            .filter(([key]) => key.toLowerCase().startsWith(relevantText.toLowerCase()))
            .map(([key, value]) => ({
                text: key,
                properties: value.properties,
                params: value.params,
                returns: value.returns,
                description: value.description,
                type: value.type
            }));
    }

    showAutoComplete() {
        // Position popup below input
        const inputRect = this.input.getBoundingClientRect();
        this.autocompletePopup.style.top = `${inputRect.bottom}px`;
        this.autocompletePopup.style.left = `${inputRect.left}px`;
        this.autocompletePopup.style.display = 'block';
    }

    navigateHistory(direction) {
        if (DebugConsolePanel.commandHistory.length === 0) return;

        // Hide autocomplete if it's visible
        if (this.autocompletePopup.style.display === 'block') {
            this.hideAutoComplete();
        }

        // Update history position
        this.historyPosition = (this.historyPosition === -1) 
            ? (direction > 0 ? 0 : DebugConsolePanel.commandHistory.length - 1)
            : this.historyPosition + direction;

        // Clamp history position
        if (this.historyPosition >= DebugConsolePanel.commandHistory.length) {
            this.historyPosition = 0;
        } else if (this.historyPosition < 0) {
            this.historyPosition = DebugConsolePanel.commandHistory.length - 1;
        }

        // Get command from history
        const command = DebugConsolePanel.commandHistory[this.historyPosition];
        this.input.value = command
        
        // Move cursor to end
        requestAnimationFrame(() => {
            const len = this.input.value.length;
            this.input.setSelectionRange(len, len);
        });
    }

    hideAutoComplete() {
        this.autocompletePopup.style.display = 'none';
        this.selectedCompletionIndex = -1;
    }

    // Update auto complete
    updateAutoComplete(text) {
        this.completions = this.getCompletionsForInput(text);
        
        if (this.completions.length === 0) {
            this.hideAutoComplete();
            return;
        }
    
        // Update popup content
        this.autocompletePopup.innerHTML = '';
        this.completions.forEach((completion, index) => {
            const item = document.createElement('div');
            item.classList.add('debug-console-autocomplete-item');
            if (index === this.selectedCompletionIndex) {
                item.classList.add('selected');
            }
            
             // Create name container
            const nameContainer = document.createElement('div');
            
            // Add function name
            const name = document.createElement('span');
            name.textContent = completion.text;
            name.classList.add('completion-name');
            nameContainer.appendChild(name);
            
            // Add parameters if it's a function
            if (completion.type == 'function') {
                const params = document.createElement('span');
                params.classList.add('completion-params');
                                
                // Handle undefined params/returns
                const paramText = completion.params || 'none';
                const returnText = completion.returns || 'any';
                
                params.textContent = `(${paramText === 'none' ? '' : paramText}) → ${returnText}`;
                nameContainer.appendChild(params);
            }
            
            // Create description
            const desc = document.createElement('span');
            desc.textContent = completion.description;
            desc.classList.add('completion-description');
            
            // Add all elements to item
            item.appendChild(nameContainer);
            // item.appendChild(type);
            item.appendChild(desc);
            
            this.autocompletePopup.appendChild(item);
        });
    
        // Position popup to the left of debug console
        const debugConsole = this.Root;
        const debugConsoleRect = debugConsole.getBoundingClientRect();
        
        // Configure popup styles
        this.autocompletePopup.style.position = 'fixed';
        this.autocompletePopup.style.display = 'block';
        this.autocompletePopup.style.visibility = 'visible';
        
        // Match debug console height and position
        this.autocompletePopup.style.height = `${debugConsoleRect.height}px`;
        this.autocompletePopup.style.right = `${window.innerWidth - debugConsoleRect.left + 10}px`; // 10px gap
        this.autocompletePopup.style.bottom = `${window.innerHeight - debugConsoleRect.bottom}px`;
        
        // Reset selection index when showing new completions
        this.selectedCompletionIndex = 0;
        this.updateCompletionHighlight();
    }

    // Store output in history
    addToHistory(text) {
        if (!text.trim()) return;

        const command = text.replace(/^>\s/, '');

         // Don't store duplicate of last command
         if (DebugConsolePanel.commandHistory.length > 0 && 
            DebugConsolePanel.commandHistory[DebugConsolePanel.commandHistory.length - 1] === command) {
            return;
        }

        DebugConsolePanel.commandHistory.push(command);
    }

    paste() {
        if (!this.input) return;
        const cursorPos = this.input.selectionStart;
        var textBefore = this.input.value.substring(0, cursorPos);
        if (textBefore.length == 1 && textBefore == '\n') {
            textBefore = '';
        }
        const textAfter = this.input.value.substring(this.input.selectionEnd);
        
        // Insert clipboard content at cursor position
        const newValue = textBefore + this._clipboard + textAfter;
        this.input.value = newValue;
        
        // Move cursor after pasted content
        const newCursorPos = cursorPos + this._clipboard.length;
        this.input.setSelectionRange(newCursorPos, newCursorPos);
    }

    getCaret(el) { 
        // https://stackoverflow.com/questions/6014702/how-do-i-detect-shiftenter-and-generate-a-new-line-in-textarea
        if (el.selectionStart) { 
            return el.selectionStart; 
        } else if (document.selection) { 
            // FocusManager.setFocus(this.input);
            // this.input.focus();

            var r = document.selection.createRange(); 
            if (r == null) { 
                return 0; 
            } 

            var re = el.createTextRange(), 
                rc = re.duplicate(); 
            re.moveToBookmark(r.getBookmark()); 
            rc.setEndPoint('EndToStart', re); 

            return rc.text.length; 
        }  
        return 0; 
    }

    // Handle key events for the text input.
    onKeyDown(e) {  
        // Handle modifiers
        if (e.keyCode == 16) this.shiftKey = true;
        if (e.keyCode == 17) this.ctrlKey = true;
        if (e.keycode == 91) this.metaKey = true;

         // Handle shift + arrow keys for history navigation - irrelevant of autocomplete
         if (this.shiftKey) {
            switch (e.keyCode) {
                case 38: // Up arrow
                    e.preventDefault();
                    e.stopPropagation();
                    this.navigateHistory(-1);
                    return false;

                case 40: // Down arrow
                    e.preventDefault();
                    e.stopPropagation();
                    this.navigateHistory(1);
                    return false;
            }
        }

        //handle ctrl/meta + v for paste 
        if ((this.ctrlKey || this.metaKey) && e.keyCode == 86) {
            e.preventDefault();
            e.stopPropagation();
            this.paste();
            return false;
        }

        //handle ctrl +d for hiding the console
        if (this.ctrlKey && e.keyCode == 68) {
            e.preventDefault();
            e.stopPropagation();
            this.close();
            return false;
        }
        
        const handleShiftEnter = () => {
            return false;
        };
  
        // Handle events when the autocomplete popup is visible
        if (this.autocompletePopup.style.display === 'block') {
            switch (e.keyCode) {
                case 9:  // Tab
                    e.preventDefault();
                    e.stopPropagation();
                    this.applySelectedCompletion();
                    this.hideAutoComplete();
                    // this.input.focus();
                    return false;

                case 13: // enter
                    // e.stopPropagation();
                    if (this.shiftKey) {
                        return handleShiftEnter();
                    }
                    // e.preventDefault();
                    // this.executeCommand(this.input.getAttribute('value'));
                    this.executeCommand(this.input.value);
                    return false;
    
                case 38: // Arrow Up
                    e.preventDefault();
                    e.stopPropagation();
                    this.cycleCompletion(-1);
                    return false;
    
                case 40: // Arrow Down
                    e.preventDefault();
                    e.stopPropagation();
                    this.cycleCompletion(1);
                    return false;
                
                case 27: // Escape
                    e.preventDefault();
                    e.stopPropagation();
                    this.hideAutoComplete();
                    return false;
            }
        }
        // Handle events when the autocomplete popup is hidden
        else { 
            switch (e.keyCode) {
                case 9: // Tab
                    e.preventDefault();
                    e.stopPropagation();
                    const text = this.input.value || '';
                    this.updateAutoComplete(text);
                    if (this.completions.length > 0) {
                        this.selectedCompletionIndex = 0;
                        this.updateCompletionHighlight();
                    }
                    return false;
                
                case 13: // enter
                    if (this.shiftKey) {
                        return handleShiftEnter();
                    }
                    this.executeCommand(this.input.value);
                    return false;
                default:
                    return true
            }
        }
        return true;
    }

    onKeyUp(e) {
        if (e.keyCode == 16) this.shiftKey = false;
        if (e.keyCode == 17) this.ctrlKey = false;
        if (e.keycode == 91) this.metaKey = false;
        return false;
    }

    onAttach() {
        super.onAttach();
        this.initializeDragAndResize();
        
        // Restore last position if it exists
        if (DebugConsolePanel.lastPosition.x !== null) {
            this.Root.style.left = `${DebugConsolePanel.lastPosition.x}px`;
            this.Root.style.top = `${DebugConsolePanel.lastPosition.y}px`;
        }

        // Restore last dimensions if they exist
        if (DebugConsolePanel.lastDimensions.width !== null) {
            this.Root.style.width = `${DebugConsolePanel.lastDimensions.width}px`;
            this.Root.style.height = `${DebugConsolePanel.lastDimensions.height}px`;
            this.input.style.width = `${DebugConsolePanel.lastDimensions.width - 18}px`;
        }

        document.getElementById('console-input').autofocus = true;
        document.getElementById('console-input').focus();

        // For whatever reason if you click in the input while it has focus, you can't type.
        // This is a workaround to prevent that.
        this.input.addEventListener('mousedown', (e) => {
            if (document.activeElement === this.input) {
                e.preventDefault(); // Prevent default behavior if already focused
        
                this.input.blur();
                setTimeout(() => {
                    this.input.focus();
                }, 50);
            } else {
                this.input.focus();
            }
        });

        this.input.addEventListener('keydown', this.keyDownListener);
        this.input.addEventListener('keyup', this.keyUpListener);
        this.Root.addEventListener(InputEngineEventName, this.onEngineInputListener);
    }

    onDetach() {
        // Store current position before detaching
        const rect = this.Root.getBoundingClientRect();
        DebugConsolePanel.lastPosition = {
            x: rect.left,
            y: rect.top
        };
        
        // Store current dimensions
        DebugConsolePanel.lastDimensions = {
            width: rect.width,
            height: rect.height
        };


        if (this.cleanupDragAndResize) {
            this.cleanupDragAndResize();
        }
        this.input.removeEventListener('keydown', this.keyDownListener);
        this.input.removeEventListener('keyup', this.keyUpListener);
        this.Root.removeEventListener(InputEngineEventName, this.onEngineInputListener);
    }

    onEngineInput(inputEvent) {
        if (inputEvent.detail.status != InputActionStatuses.FINISH) return true;

        switch (inputEvent.detail.name) {
            case 'keyboard-escape':
            case 'chrispresso-debug-console':
                if (this.isVisible) {
                    this.close();
                    inputEvent.stopImmediatePropagation();
                    inputEvent.preventDefault();
                    return false;
                }
                
            case 'keyboard-return':
            case 'keyboard-enter':
                const text = this.input.value;
                if (text) {
                    this.executeCommand(text);
                }
                inputEvent.stopImmediatePropagation();
                inputEvent.preventDefault();
                return false;
        }
        return true;
    }

    // Evaluate a piece of code against the global context
    evaluate(code) {
        try {
            const result = (0, eval)(code);
            return result;
        } catch(err) {
            return err.message;
        }
    }
    
    addMinimizeHandler(element) {
        element.addEventListener('mousedown', (e) => {
            // Check for right click (button 2)
            if (e.button === 2) {
                console.error("right click");
                e.preventDefault();
                e.stopPropagation();
                
                if (element.classList.contains('minimized')) {
                    // Restore
                    element.classList.remove('minimized');
                    element.style.height = element.dataset.originalHeight;
                } else {
                    // Minimize
                    element.dataset.originalHeight = element.style.height || 'auto';
                    element.classList.add('minimized');
                }
            }
        });
    
        // Still prevent context menu
        element.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            e.stopPropagation();
            return false;
        });
    }

    executeCommand(command) {
        command = command.replace(/^\s+|\s+$/g, ''); // Trim whitespace
        
        // Add command to history
        this.addToHistory(command);

        this.historyPosition = -1; // Reset position
        
        // Create command element with click handler
        const cmdElement = document.createElement('div');
        cmdElement.classList.add('console-output-entry');
        cmdElement.style.color = '#88ff88';
        cmdElement.style.whiteSpace = 'pre';
        cmdElement.textContent = '> ' + command;
        cmdElement.addEventListener('click', () => {
            cmdElement.classList.add('highlight');
            cmdElement.focus();
            this._clipboard = command;
            console.error("Clipboard: ", this._clipboard);
            setTimeout(() => {
                cmdElement.classList.remove('highlight');
            }, 300);
        });

        // right click toggle
        this.addMinimizeHandler(cmdElement);

        this.output.appendChild(cmdElement);

        try {
            const beforeGlobals = new Set(Object.keys(window));
            const evalResult = this.evaluate(command);
            const afterGlobals = new Set(Object.keys(window));
            const newGlobals = [...afterGlobals].filter(key => 
                !beforeGlobals.has(key) && 
                !DebugConsolePanel.knownGlobals.has(key)
            );
            
            if (newGlobals.length > 0) {
                // Add each new global to completions
                newGlobals.forEach(key => {
                    DebugConsolePanel.knownGlobals.add(key);
                    globalCompletions[key] = new CompletionItem(key, 'attribute', {}, 
                        `Console-created global (${typeof window[key]})`, 
                        '', 
                        typeof window[key]
                    );
                });
            }

            const resultElement = document.createElement('div');
            resultElement.classList.add('console-output-entry');
            resultElement.style.whiteSpace = 'pre';
            var jsonText = '';
            try {
                jsonText = JSON.stringify(evalResult, null, 2);
            } catch(error) {
                jsonText = JSON.stringify(evalResult, refReplacer(), 2);
            }
            if (jsonText) {
                jsonText = jsonText.replace(/^\n+|\n+$/g, '');
            }
            resultElement.textContent = '< ' + jsonText;
            resultElement.addEventListener('click', () => {
                resultElement.classList.add('highlight');
                resultElement.focus();
                this._clipboard = jsonText;
                console.error("Clipboard: ", this._clipboard);
                setTimeout(() => {
                    resultElement.classList.remove('highlight');
                }, 300);
            });

            // Right click to toggle minimize
            this.addMinimizeHandler(resultElement);

            this.output.appendChild(resultElement);
            resultElement.scrollTop = resultElement.scrollHeight;

        } catch (error) {
            const errorElement = document.createElement('div');
            errorElement.classList.add('console-output-entry');
            errorElement.style.color = '#ff8888';
            errorElement.style.whiteSpace = 'pre';
            errorElement.textContent = '< Error: ' + error.message;
            errorElement.addEventListener('click', () => {
                errorElement.classList.add('highlight');
                errorElement.focus();
                this._clipboard = error.message;
                console.error("Clipboard: ", this._clipboard);
                setTimeout(() => {
                    errorElement.classList.remove('highlight');
                }, 300); // Remove highlight after 300ms
            });

            // Right click to toggle minimize
            this.addMinimizeHandler(errorElement);

            this.output.appendChild(errorElement);
        }
    
        this.input.value = '';

        requestAnimationFrame(() => {
            this.input.setSelectionRange(0, 0);
            this.input.scrollTop = 0; // Reset scroll position of textarea
        });
    }

    close() {
        ContextManager.pop("debug-console-panel");
    }

    cycleCompletion(direction) {
        if (this.completions.length === 0) return;
    
        // Update selected index with wrapping
        this.selectedCompletionIndex += direction;
        
        // Wrap around
        if (this.selectedCompletionIndex >= this.completions.length) {
            this.selectedCompletionIndex = 0;
        } else if (this.selectedCompletionIndex < 0) {
            this.selectedCompletionIndex = this.completions.length - 1;
        }
    
        this.updateCompletionHighlight();
    }

    updateCompletionHighlight() {
        // Remove highlight from all items
        const items = this.autocompletePopup.querySelectorAll('.debug-console-autocomplete-item');
        items.forEach(item => item.classList.remove('selected'));
    
        // Add highlight to selected item
        if (this.selectedCompletionIndex >= 0 && this.selectedCompletionIndex < items.length) {
            const selectedItem = items[this.selectedCompletionIndex];
            selectedItem.classList.add('selected');
            
            // Calculate scroll position to keep selected item in view
            const popupRect = this.autocompletePopup.getBoundingClientRect();
            const itemRect = selectedItem.getBoundingClientRect();
            
            // Check if item is outside visible area
            if (itemRect.bottom > popupRect.bottom) {
                this.autocompletePopup.scrollTop += (itemRect.bottom - popupRect.bottom);
            } else if (itemRect.top < popupRect.top) {
                this.autocompletePopup.scrollTop -= (popupRect.top - itemRect.top);
            }
        }
    }

    applySelectedCompletion() {
        if (this.selectedCompletionIndex < 0 || !this.completions[this.selectedCompletionIndex]) return;
    
        const currentValue = this.input.value || '';
        const cursorPos = this.input.selectionStart;
        const textToCursor = currentValue.substring(0, cursorPos);
        
        // Find last non-identifier character
        const lastDelimiterMatch = textToCursor.match(/[^a-zA-Z0-9_.$]+([a-zA-Z0-9_.$]*)$/);
        const startIndex = lastDelimiterMatch ? 
            textToCursor.length - lastDelimiterMatch[1].length : 
            0;
        
        // Get the text after cursor
        const textAfterCursor = currentValue.substring(cursorPos);
        
        // Get the completion text
        let completion = this.completions[this.selectedCompletionIndex].text;
        
        // If we're completing a property (has a dot), preserve the parent object
        if (textToCursor.includes('.')) {
            const lastDotIndex = textToCursor.lastIndexOf('.');
            const parentObj = textToCursor.substring(startIndex, lastDotIndex + 1);
            completion = parentObj + completion;
        }
        
        // Create new value by combining parts
        const newValue = currentValue.substring(0, startIndex) + completion + textAfterCursor;
    
        // Update input
        this.input.value = newValue;
        
        // Set cursor position after the completion
        const newCursorPos = startIndex + completion.length;
        requestAnimationFrame(() => {
            this.input.setSelectionRange(newCursorPos, newCursorPos);
        });
    
        // Only hide if we're not about to show nested completions
        if (!completion.endsWith('.')) {
            this.hideAutoComplete();
        } else {
            // Show nested completions immediately
            this.updateAutoComplete(newValue);
        }
    }

}


Controls.define('debug-console-panel', {
    createInstance: DebugConsolePanel,
    description: "debug console cdc",
    classNames: ['debug-console', 'allowCameraMovement', 'ui-layer'],
    styles: ['fs://game/chrispresso-debug-console/ui/debug-console/debug-console.css'],
    content: ['fs://game/chrispresso-debug-console/ui/debug-console/debug-console.html']
});


// handler for the main input event
function handleInput(event) {
    if (event.detail.status == InputActionStatuses.START && event.detail.name == "chrispresso-debug-console") {
        // Toggle panel visibility using ContextManager
        if (!ContextManager.getTarget("debug-console-panel")) {
            ContextManager.push("debug-console-panel", {
                singleton: true,
                createMouseGuard: true,
                attributes: {
                    shouldDarken: true,
                },
                parentId: 'GameContainer'
            });

            // Use requestAnimationFrame to ensure the panel is created before focusing
            requestAnimationFrame(() => {
                const input = document.getElementById('console-input');
                if (input) {
                    input.focus();
                    input.setSelectionRange(0, 0);
                }
            });
        }
        
        event.stopPropagation();
        event.preventDefault();
        return false;
    }
    return true;
}

// Only grab certain "globals" once the engine is ready
engine.whenReady.then(() => {
    window.UnitFlagManager = UnitFlagManager;
    window.ComponentID = ComponentID;
});

window.addEventListener('engine-input', handleInput);


console.log('debug-console.js loaded');


//# sourceMappingURL=file:///base-standard/ui/debug-console/debug-console.js.map

