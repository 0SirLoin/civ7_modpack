import TooltipManager from '/core/ui/tooltips/tooltip-manager.js';
import {getConstructibleEffectStrings} from '/core/ui/utilities/utilities-core-textprovider.js'

class CityDetailsBuildingTooltipType {
    constructor() {
        this.target = null;
        // #region Element References
        this.container = document.createElement('fxs-tooltip');
        this.description = document.createElement('p');
        this.header = document.createElement('div');
        this.baseYield = document.createElement('div');
        this.constructibleName = document.createElement('div');
        this.constructibleBonusContainer = document.createElement('div');
        this.container.className = 'flex flex-col w-96 font-body text-md text-accent-2';
        this.container.dataset.showBorder = 'false';
        this.header.className = 'font-title text-secondary text-center uppercase tracking-100';
        this.constructibleName.className = 'font-title text-sm uppercase';
        this.baseYield.className = 'mb-1';
        this.constructibleBonusContainer.className = 'mb-1';
        this.container.append(this.header, this.constructibleName, this.baseYield, this.constructibleBonusContainer, this.description);
    }

    getHTML() {
        return this.container;
    }

    reset() {
    }

    isUpdateNeeded(target) {
        const targetItem = target.closest('.constructible-entry');
        if (!targetItem) {
            this.target = null;
            // The target nor any of its parents are buildings. Skip update.
            return false;
        }

        const constructibleData = JSON.parse(targetItem.dataset?.constructibleData);
        if (!constructibleData) {
            this.target = null;
            return false;
        }

        if (!constructibleData.type || constructibleData.type === this.definition?.ConstructibleType) {
            return false;
        }
        const definition = GameInfo.Constructibles.lookup(constructibleData.type);
        if (!definition) {
            return false;
        }
        this.target = targetItem;
        this.definition = definition;
        return true;
    }

    update() {
        const cityID = UI.Player.getHeadSelectedCity();
        if (!cityID) {
            return;
        }

        const city = Cities.get(cityID);
        if (!city) {
            return;
        }
        const definition = this.definition;
        if (!definition) {
            return;
        }
        this.header.setAttribute('data-l10n-id', definition.Name);

        const {baseYield, adjacencies, effects} = getConstructibleEffectStrings(definition.ConstructibleType, city);
        if (baseYield) {
            this.baseYield.innerHTML = Locale.stylize(baseYield);
        } else {
            this.baseYield.innerHTML = '';
        }
        this.constructibleBonusContainer.innerHTML = '';
        const bonuses = [...adjacencies, ...effects];
        for (let index = 0; index < bonuses.length; index++) {
            const bonusText = document.createElement('p');
            this.constructibleBonusContainer.appendChild(bonusText);
            bonusText.setAttribute('data-l10n-id', bonuses[index]);
        }

        if (this.definition?.Tooltip) {
            this.description.setAttribute('data-l10n-id', this.definition.Tooltip);
            this.description.classList.remove('hidden');
        } else {
            this.description.classList.add('hidden');
        }
    }

    isBlank() {
        return !this.definition;
    }
}

export class CityDetailsBuildingDecorator {
    constructor(cmp) {
        this.cmp = cmp
    }

    beforeAttach() {
    }

    afterAttach() {
        if (!this.cmp || !this.cmp.Root) {
            return
        }

        const buildings = this.cmp.Root.querySelectorAll(".buildings-list .constructible-entry")
        buildings.forEach((building) => {
            building.setAttribute('data-tooltip-anchor', 'left');
            building.setAttribute('data-tooltip-style', 'city-details-building-tooltip');
        })

        const wonders = this.cmp.Root.querySelectorAll(".wonders-list .constructible-entry")
        wonders.forEach((wonders) => {
            wonders.setAttribute('data-tooltip-anchor', 'left');
            wonders.setAttribute('data-tooltip-style', 'city-details-building-tooltip');
        })
    }

    beforeDetach() {
    }

    afterDetach() {
    }

    onAttributeChanged(name, prev, next) {
    }
}

TooltipManager.registerType('city-details-building-tooltip', new CityDetailsBuildingTooltipType());
Controls.decorate('panel-city-details', (cmp) => new CityDetailsBuildingDecorator(cmp));