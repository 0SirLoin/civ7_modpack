--=============================================================================================================
-- Stylish Text and Font Icons
--=============================================================================================================
-- Updated text without the Combat Strength font icon for the correspdonding Modifier Strings data updates.
--=============================================================================================================
INSERT OR REPLACE INTO LocalizedText
		(Tag,				Text,		Language)
SELECT	'POK_STFI' ||Tag,	Text,		'en_US'
FROM	LocalizedText
WHERE   Tag LIKE 'LOC_TRADITION%'
AND     Tag NOT LIKE '%PREVIEW%' 		-- should catch all cases where a Tradition was appropriately given a separate Preview text string
AND		Text LIKE '%Combat Strength%';

-- Null the Combat Strength icon
UPDATE 	LocalizedText
SET 	Text = replace(Text, "[icon:POK_COMBAT_STRENGTH]", "")
WHERE   Tag LIKE 'POK_STFI%'
AND   	Language = 'en_US';

/*-- Null the Distant Lands icon
UPDATE 	LocalizedText
SET 	Text = replace(Text, "[icon:NOTIFICATION_DISCOVER_CONTINENT]", "")
WHERE   Tag LIKE 'POK_STFI%'
AND   	Language = 'en_US';/*