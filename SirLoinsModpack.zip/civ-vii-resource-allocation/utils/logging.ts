export function inspect(obj: Object) {
    return console.dir(obj, { depth: null, colors: true })
}
