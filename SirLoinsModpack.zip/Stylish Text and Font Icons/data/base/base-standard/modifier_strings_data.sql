--=============================================================================================================
-- Stylish Text and Font Icons
--=============================================================================================================
-- Font icons do not work in text in Combat Preview panel.
-- Let's replace the relevant text strings with duplicates that
-- do not have the Combat Strength font icon.
-- This way, the regular Descriptions can keep the font icon.
--=============================================================================================================
INSERT OR REPLACE INTO ModifierStrings
		(Context,		ModifierId,		Text)
SELECT	Context,		ModifierId,		'POK_STFI' ||Text
FROM	ModifierStrings
WHERE	Context = 'Preview'
AND		Text LIKE 'LOC_TRADITION%'
AND     Text NOT LIKE '%PREVIEW%'; -- should catch all cases where a Tradition was appropriately given a separate Preview text string

