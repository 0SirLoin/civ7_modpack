/**								 ===========================
* @file appeal-layer			 == Edited by SiBr3, 2025 ==
* @copyright 2022, Firaxis Games ===========================
* @description Lens layer to show settling appeal of a plots
*/
import { InterfaceMode } from '/core/ui/interface-modes/interface-modes.js';
import LensManager from '/core/ui/lenses/lens-manager.js';
import  sibTransparentAppealOptions, {sibTransparentAppealTheme} from '/sib-transparent-appeal/ui/options/sib-transparent-appeal-options.js';
import { OVERLAY_PRIORITY } from '/base-standard/ui/utilities/utilities-overlay.js';


const APPEAL_LAYER_ID = 'fxs-appeal-layer';

const HexToFloat4 = (hex, alpha = 1) => {
	const r = (hex >> 16) & 0xff;
	const g = (hex >> 8) & 0xff;
	const b = hex & 0xff;
	return { x: r / 255, y: g / 255, z: b / 255, w: Math.min(1, Math.max(0, alpha)) };
};

// Define common plot colors
const PLOT_COLORS = {
	settlement: {
		hidden: HexToFloat4(0x690909, 0.3),
		revealed: HexToFloat4(0x690909, 0.6),
	},
	resource: {
		hidden: HexToFloat4(0xFF33AA, 0.1),
		revealed: HexToFloat4(0xFF33AA, 0.25),
	},
	wonder: {
		hidden: HexToFloat4(0x7A1EFF, 0.3),
		revealed: HexToFloat4(0x7A1EFF, 0.4),
	},
	volcano: {
		hidden: HexToFloat4(0xFF4C00, 0.3),
		revealed: HexToFloat4(0xFF4C00, 0.5),
	},
	navigable_river: {
		hidden: HexToFloat4(0x1C39BB, 0.3),
		revealed: HexToFloat4(0x1C39BB, 0.5),
	}
};

//Get theme colours from options menu
function _getOkayColor() {
  const theme = sibTransparentAppealOptions.data.theme;
  return theme === sibTransparentAppealTheme.CIV6
  ? HexToFloat4(0xC6C6C6, .15) // Civ6 style
  : HexToFloat4(0xB49E28, .1); // Base-game style
}

function _getRevealedOkayColor() {
  const theme = sibTransparentAppealOptions.data.theme;
  return theme === sibTransparentAppealTheme.CIV6
  ? HexToFloat4(0xC6C6C6, .4) // Civ6 style
  : HexToFloat4(0xB49E28, .5); // Base-game style
}

function _getGoodColor() {
  const theme = sibTransparentAppealOptions.data.theme;
  return theme === sibTransparentAppealTheme.CIV6
  ? HexToFloat4(0x196319, .15) // Civ6 style
  : HexToFloat4(0x26EEBE, .15); // Base-game style
}

function _getRevealedGoodColor() {
  const theme = sibTransparentAppealOptions.data.theme;
  return theme === sibTransparentAppealTheme.CIV6
  ? HexToFloat4(0x196319, .5) // Civ6 style
  : HexToFloat4(0x26EEBE, .4); // Base-game style
}

class AppealLensLayer {
	constructor() {
		// Init state
		this.refreshTimeout = null;
		this.visibilityChangeCount = 0;
		this.visibilityDecayTimer = null;

		// UI and lens setup
		this.cityAddedToMapListener = () => { this.onCityAddedToMap(); };
		this.appealOverlayGroup = WorldUI.createOverlayGroup("AppealOverlayGroup", OVERLAY_PRIORITY.SETTLER_LENS);
		this.appealOverlay = this.appealOverlayGroup.addPlotOverlay();

		// Map plot arrays
		const plotNames = [
			'blockedPlots',
			'revealedBlockedPlots',
			'bestPlots',
			'revealedBestPlots',
			'okayPlots',
			'revealedOkayPlots',
			'resourcePlots',
			'revealedResourcePlots',
			'wonderPlots',
			'revealedWonderPlots',
			'volcanoPlots',
			'revealedVolcanoPlots',
			'navigableRiverPlots',
			'revealedNavigableRiverPlots'
		];
		this.plotGroups = plotNames.map(name => (this[name] = []));

		// Handles map reveal refreshes -- scaled by map size for performance 
		const width = GameplayMap.getGridWidth();
		const height = GameplayMap.getGridHeight();
		const totalPlots = width * height;
		const scalingFactor = totalPlots / 1000;

		this.onPlotVisibilityChanged = () => {
			this.visibilityChangeCount++;

			if (this.visibilityDecayTimer) clearTimeout(this.visibilityDecayTimer);
			this.visibilityDecayTimer = setTimeout(() => {
				this.visibilityChangeCount = Math.max(0, this.visibilityChangeCount - 10);
			}, 1000);

			const baseDelay = 50;
			const maxDelay = 800;
			const dynamicDelay = Math.min(maxDelay, baseDelay + this.visibilityChangeCount * 2 * scalingFactor);

			if (this.refreshTimeout) clearTimeout(this.refreshTimeout);
			this.refreshTimeout = setTimeout(() => {
				this.applyLayer();
				this.refreshTimeout = null;
				this.visibilityChangeCount = 0;
			}, dynamicDelay);
		};
		engine.on('PlotVisibilityChanged', this.onPlotVisibilityChanged, this);
	}
	clearOverlay() {
		this.appealOverlayGroup.clearAll();
		this.appealOverlay.clear();
		this.plotGroups.forEach(group => group.length = 0);
    
		engine.off('CityInitialized', this.cityAddedToMapListener);
		engine.off('PlotVisibilityChanged', this.onPlotVisibilityChanged, this);
	}
	initLayer() {
	}
	applyLayer() {
		
        console.error("appeal-layer: applyLayer called, lens enabled?", LensManager.isLayerEnabled(APPEAL_LAYER_ID));
        if (!LensManager.isLayerEnabled(APPEAL_LAYER_ID)) {
            console.error("appeal-layer: applyLayer blocked - lens not enabled.");
            return;
        }
		this.clearOverlay();
		engine.on('CityInitialized', this.cityAddedToMapListener);
		engine.on('PlotVisibilityChanged', this.onPlotVisibilityChanged, this);
		const localPlayer = Players.get(GameContext.localPlayerID);
		const localPlayerDiplomacy = localPlayer?.Diplomacy;
		if (!localPlayerDiplomacy) {
		  console.error("appeal-layer: Unable to find local player diplomacy!");
		  return;
		}
		const isInPlacementMode = InterfaceMode.isInInterfaceMode("INTERFACEMODE_BONUS_PLACEMENT");
		const width = GameplayMap.getGridWidth();
		const height = GameplayMap.getGridHeight();
		for (let x = 0; x < width; x++) {
			for (let y = 0; y < height; y++) {
				const plotCoord = { x, y };
				const isRevealed = GameplayMap.getRevealedState(GameContext.localPlayerID, x, y) === RevealedStates.VISIBLE;
				const isWater = GameplayMap.isWater(x, y);
				const isNavigableRiver = GameplayMap.isNavigableRiver(x, y);
				const isMountain = GameplayMap.isMountain(x, y);
				const isNaturalWonder = GameplayMap.isNaturalWonder(x, y);
				const isVolcano = GameplayMap.isVolcano(x, y);
				const getResourceType = GameplayMap.getResourceType(x, y);
				
				function pushPlot(isRevealed, revealedList, list, plot) {
					(isRevealed ? revealedList : list).push(plot);
				}
				
				const features = [
					{ check: sibTransparentAppealOptions.data.showResources,  		condition: getResourceType !== -1, 			revealedList: this.revealedResourcePlots, 		list: this.resourcePlots },
					{ check: sibTransparentAppealOptions.data.showWonders,    		condition: isNaturalWonder,        			revealedList: this.revealedWonderPlots, 		list: this.wonderPlots },
					{ check: sibTransparentAppealOptions.data.showVolcanoes,  		condition: isVolcano && !isNaturalWonder,   revealedList: this.revealedVolcanoPlots, 		list: this.volcanoPlots },
					{ check: sibTransparentAppealOptions.data.showNavigableRivers,  condition: isNavigableRiver, 				revealedList: this.revealedNavigableRiverPlots, list: this.navigableRiverPlots }
				];
				
				for (const { check, condition, revealedList, list } of features) {
					if (check && condition) {
					pushPlot(isRevealed, revealedList, list, plotCoord);
					}
				}
				
				if (isInPlacementMode) {
					if (!GameplayMap.isPlotInAdvancedStartRegion(GameContext.localPlayerID, x, y)) {
						if (isWater || isNavigableRiver || isMountain) continue;
						pushPlot(isRevealed, this.revealedBlockedPlots, this.blockedPlots, plotCoord);
						continue;
					}	
				}
				
				if (!localPlayerDiplomacy.isValidLandClaimLocation(plotCoord, true)) {
					if (isWater || isNavigableRiver || isMountain) continue;
					pushPlot(isRevealed, this.revealedBlockedPlots, this.blockedPlots, plotCoord);
					continue;
				}
				
				// Highlight fresh water plots (good appeal)
				if (GameplayMap.isFreshWater(x, y)) {
					pushPlot(isRevealed, this.revealedBestPlots, this.bestPlots, plotCoord);
					continue;
				}
				
				// Remainder of plots have neutral appeal
				pushPlot(isRevealed, this.revealedOkayPlots, this.okayPlots, plotCoord);
			}
		}
		//Fill in blocked plots first
		this.appealOverlay.addPlots(this.blockedPlots, { fillColor: PLOT_COLORS.settlement.hidden });
		this.appealOverlay.addPlots(this.revealedBlockedPlots, { fillColor: PLOT_COLORS.settlement.revealed });
		
		this.appealOverlay.addPlots(this.okayPlots,           { fillColor: _getOkayColor() });
		this.appealOverlay.addPlots(this.revealedOkayPlots,   { fillColor: _getRevealedOkayColor() });
		this.appealOverlay.addPlots(this.bestPlots,           { fillColor: _getGoodColor() });
		this.appealOverlay.addPlots(this.revealedBestPlots,   { fillColor: _getRevealedGoodColor() });
		//Fill in feature plots last
		this.appealOverlay.addPlots(this.resourcePlots, { fillColor: PLOT_COLORS.resource.hidden });
		this.appealOverlay.addPlots(this.revealedResourcePlots, { fillColor: PLOT_COLORS.resource.revealed });
		this.appealOverlay.addPlots(this.wonderPlots, { fillColor: PLOT_COLORS.wonder.hidden });
		this.appealOverlay.addPlots(this.revealedWonderPlots, { fillColor: PLOT_COLORS.wonder.revealed });
		this.appealOverlay.addPlots(this.volcanoPlots, { fillColor: PLOT_COLORS.volcano.hidden });
		this.appealOverlay.addPlots(this.revealedVolcanoPlots, { fillColor: PLOT_COLORS.volcano.revealed });
		this.appealOverlay.addPlots(this.navigableRiverPlots, { fillColor: PLOT_COLORS.navigable_river.hidden });
		this.appealOverlay.addPlots(this.revealedNavigableRiverPlots, { fillColor: PLOT_COLORS.navigable_river.revealed });
	}
	onCityAddedToMap() {
		this.applyLayer();
	}
	onPlotVisibilityChanged(data) {
		        
        console.error("appeal-layer: onPlotVisibilityChanged called, lens enabled?", LensManager.isLayerEnabled(APPEAL_LAYER_ID));
		//Only refresh if appeal lens is active ===
        if (!LensManager.isLayerEnabled(APPEAL_LAYER_ID)) {
            return;
		}
		this.visibilityChangeCount++;

		// If too many changes, wait for a full stop
		if (this.visibilityChangeCount > 200) {
			if (this.refreshTimeout) clearTimeout(this.refreshTimeout);

			this.refreshTimeout = setTimeout(() => {
				this.applyLayer();
				this.refreshTimeout = null;
				this.visibilityChangeCount = 0;
			}, 500); // Long delay for heavy map reveals
			return;
		}

		// Normal case: short delay
		if (this.refreshTimeout) clearTimeout(this.refreshTimeout);

			this.refreshTimeout = setTimeout(() => {
				this.applyLayer();
				this.refreshTimeout = null;
				this.visibilityChangeCount = 0;
		}, 100);
	}
	removeLayer() {
		this.clearOverlay();
		if (this.refreshTimeout) {
			clearTimeout(this.refreshTimeout);
			this.refreshTimeout = null;
		}
		engine.off('PlotVisibilityChanged', this.onPlotVisibilityChanged, this);
	}
}

LensManager.registerLensLayer(APPEAL_LAYER_ID, new AppealLensLayer());

//# sourceMappingURL=file:///base-standard/ui/lenses/layer/appeal-layer.js.map

