export class CompletionItem {
    constructor(name, type = 'object', properties = {}, description = '', params = '', returns = '') {
        this.name = name;
        this.type = type;
        this.properties = properties;
        this.description = description;
        this.params = params;
        this.returns = returns;
    }
}

export var globalCompletions = {
    'Game': new CompletionItem('Game', 'object', {
        // Core attributes
        'age': new CompletionItem('age', 'attribute', {}, 'Current game age', '', 'number'),
        'maxTurns': new CompletionItem('maxTurns', 'attribute', {}, 'Maximum number of turns', '', 'number'),
        'turn': new CompletionItem('turn', 'attribute', {}, 'Current turn number', '', 'number'),
        'playerScores': new CompletionItem('playerScores', 'attribute', {}, 'Array of player scores', '', 'number[]'),
        'updateCallback': new CompletionItem('updateCallback', 'attribute', {}, 'Game update callback', '', 'Function'),
        'IsAutosave': new CompletionItem('IsAutosave', 'attribute', {}, 'Whether game is autosaving', '', 'boolean'),
        'IsQuicksave': new CompletionItem('IsQuicksave', 'attribute', {}, 'Whether game is quicksaving', '', 'boolean'),
        'ContentType': new CompletionItem('ContentType', 'attribute', {}, 'Game content type', '', 'string'),
        'Type': new CompletionItem('Type', 'attribute', {}, 'Game type', '', 'string'),
        'Directory': new CompletionItem('Directory', 'attribute', {}, 'Game directory', '', 'string'),
        'FileName': new CompletionItem('FileName', 'attribute', {}, 'Game filename', '', 'string'),
        'Location': new CompletionItem('Location', 'attribute', {}, 'Game location', '', 'string'),
        'LocationCategories': new CompletionItem('LocationCategories', 'attribute', {}, 'Game location categories', '', 'string[]'),

        // Core functions
        'bind': new CompletionItem('bind', 'function', {}, 'Bind event handler', 'event: string, handler: Function', 'void'),
        'cancel': new CompletionItem('cancel', 'function', {}, 'Cancel current action', '', 'void'),
        'getBenchmarkType': new CompletionItem('getBenchmarkType', 'function', {}, 'Get benchmark type', '', 'string'),
        'getDebugUiVisiblity': new CompletionItem('getDebugUiVisiblity', 'function', {}, 'Get debug UI visibility', '', 'boolean'),
        'getHash': new CompletionItem('getHash', 'function', {}, 'Get hash value for string', 'value: string', 'number'),
        'getTurnDate': new CompletionItem('getTurnDate', 'function', {}, 'Get date for current turn', '', 'Date'),
        'isRunning': new CompletionItem('isRunning', 'function', {}, 'Check if game is running', '', 'boolean'),
        'randomRange': new CompletionItem('randomRange', 'function', {}, 'Get random number in range', 'min: number, max: number', 'number'),
        'setDebugUiVisiblity': new CompletionItem('setDebugUiVisiblity', 'function', {}, 'Set debug UI visibility', 'visible: boolean', 'void'),
        'start': new CompletionItem('start', 'function', {}, 'Start game', '', 'void'),

        // Age Progress Manager
        'AgeProgressManager': new CompletionItem('AgeProgressManager', 'object', {
            'canTransitionToNextAge': new CompletionItem('canTransitionToNextAge', 'function', {}, 'Check if can transition to next age', 'playerID: number', 'boolean'),
            'getCurrentAgeProgressionPoints': new CompletionItem('getCurrentAgeProgressionPoints', 'function', {}, 'Get current age progression points', '', 'number'),
            'getMaxAgeProgressionPoints': new CompletionItem('getMaxAgeProgressionPoints', 'function', {}, 'Get maximum age progression points', '', 'number'),
            'isAgeOver': new CompletionItem('isAgeOver', 'attribute', {}, 'Whether current age is over', '', 'boolean'),
            'isFinalAge': new CompletionItem('isFinalAge', 'attribute', {}, 'Whether current age is final', '', 'boolean'),
            'isMilestoneComplete': new CompletionItem('isMilestoneComplete', 'function', {}, 'Check if milestone is complete', 'milestoneType: string', 'boolean')
        }, 'Age progression management'),

        // Combat
        'Combat': new CompletionItem('Combat', 'object', {
            'getBestDefender': new CompletionItem('getBestDefender', 'function', {}, 'Get best defender at location', 'x: number, y: number', 'UnitID'),
            'getDefensibleDistrict': new CompletionItem('getDefensibleDistrict', 'function', {}, 'Get defensible district at location', 'x: number, y: number', 'DistrictID'),
            'testAttackInto': new CompletionItem('testAttackInto', 'function', {}, 'Test attack into location', 'attackerID: number, x: number, y: number', 'CombatResult')
        }, 'Combat operations'),

        // City Commands
        'CityCommands': new CompletionItem('CityCommands', 'object', {
            'canStart': new CompletionItem('canStart', 'function', {}, 'Check if city command can start', 'commandType: string, cityID: number', 'boolean'),
            'canStartQuery': new CompletionItem('canStartQuery', 'function', {}, 'Query if city command can start', 'commandType: string, cityID: number', 'QueryResult'),
            'sendRequest': new CompletionItem('sendRequest', 'function', {}, 'Send city command request', 'commandType: string, cityID: number, data: object', 'void')
        }, 'City command operations'),

        // City Operations
        'CityOperations': new CompletionItem('CityOperations', 'object', {
            'canStart': new CompletionItem('canStart', 'function', {}, 'Check if city operation can start', 'operationType: string, cityID: number', 'boolean'),
            'canStartQuery': new CompletionItem('canStartQuery', 'function', {}, 'Query if city operation can start', 'operationType: string, cityID: number', 'QueryResult'),
            'sendRequest': new CompletionItem('sendRequest', 'function', {}, 'Send city operation request', 'operationType: string, cityID: number, data: object', 'void')
        }, 'City operations'),

        // City States
        'CityStates': new CompletionItem('CityStates', 'object', {
            'getBonusType': new CompletionItem('getBonusType', 'function', {}, 'Get city state bonus type', 'cityStateID: number', 'string'),
            'getCityStateBonusToSelect': new CompletionItem('getCityStateBonusToSelect', 'function', {}, 'Get bonus options for city state', 'cityStateID: number', 'string[]'),
            'hasBeenChosen': new CompletionItem('hasBeenChosen', 'function', {}, 'Check if city state has been chosen', 'cityStateID: number', 'boolean')
        }, 'City state management'),

        // Crisis Manager
        'CrisisManager': new CompletionItem('CrisisManager', 'object', {
            'getCrisisStageTriggerPercent': new CompletionItem('getCrisisStageTriggerPercent', 'function', {}, 'Get crisis stage trigger percentage', 'stageID: number', 'number')
        }, 'Crisis management'),

        // Culture
        'Culture': new CompletionItem('Culture', 'object', {
            'GetCelebrationTypesForGovernment': new CompletionItem('GetCelebrationTypesForGovernment', 'function', {}, 'Get celebration types for government', 'governmentType: string', 'string[]'),
            'getGreatWorkType': new CompletionItem('getGreatWorkType', 'function', {}, 'Get great work type', 'greatWorkID: number', 'string')
        }, 'Cultural systems'),

        // Diplomacy
        'Diplomacy': new CompletionItem('Diplomacy', 'object', {
            'getActionRelationshipDelta': new CompletionItem('getActionRelationshipDelta', 'function', {}, 'Get relationship change from action', 'actionType: string, playerID: number', 'number'),
            'getActiveEvents': new CompletionItem('getActiveEvents', 'function', {}, 'Get active diplomatic events', '', 'DiplomaticEvent[]'),
            'getActiveStage': new CompletionItem('getActiveStage', 'function', {}, 'Get active diplomatic stage', '', 'string'),
            'getAgendaDescriptions': new CompletionItem('getAgendaDescriptions', 'function', {}, 'Get agenda descriptions', 'playerID: number', 'string[]'),
            'getAgendaNames': new CompletionItem('getAgendaNames', 'function', {}, 'Get agenda names', 'playerID: number', 'string[]'),
            'hasMet': new CompletionItem('hasMet', 'function', {}, 'Check if players have met', 'player1ID: number, player2ID: number', 'boolean'),
            'modifyByGameSpeed': new CompletionItem('modifyByGameSpeed', 'function', {}, 'Modify value by game speed', 'value: number', 'number')
        }, 'Diplomacy systems'),

        // Economic Rules
        'EconomicRules': new CompletionItem('EconomicRules', 'object', {
            'adjustForGameSpeed': new CompletionItem('adjustForGameSpeed', 'function', {}, 'Adjust economic value for game speed', 'value: number', 'number')
        }, 'Economic rules'),

        // Independent Powers 
        'IndependentPowers': new CompletionItem('IndependentPowers', 'object', {
            'getDistanceToNearestIndependent': new CompletionItem('getDistanceToNearestIndependent', 'function', {}, 'Get distance to nearest independent', 'x: number, y: number', 'number'),
            'getIndependentHostility': new CompletionItem('getIndependentHostility', 'function', {}, 'Get independent power hostility', 'powerID: number', 'number'),
            'independentName': new CompletionItem('independentName', 'function', {}, 'Get independent power name', 'powerID: number', 'string'),
            'isIndependentEncampment': new CompletionItem('isIndependentEncampment', 'function', {}, 'Check if location is independent encampment', 'x: number, y: number', 'boolean')
        }, 'Independent powers management'),

        // Notifications
        'Notifications': new CompletionItem('Notifications', 'object', {
            'activate': new CompletionItem('activate', 'function', {}, 'Activate notification', 'notificationID: number', 'void'),
            'dismiss': new CompletionItem('dismiss', 'function', {}, 'Dismiss notification', 'notificationID: number', 'void'),
            'find': new CompletionItem('find', 'function', {}, 'Find notification by type', 'type: string', 'NotificationID'),
            'getBlocksTurnAdvancement': new CompletionItem('getBlocksTurnAdvancement', 'function', {}, 'Check if notification blocks turn advancement', 'notificationID: number', 'boolean'),
            'getMessage': new CompletionItem('getMessage', 'function', {}, 'Get notification message', 'notificationID: number', 'string'),
            'getSeverity': new CompletionItem('getSeverity', 'function', {}, 'Get notification severity', 'notificationID: number', 'string'),
            'getType': new CompletionItem('getType', 'function', {}, 'Get notification type', 'notificationID: number', 'string')
        }, 'Notification management'),

        // Placement Rules
        'PlacementRules': new CompletionItem('PlacementRules', 'object', {
            'getValidOceanNavalLocation': new CompletionItem('getValidOceanNavalLocation', 'function', {}, 'Get valid naval placement location', 'x: number, y: number', 'Location')
        }, 'Placement rule checking'),

        // Player Operations
        'PlayerOperations': new CompletionItem('PlayerOperations', 'object', {
            'canStart': new CompletionItem('canStart', 'function', {}, 'Check if player operation can start', 'operationType: string, playerID: number', 'boolean'),
            'sendRequest': new CompletionItem('sendRequest', 'function', {}, 'Send player operation request', 'operationType: string, playerID: number, data: object', 'void')
        }, 'Player operations'),

        // Progression Trees
        'ProgressionTrees': new CompletionItem('ProgressionTrees', 'object', {
            'canEverUnlock': new CompletionItem('canEverUnlock', 'function', {}, 'Check if node can be unlocked', 'nodeID: string', 'boolean'),
            'getNode': new CompletionItem('getNode', 'function', {}, 'Get progression tree node', 'nodeID: string', 'Node'),
            'getNodeState': new CompletionItem('getNodeState', 'function', {}, 'Get node state', 'nodeID: string', 'string'),
            'getTree': new CompletionItem('getTree', 'function', {}, 'Get progression tree', 'treeID: string', 'Tree')
        }, 'Progression tree management'),

        // Religion
        'Religion': new CompletionItem('Religion', 'object', {
            'canHaveBelief': new CompletionItem('canHaveBelief', 'function', {}, 'Check if belief can be added', 'beliefType: string', 'boolean'),
            'getPlayerFromReligion': new CompletionItem('getPlayerFromReligion', 'function', {}, 'Get player who founded religion', 'religionID: number', 'PlayerID'),
            'hasBeenFounded': new CompletionItem('hasBeenFounded', 'function', {}, 'Check if religion has been founded', 'religionID: number', 'boolean'),
            'isInSomePantheon': new CompletionItem('isInSomePantheon', 'function', {}, 'Check if belief is in any pantheon', 'beliefType: string', 'boolean'),
            'isInSomeReligion': new CompletionItem('isInSomeReligion', 'function', {}, 'Check if belief is in any religion', 'beliefType: string', 'boolean')
        }, 'Religion systems'),

        // Resources
        'Resources': new CompletionItem('Resources', 'object', {
            'getOriginCity': new CompletionItem('getOriginCity', 'function', {}, 'Get city where resource originates', 'resourceType: string', 'CityID'),
            'getUniqueResourceName': new CompletionItem('getUniqueResourceName', 'function', {}, 'Get unique resource name', 'resourceType: string', 'string')
        }, 'Resource management'),

        // Unit Commands
        'UnitCommands': new CompletionItem('UnitCommands', 'object', {
            'canStart': new CompletionItem('canStart', 'function', {}, 'Check if unit command can start', 'commandType: string, unitID: number', 'boolean'),
            'sendRequest': new CompletionItem('sendRequest', 'function', {}, 'Send unit command request', 'commandType: string, unitID: number, data: object', 'void')
        }, 'Unit command operations'),

        // Unit Operations
        'UnitOperations': new CompletionItem('UnitOperations', 'object', {
            'canStart': new CompletionItem('canStart', 'function', {}, 'Check if unit operation can start', 'operationType: string, unitID: number', 'boolean'),
            'sendRequest': new CompletionItem('sendRequest', 'function', {}, 'Send unit operation request', 'operationType: string, unitID: number, data: object', 'void')
        }, 'Unit operations'),

        // Unlocks
        'Unlocks': new CompletionItem('Unlocks', 'object', {
            'getProgressForPlayer': new CompletionItem('getProgressForPlayer', 'function', {}, 'Get unlock progress for player', 'unlockType: string, playerID: number', 'number')
        }, 'Unlock tracking'),

        // Victory Manager
        'VictoryManager': new CompletionItem('VictoryManager', 'object', {
            'getLatestPlayerDefeat': new CompletionItem('getLatestPlayerDefeat', 'function', {}, 'Get most recent player defeat', '', 'PlayerDefeat'),
            'getVictories': new CompletionItem('getVictories', 'function', {}, 'Get all possible victories', '', 'Victory[]')
        }, 'Victory management')
    }, 'Game engine interface'),

    // Game Context
    'GameContext': new CompletionItem('GameContext', 'object', {
        // Core attributes
        'localObserverID': new CompletionItem('localObserverID', 'object', {
            'toString': new CompletionItem('toString', 'function', {}, 'Convert observer ID to string', '', 'string')
        }, 'Local observer ID'),
        'localPlayerID': new CompletionItem('localPlayerID', 'attribute', {}, 'Current local player ID', '', 'number'),

        // Turn management functions
        'hasSentRetire': new CompletionItem('hasSentRetire', 'function', {}, 'Check if retire request was sent', '', 'boolean'),
        'hasSentTurnComplete': new CompletionItem('hasSentTurnComplete', 'function', {}, 'Check if turn complete was sent', '', 'boolean'),
        'hasSentTurnUnreadyThisTurn': new CompletionItem('hasSentTurnUnreadyThisTurn', 'function', {}, 'Check if turn unready was sent this turn', '', 'boolean'),

        // Game state functions
        'sendGameQuery': new CompletionItem('sendGameQuery', 'function', {}, 'Send game query request', 'queryType: string, data: object', 'void'),
        'sendPauseRequest': new CompletionItem('sendPauseRequest', 'function', {}, 'Send pause game request', 'pause: boolean', 'void'),
        'sendRetireRequest': new CompletionItem('sendRetireRequest', 'function', {}, 'Send retire from game request', '', 'void'),
        'sendTurnComplete': new CompletionItem('sendTurnComplete', 'function', {}, 'Send turn complete notification', '', 'void'),
        'sendUnreadyTurn': new CompletionItem('sendUnreadyTurn', 'function', {}, 'Send turn not ready notification', '', 'void')
    }, 'Game context management'),

    'GameInfo': new CompletionItem('GameInfo', 'object', {
        // Core attributes
        //GameInfo.ID
        'ID': new CompletionItem('ID', 'attribute', {}, 'Game info identifier', '', 'string'),
        //GameInfo.isLackingOwnership
        'isLackingOwnership': new CompletionItem('isLackingOwnership', 'attribute', {}, 'Whether game ownership is lacking', '', 'boolean'),
        //GameInfo.isMissingMods
        'isMissingMods': new CompletionItem('isMissingMods', 'attribute', {}, 'Whether required mods are missing', '', 'boolean'),

        // Collections
        //GameInfo.Units
        'Units': new CompletionItem('Units', 'object', {
            'filter': new CompletionItem('filter', 'function', {}, 'Filter units by predicate', 'predicate: (unit: Unit) => boolean', 'Unit[]'),
            'find': new CompletionItem('find', 'function', {}, 'Find unit by predicate', 'predicate: (unit: Unit) => boolean', 'Unit'),
            'forEach': new CompletionItem('forEach', 'function', {}, 'Iterate over units', 'callback: (unit: Unit) => void', 'void'),
            'length': new CompletionItem('length', 'attribute', {}, 'Number of units', '', 'number'),
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up unit by type', 'type: string', 'Unit')
        }, 'Unit definitions'),

        //GameInfo.Ages
        'Ages': new CompletionItem('Ages', 'object', {
            'find': new CompletionItem('find', 'function', {}, 'Find age by predicate', 'predicate: (age: Age) => boolean', 'Age'),
            'length': new CompletionItem('length', 'attribute', {}, 'Number of ages', '', 'number'),
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up age by type', 'type: string', 'Age')
        }, 'Age definitions'),

        //GameInfo.Buildings 
        'Buildings': new CompletionItem('Buildings', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up building by type', 'type: string', 'Building')
        }, 'Building definitions'),

        //GameInfo.Resources
        'Resources': new CompletionItem('Resources', 'object', {
            'forEach': new CompletionItem('forEach', 'function', {}, 'Iterate over resources', 'callback: (resource: Resource) => void', 'void'),
            'length': new CompletionItem('length', 'attribute', {}, 'Number of resources', '', 'number'),
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up resource by type', 'type: string', 'Resource')
        }, 'Resource definitions'),

        //GameInfo.Features
        'Features': new CompletionItem('Features', 'object', {
            'find': new CompletionItem('find', 'function', {}, 'Find feature by predicate', 'predicate: (feature: Feature) => boolean', 'Feature'),
            'length': new CompletionItem('length', 'attribute', {}, 'Number of features', '', 'number'),
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up feature by type', 'type: string', 'Feature')
        }, 'Feature definitions'),

        //GameInfo.Adjacency_YieldChanges
        'Adjacency_YieldChanges': new CompletionItem('Adjacency_YieldChanges', 'object', {
            'find': new CompletionItem('find', 'function', {}, 'Find adjacency yield change', 'predicate: (yield: YieldChange) => boolean', 'YieldChange')
        }, 'Adjacency yield change definitions'),

        //GameInfo.AdvancedStartDeckCardEntries
        'AdvancedStartDeckCardEntries': new CompletionItem('AdvancedStartDeckCardEntries', 'attribute', {}, 'Advanced start deck card entries', '', 'DeckCardEntry[]'),

        //GameInfo.AdvancedStartParameters
        'AdvancedStartParameters': new CompletionItem('AdvancedStartParameters', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up advanced start parameter', 'type: string', 'Parameter')
        }, 'Advanced start parameter definitions'),

        //GameInfo.AdvisorySubjects
        'AdvisorySubjects': new CompletionItem('AdvisorySubjects', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up advisory subject', 'type: string', 'AdvisorySubject')
        }, 'Advisory subject definitions'),

        //GameInfo.AgeProgressionDarkAgeRewardInfos
        'AgeProgressionDarkAgeRewardInfos': new CompletionItem('AgeProgressionDarkAgeRewardInfos', 'object', {
            'find': new CompletionItem('find', 'function', {}, 'Find dark age reward info', 'predicate: (reward: RewardInfo) => boolean', 'RewardInfo')
        }, 'Dark age reward information'),

        //GameInfo.AgeProgressionMilestoneRewards
        'AgeProgressionMilestoneRewards': new CompletionItem('AgeProgressionMilestoneRewards', 'object', {
            'filter': new CompletionItem('filter', 'function', {}, 'Filter milestone rewards', 'predicate: (reward: MilestoneReward) => boolean', 'MilestoneReward[]')
        }, 'Age progression milestone reward definitions'),

        //GameInfo.AgeProgressionMilestones
        'AgeProgressionMilestones': new CompletionItem('AgeProgressionMilestones', 'object', {
            'filter': new CompletionItem('filter', 'function', {}, 'Filter age progression milestones', 'predicate: (milestone: Milestone) => boolean', 'Milestone[]'),
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up age progression milestone', 'type: string', 'Milestone')
        }, 'Age progression milestone definitions'),

        //GameInfo.Beliefs
        'Beliefs': new CompletionItem('Beliefs', 'object', {
            'forEach': new CompletionItem('forEach', 'function', {}, 'Iterate over beliefs', 'callback: (belief: Belief) => void', 'void'),
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up belief by type', 'type: string', 'Belief')
        }, 'Religious belief definitions'),

        //GameInfo.Biomes
        'Biomes': new CompletionItem('Biomes', 'object', {
            'find': new CompletionItem('find', 'function', {}, 'Find biome by predicate', 'predicate: (biome: Biome) => boolean', 'Biome'),
            'length': new CompletionItem('length', 'attribute', {}, 'Number of biomes', '', 'number'),
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up biome by type', 'type: string', 'Biome')
        }, 'Biome definitions'),

        //GameInfo.CityStateBonuses
        'CityStateBonuses': new CompletionItem('CityStateBonuses', 'object', {
            'find': new CompletionItem('find', 'function', {}, 'Find city state bonus', 'predicate: (bonus: CityStateBonus) => boolean', 'CityStateBonus')
        }, 'City state bonus definitions'),

        //GameInfo.CivilizationTraits
        'CivilizationTraits': new CompletionItem('CivilizationTraits', 'object', {
            'filter': new CompletionItem('filter', 'function', {}, 'Filter civilization traits', 'predicate: (trait: CivilizationTrait) => boolean', 'CivilizationTrait[]')
        }, 'Civilization trait definitions'),

        // Civilopedia related collections
        //GameInfo.CivilopediaPageChapterHeaders
        'CivilopediaPageChapterHeaders': new CompletionItem('CivilopediaPageChapterHeaders', 'object', {
            'forEach': new CompletionItem('forEach', 'function', {}, 'Iterate over chapter headers', 'callback: (header: ChapterHeader) => void', 'void')
        }, 'Civilopedia chapter header definitions'),

        //GameInfo.CivilopediaPageChapterParagraphs
        'CivilopediaPageChapterParagraphs': new CompletionItem('CivilopediaPageChapterParagraphs', 'object', {
            'forEach': new CompletionItem('forEach', 'function', {}, 'Iterate over chapter paragraphs', 'callback: (paragraph: ChapterParagraph) => void', 'void')
        }, 'Civilopedia chapter paragraph definitions'),

        //GameInfo.CivilopediaPages
        'CivilopediaPages': new CompletionItem('CivilopediaPages', 'object', {
            'forEach': new CompletionItem('forEach', 'function', {}, 'Iterate over pages', 'callback: (page: CivilopediaPage) => void', 'void')
        }, 'Civilopedia page definitions'),

        //GameInfo.CivilopediaPageLayouts
        'CivilopediaPageLayouts': new CompletionItem('CivilopediaPageLayouts', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up page layout', 'type: string', 'PageLayout')
        }, 'Civilopedia page layout definitions'),

        //GameInfo.CivilopediaPageSearchTerms
        'CivilopediaPageSearchTerms': new CompletionItem('CivilopediaPageSearchTerms', 'attribute', {}, 'Civilopedia search terms', '', 'string[]'),

        // Diplomacy related collections
        //GameInfo.DiplomacyActions
        'DiplomacyActions': new CompletionItem('DiplomacyActions', 'object', {
            'find': new CompletionItem('find', 'function', {}, 'Find diplomacy action', 'predicate: (action: DiplomacyAction) => boolean', 'DiplomacyAction'),
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up diplomacy action', 'type: string', 'DiplomacyAction')
        }, 'Diplomacy action definitions'),

        //GameInfo.DiplomacyStatements
        'DiplomacyStatements': new CompletionItem('DiplomacyStatements', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up diplomacy statement', 'type: string', 'DiplomacyStatement')
        }, 'Diplomacy statement definitions'),

        //GameInfo.DiplomacyStatementSelections
        'DiplomacyStatementSelections': new CompletionItem('DiplomacyStatementSelections', 'object', {
            'filter': new CompletionItem('filter', 'function', {}, 'Filter statement selections', 'predicate: (selection: StatementSelection) => boolean', 'StatementSelection[]')
        }, 'Diplomacy statement selection definitions'),

        // Management and rule collections
        //GameInfo.Difficulties
        'Difficulties': new CompletionItem('Difficulties', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up difficulty', 'type: string', 'Difficulty')
        }, 'Difficulty level definitions'),

        //GameInfo.Districts
        'Districts': new CompletionItem('Districts', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up district', 'type: string', 'District')
        }, 'District definitions'),

        //GameInfo.GameSpeeds
        'GameSpeeds': new CompletionItem('GameSpeeds', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up game speed', 'type: string', 'GameSpeed')
        }, 'Game speed definitions'),

        //GameInfo.Feature_NaturalWonders
        'Feature_NaturalWonders': new CompletionItem('Feature_NaturalWonders', 'object', {
            'length': new CompletionItem('length', 'attribute', {}, 'Number of natural wonders', '', 'number'),
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up natural wonder', 'type: string', 'NaturalWonder')
        }, 'Natural wonder definitions'),

        //GameInfo.Governments
        'Governments': new CompletionItem('Governments', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up government', 'type: string', 'Government')
        }, 'Government definitions'),

        //GameInfo.GreatWork_YieldChanges
        'GreatWork_YieldChanges': new CompletionItem('GreatWork_YieldChanges', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up great work yield change', 'type: string', 'YieldChange')
        }, 'Great work yield change definitions'),

        //GameInfo.GreatWorks
        'GreatWorks': new CompletionItem('GreatWorks', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up great work', 'type: string', 'GreatWork')
        }, 'Great work definitions'),

        //GameInfo.Ideologies
        'Ideologies': new CompletionItem('Ideologies', 'object', {
            'find': new CompletionItem('find', 'function', {}, 'Find ideology', 'predicate: (ideology: Ideology) => boolean', 'Ideology')
        }, 'Ideology definitions'),

        //GameInfo.Leaders
        'Leaders': new CompletionItem('Leaders', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up leader', 'type: string', 'Leader')
        }, 'Leader definitions'),

        //GameInfo.UnitPromotions
        'UnitPromotions': new CompletionItem('UnitPromotions', 'object', {
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up unit promotion', 'type: string', 'UnitPromotion')
        }, 'Unit promotion definitions'),

        //GameInfo.StartBias collections
        'StartBiasAdjacentToCoasts': new CompletionItem('StartBiasAdjacentToCoasts', 'attribute', {}, 'Start bias for coastal locations', '', 'StartBias[]'),
        'StartBiasBiomes': new CompletionItem('StartBiasBiomes', 'attribute', {}, 'Start bias for biomes', '', 'StartBias[]'),
        'StartBiasFeatureClasses': new CompletionItem('StartBiasFeatureClasses', 'attribute', {}, 'Start bias for feature classes', '', 'StartBias[]'),
        'StartBiasLakes': new CompletionItem('StartBiasLakes', 'attribute', {}, 'Start bias for lakes', '', 'StartBias[]'),
        'StartBiasNaturalWonders': new CompletionItem('StartBiasNaturalWonders', 'attribute', {}, 'Start bias for natural wonders', '', 'StartBias[]'),
        'StartBiasResources': new CompletionItem('StartBiasResources', 'attribute', {}, 'Start bias for resources', '', 'StartBias[]'),
        'StartBiasRivers': new CompletionItem('StartBiasRivers', 'attribute', {}, 'Start bias for rivers', '', 'StartBias[]'),
        'StartBiasTerrains': new CompletionItem('StartBiasTerrains', 'attribute', {}, 'Start bias for terrains', '', 'StartBias[]'),
        'StartingGovernments': new CompletionItem('StartingGovernments', 'attribute', {}, 'Available starting governments', '', 'Government[]'),

        //GameInfo.Yields
        'Yields': new CompletionItem('Yields', 'object', {
            'findIndex': new CompletionItem('findIndex', 'function', {}, 'Find yield index', 'predicate: (yield: Yield) => boolean', 'number'),
            'forEach': new CompletionItem('forEach', 'function', {}, 'Iterate over yields', 'callback: (yield: Yield) => void', 'void'),
            'length': new CompletionItem('length', 'attribute', {}, 'Number of yields', '', 'number'),
            'lookup': new CompletionItem('lookup', 'function', {}, 'Look up yield', 'type: string', 'Yield')
        }, 'Yield definitions')
    }, 'Game information database'),

    //GameplayMap
    'GameplayMap': new CompletionItem('GameplayMap', 'object', {
        // Map Information
        'getGridWidth': new CompletionItem('getGridWidth', 'function', {}, 'Get map grid width', '', 'number'),
        'getGridHeight': new CompletionItem('getGridHeight', 'function', {}, 'Get map grid height', '', 'number'),
        'getMapSize': new CompletionItem('getMapSize', 'function', {}, 'Get map size category', '', 'number'),
        'getRandomSeed': new CompletionItem('getRandomSeed', 'function', {}, 'Get map random seed', '', 'number'),

        // Plot Location and Indexing
        'getIndexFromXY': new CompletionItem('getIndexFromXY', 'function', {}, 'Convert X,Y to plot index', 'x: number, y: number', 'number'),
        'getLocationFromIndex': new CompletionItem('getLocationFromIndex', 'function', {}, 'Convert index to location', 'index: number', 'Location'),
        'getIndexFromLocation': new CompletionItem('getIndexFromLocation', 'function', {}, 'Convert location to index', 'location: Location', 'number'),
        'getAdjacentPlotLocation': new CompletionItem('getAdjacentPlotLocation', 'function', {}, 'Get adjacent plot location', 'location: Location, direction: number', 'Location'),
        'isValidLocation': new CompletionItem('isValidLocation', 'function', {}, 'Check if location is valid', 'location: Location', 'boolean'),

        // Geography and Terrain
        'getAreaId': new CompletionItem('getAreaId', 'function', {}, 'Get area ID at location', 'x: number, y: number', 'number'),
        'getRegionId': new CompletionItem('getRegionId', 'function', {}, 'Get region ID at location', 'x: number, y: number', 'number'),
        'getContinentType': new CompletionItem('getContinentType', 'function', {}, 'Get continent type at location', 'x: number, y: number', 'string'),
        'findSecondContinent': new CompletionItem('findSecondContinent', 'function', {}, 'Find second continent from location', 'x: number, y: number, radius: number', 'boolean'),
        'getHemisphere': new CompletionItem('getHemisphere', 'function', {}, 'Get hemisphere of location', 'x: number, y: number', 'string'),
        'getPlotLatitude': new CompletionItem('getPlotLatitude', 'function', {}, 'Get latitude of location', 'x: number, y: number', 'number'),
        'getElevation': new CompletionItem('getElevation', 'function', {}, 'Get elevation at location', 'x: number, y: number', 'number'),

        // Terrain Features
        'getTerrainType': new CompletionItem('getTerrainType', 'function', {}, 'Get terrain type at location', 'x: number, y: number', 'string'),
        'getBiomeType': new CompletionItem('getBiomeType', 'function', {}, 'Get biome type at location', 'x: number, y: number', 'string'),
        'getFeatureType': new CompletionItem('getFeatureType', 'function', {}, 'Get feature type at location', 'x: number, y: number', 'string'),
        'getFeatureClassType': new CompletionItem('getFeatureClassType', 'function', {}, 'Get feature class at location', 'x: number, y: number', 'string'),
        'getRainfall': new CompletionItem('getRainfall', 'function', {}, 'Get rainfall at location', 'x: number, y: number', 'number'),

        // Water Features
        'isWater': new CompletionItem('isWater', 'function', {}, 'Check if plot is water', 'x: number, y: number', 'boolean'),
        'isLake': new CompletionItem('isLake', 'function', {}, 'Check if plot is lake', 'x: number, y: number', 'boolean'),
        'isRiver': new CompletionItem('isRiver', 'function', {}, 'Check if plot has river', 'x: number, y: number', 'boolean'),
        'getRiverType': new CompletionItem('getRiverType', 'function', {}, 'Get river type at location', 'x: number, y: number', 'string'),
        'getRiverName': new CompletionItem('getRiverName', 'function', {}, 'Get river name at location', 'x: number, y: number', 'string'),
        'isNavigableRiver': new CompletionItem('isNavigableRiver', 'function', {}, 'Check if river is navigable', 'x: number, y: number', 'boolean'),
        'isCoastalLand': new CompletionItem('isCoastalLand', 'function', {}, 'Check if plot is coastal', 'x: number, y: number', 'boolean'),
        'isFreshWater': new CompletionItem('isFreshWater', 'function', {}, 'Check if plot has fresh water', 'x: number, y: number', 'boolean'),
        'isAdjacentToRivers': new CompletionItem('isAdjacentToRivers', 'function', {}, 'Check if plot is next to rivers', 'x: number, y: number', 'boolean'),
        'isAdjacentToShallowWater': new CompletionItem('isAdjacentToShallowWater', 'function', {}, 'Check if plot is next to shallow water', 'x: number, y: number', 'boolean'),

        // Special Features
        'isNaturalWonder': new CompletionItem('isNaturalWonder', 'function', {}, 'Check if plot has natural wonder', 'x: number, y: number', 'boolean'),
        'isVolcano': new CompletionItem('isVolcano', 'function', {}, 'Check if plot has volcano', 'x: number, y: number', 'boolean'),
        'isVolcanoActive': new CompletionItem('isVolcanoActive', 'function', {}, 'Check if volcano is active', 'x: number, y: number', 'boolean'),
        'getVolcanoName': new CompletionItem('getVolcanoName', 'function', {}, 'Get volcano name at location', 'x: number, y: number', 'string'),
        'isMountain': new CompletionItem('isMountain', 'function', {}, 'Check if plot is mountain', 'x: number, y: number', 'boolean'),
        'isCliffCrossing': new CompletionItem('isCliffCrossing', 'function', {}, 'Check if plot has cliff crossing', 'x: number, y: number, direction: number', 'boolean'),

        // Resources and Yields
        'getResourceType': new CompletionItem('getResourceType', 'function', {}, 'Get resource type at location', 'x: number, y: number', 'string'),
        'getYield': new CompletionItem('getYield', 'function', {}, 'Get yield at location', 'x: number, y: number, yieldType: string', 'number'),
        'getYields': new CompletionItem('getYields', 'function', {}, 'Get all yields at location', 'x: number, y: number', 'number[]'),
        'getYieldsWithCity': new CompletionItem('getYieldsWithCity', 'function', {}, 'Get yields with city effects', 'x: number, y: number', 'number[]'),

        // Ownership and Cities
        'getOwner': new CompletionItem('getOwner', 'function', {}, 'Get plot owner ID', 'x: number, y: number', 'number'),
        'getOwnerName': new CompletionItem('getOwnerName', 'function', {}, 'Get plot owner name', 'x: number, y: number', 'string'),
        'getOwnerHostility': new CompletionItem('getOwnerHostility', 'function', {}, 'Get owner hostility level', 'x: number, y: number', 'number'),
        'getOwningCityFromXY': new CompletionItem('getOwningCityFromXY', 'function', {}, 'Get owning city ID', 'x: number, y: number', 'number'),
        'isCityWithinMinimumDistance': new CompletionItem('isCityWithinMinimumDistance', 'function', {}, 'Check minimum city spacing', 'x: number, y: number', 'boolean'),

        // Plot Properties
        'hasPlotTag': new CompletionItem('hasPlotTag', 'function', {}, 'Check if plot has tag', 'x: number, y: number, tag: string', 'boolean'),
        'isPlotInAdvancedStartRegion': new CompletionItem('isPlotInAdvancedStartRegion', 'function', {}, 'Check if in advanced start region', 'x: number, y: number', 'boolean'),
        'getRevealedState': new CompletionItem('getRevealedState', 'function', {}, 'Get revealed state for player', 'x: number, y: number, playerID: number', 'number'),
        'getRevealedStates': new CompletionItem('getRevealedStates', 'function', {}, 'Get all revealed states', 'x: number, y: number', 'number[]')
    }, 'Map and terrain management'),

    //Players
    'Players': new CompletionItem('Players', 'object', {
        // Player interfaces
        //Players.AI
        'AI': new CompletionItem('AI', 'object', {
            'get': new CompletionItem('get', 'function', {}, 'Get AI interface for player', 'playerID: number', 'PlayerAI')
        }, 'AI player functions'),

        //Players.AdvancedStart
        'AdvancedStart': new CompletionItem('AdvancedStart', 'object', {
            'get': new CompletionItem('get', 'function', {}, 'Get advanced start interface for player', 'playerID: number', 'PlayerAdvancedStart')
        }, 'Advanced start functions'),

        //Players.Advisory
        'Advisory': new CompletionItem('Advisory', 'object', {
            'get': new CompletionItem('get', 'function', {}, 'Get advisory interface for player', 'playerID: number', 'PlayerAdvisory')
        }, 'Advisory functions'),

        //Players.Cities
        'Cities': new CompletionItem('Cities', 'object', {
            'get': new CompletionItem('get', 'function', {}, 'Get cities interface for player', 'playerID: number', 'PlayerCities')
        }, 'City management'),

        //Players.Culture
        'Culture': new CompletionItem('Culture', 'object', {
            'get': new CompletionItem('get', 'function', {}, 'Get culture interface for player', 'playerID: number', 'PlayerCulture')
        }, 'Culture functions'),

        //Players.Districts
        'Districts': new CompletionItem('Districts', 'object', {
            'get': new CompletionItem('get', 'function', {}, 'Get districts interface for player', 'playerID: number', 'PlayerDistricts')
        }, 'District functions'),

        //Players.Religion
        'Religion': new CompletionItem('Religion', 'attribute', {}, 'Player religion data', '', 'PlayerReligion'),

        //Players.Treasury
        'Treasury': new CompletionItem('Treasury', 'object', {
            'get': new CompletionItem('get', 'function', {}, 'Get treasury interface for player', 'playerID: number', 'PlayerTreasury')
        }, 'Treasury functions'),

        // Collection attributes
        //Players.length
        'length': new CompletionItem('length', 'attribute', {}, 'Number of players', '', 'number'),
        //Players.maxPlayers
        'maxPlayers': new CompletionItem('maxPlayers', 'attribute', {}, 'Maximum number of players allowed', '', 'number'),

        // Collection methods
        //Players.filter
        'filter': new CompletionItem('filter', 'function', {}, 'Filter players by predicate', 'predicate: (player: Player) => boolean', 'Player[]'),
        //Players.forEach
        'forEach': new CompletionItem('forEach', 'function', {}, 'Iterate over players', 'callback: (player: Player) => void', 'void'),
        //Players.get
        'get': new CompletionItem('get', 'function', {}, 'Get player by ID', 'playerID: number', 'Player'),
        //Players.getAlive
        'getAlive': new CompletionItem('getAlive', 'function', {}, 'Get all living players', '', 'Player[]'),
        //Players.getAliveIds
        'getAliveIds': new CompletionItem('getAliveIds', 'function', {}, 'Get IDs of living players', '', 'number[]'),
        //Players.getAliveMajorIds
        'getAliveMajorIds': new CompletionItem('getAliveMajorIds', 'function', {}, 'Get IDs of living major civilizations', '', 'number[]'),
        //Players.getEverAlive
        'getEverAlive': new CompletionItem('getEverAlive', 'function', {}, 'Get all players that were ever alive', '', 'Player[]'),
        //Players.includes
        'includes': new CompletionItem('includes', 'function', {}, 'Check if player ID exists', 'playerID: number', 'boolean'),
        //Players.push
        'push': new CompletionItem('push', 'function', {}, 'Add player to collection', 'player: Player', 'void'),
        //Players.some
        'some': new CompletionItem('some', 'function', {}, 'Test if any players match predicate', 'predicate: (player: Player) => boolean', 'boolean'),

        // State checks
        //Players.isAI
        'isAI': new CompletionItem('isAI', 'function', {}, 'Check if player is AI controlled', 'playerID: number', 'boolean'),
        //Players.isAlive
        'isAlive': new CompletionItem('isAlive', 'function', {}, 'Check if player is alive', 'playerID: number', 'boolean'),
        //Players.isHuman
        'isHuman': new CompletionItem('isHuman', 'function', {}, 'Check if player is human controlled', 'playerID: number', 'boolean'),
        //Players.isParticipant
        'isParticipant': new CompletionItem('isParticipant', 'function', {}, 'Check if player is game participant', 'playerID: number', 'boolean'),
        //Players.isValid
        'isValid': new CompletionItem('isValid', 'function', {}, 'Check if player ID is valid', 'playerID: number', 'boolean')
    }, 'Player management system'),

    //UnitFlagManager
    'UnitFlagManager': new CompletionItem('UnitFlagManager', 'object', {
        // Static members
        'instance': new CompletionItem('instance', 'attribute', {}, 'Get singleton instance', '', 'UnitFlagManager'),

        // Attributes
        'unitFlagZoomScale': new CompletionItem('unitFlagZoomScale', 'attribute', {}, 'Scale factor for unit flags based on zoom', '', 'number'),
        'flags': new CompletionItem('flags', 'attribute', {}, 'Map of unit flags', '', 'Map<number, UnitFlagType>'),
        'rebuildPending': new CompletionItem('rebuildPending', 'attribute', {}, 'Whether flags need to be rebuilt', '', 'boolean'),
        'globalHide': new CompletionItem('globalHide', 'attribute', {}, 'Whether flags are globally hidden', '', 'boolean'),
        'systemDisabled': new CompletionItem('systemDisabled', 'attribute', {}, 'Whether unit flags are disabled via debug panel', '', 'boolean'),
        'stressTestUnitsEnabled': new CompletionItem('stressTestUnitsEnabled', 'attribute', {}, 'Whether stress test mode is enabled', '', 'boolean'),
        'zoomLevel': new CompletionItem('zoomLevel', 'attribute', {}, 'Current camera zoom level', '', 'number'),

        // Core methods
        'onInitialize': new CompletionItem('onInitialize', 'function', {}, 'Initialize the unit flag manager', '', 'void'),
        'onAttach': new CompletionItem('onAttach', 'function', {}, 'Attach event handlers', '', 'void'), 
        'onDetach': new CompletionItem('onDetach', 'function', {}, 'Detach event handlers', '', 'void'),

        // Flag management
        'getFlag': new CompletionItem('getFlag', 'function', {}, 'Get unit flag by component ID', 'componentID: ComponentID', 'UnitFlagType'),
        'createFlag': new CompletionItem('createFlag', 'function', {}, 'Create unit flag', 'unitID: ComponentID', 'void'),
        'createFlagComponent': new CompletionItem('createFlagComponent', 'function', {}, 'Create unit flag component', 'unitID: ComponentID', 'HTMLElement'),
        'createAllFlags': new CompletionItem('createAllFlags', 'function', {}, 'Create flags for all units', '', 'void'),
        'removeAllFlags': new CompletionItem('removeAllFlags', 'function', {}, 'Remove all unit flags', '', 'void'),
        'requestFlagsRebuild': new CompletionItem('requestFlagsRebuild', 'function', {}, 'Request flags to be rebuilt next frame', '', 'void'),
        'checkFlagRebuild': new CompletionItem('checkFlagRebuild', 'function', {}, 'Check if flags need rebuilding', '', 'void'),

        // Flag tracking
        'addChildForTracking': new CompletionItem('addChildForTracking', 'function', {}, 'Add unit flag to tracking', 'child: UnitFlagType', 'void'),
        'removeChildFromTracking': new CompletionItem('removeChildFromTracking', 'function', {}, 'Remove unit flag from tracking', 'child: UnitFlagType', 'void'),

        // Event handlers  
        'onInteractUnitShow': new CompletionItem('onInteractUnitShow', 'function', {}, 'Handle unit interaction show', 'event: CustomEvent', 'void'),
        'onInteractUnitHide': new CompletionItem('onInteractUnitHide', 'function', {}, 'Handle unit interaction hide', 'event: CustomEvent', 'void'),
        'onDisableFlags': new CompletionItem('onDisableFlags', 'function', {}, 'Disable all unit flags', '', 'void'),
        'onEnableFlags': new CompletionItem('onEnableFlags', 'function', {}, 'Enable all unit flags', '', 'void'),
        'onGlobalHide': new CompletionItem('onGlobalHide', 'function', {}, 'Hide all flags globally', '', 'void'),
        'onGlobalShow': new CompletionItem('onGlobalShow', 'function', {}, 'Show all flags globally', '', 'void'),

        // Unit event handlers
        'onUnitDamageChanged': new CompletionItem('onUnitDamageChanged', 'function', {}, 'Handle unit damage changes', 'data: UnitDamageChanged_EventData', 'void'),
        'onUnitMovementPointsChanged': new CompletionItem('onUnitMovementPointsChanged', 'function', {}, 'Handle unit movement changes', 'data: UnitMovementPointsChanged_EventData', 'void'),
        'onUnitRemovedFromMap': new CompletionItem('onUnitRemovedFromMap', 'function', {}, 'Handle unit removal from map', 'data: Unit_EventData', 'void'),
        'onUnitVisibilityChanged': new CompletionItem('onUnitVisibilityChanged', 'function', {}, 'Handle unit visibility changes', 'data: UnitVisibilityChanged_EventData', 'void'),

        // City event handlers
        'onCityInitialized': new CompletionItem('onCityInitialized', 'function', {}, 'Handle city initialization', 'data: CityAddedToMap_EventData', 'void'),

        // Camera handling
        'onZoomChange': new CompletionItem('onZoomChange', 'function', {}, 'Handle camera zoom changes', 'cameraState: CameraState', 'void'),
        'calculateZoom': new CompletionItem('calculateZoom', 'function', {}, 'Calculate zoom scale factor', 'zoomLevel: number', 'number'),
        'setZoomLevel': new CompletionItem('setZoomLevel', 'function', {}, 'Set zoom level and update flags', 'zoomLevel: number', 'void'),

        // Utility methods
        'isUnitInArmy': new CompletionItem('isUnitInArmy', 'function', {}, 'Check if unit is in an army', 'unitID: ComponentID', 'boolean'),
        'createStressTestFlags': new CompletionItem('createStressTestFlags', 'function', {}, 'Create flags for stress testing', '', 'void'),
        'removeStressTestUnits': new CompletionItem('removeStressTestUnits', 'function', {}, 'Remove stress test units', '', 'void')
    }, 'Manages unit flag lifecycle and updates'),

    //Units
    'Units': new CompletionItem('Units', 'object', {
        // Collection operations
        'filter': new CompletionItem('filter', 'function', {}, 'Filter units by predicate', 'predicate: (unit: Unit) => boolean', 'Unit[]'),
        'find': new CompletionItem('find', 'function', {}, 'Find first matching unit', 'predicate: (unit: Unit) => boolean', 'Unit'),
        'findIndex': new CompletionItem('findIndex', 'function', {}, 'Find index of first matching unit', 'predicate: (unit: Unit) => boolean', 'number'),
        'forEach': new CompletionItem('forEach', 'function', {}, 'Iterate over units', 'callback: (unit: Unit) => void', 'void'),
        'length': new CompletionItem('length', 'attribute', {}, 'Number of units', '', 'number'),
        'push': new CompletionItem('push', 'function', {}, 'Add unit to collection', 'unit: Unit', 'void'),

        // Unit retrieval
        'get': new CompletionItem('get', 'function', {}, 'Get unit by ID', 'unitID: number', 'Unit'),
        'getBuildUnit': new CompletionItem('getBuildUnit', 'function', {}, 'Get buildable unit type', 'unitType: string', 'string'),
        'getUnitIds': new CompletionItem('getUnitIds', 'function', {}, 'Get all unit IDs', '', 'number[]'),
        'getUnits': new CompletionItem('getUnits', 'function', {}, 'Get all units', '', 'Unit[]'),
        'lookup': new CompletionItem('lookup', 'function', {}, 'Look up unit by type', 'type: string', 'Unit'),

        // Unit creation and modification
        'create': new CompletionItem('create', 'function', {}, 'Create new unit', 'type: string, location: Location, owner: number', 'Unit'),
        'setLocation': new CompletionItem('setLocation', 'function', {}, 'Set unit location', 'unitID: number, location: Location', 'void'),

        // Unit capabilities
        'getCommandRadiusPlots': new CompletionItem('getCommandRadiusPlots', 'function', {}, 'Get plots in command radius', 'unitID: number', 'Plot[]'),
        'getNumUnitsOfType': new CompletionItem('getNumUnitsOfType', 'function', {}, 'Get count of units of type', 'unitType: string', 'number'),
        'getPathTo': new CompletionItem('getPathTo', 'function', {}, 'Get path to location', 'unitID: number, location: Location', 'Path'),
        'getQueuedOperationDestination': new CompletionItem('getQueuedOperationDestination', 'function', {}, 'Get queued operation target', 'unitID: number', 'Location'),
        'getReachableMovement': new CompletionItem('getReachableMovement', 'function', {}, 'Get reachable movement plots', 'unitID: number', 'Plot[]'),
        'getReachableTargets': new CompletionItem('getReachableTargets', 'function', {}, 'Get reachable target plots', 'unitID: number', 'Plot[]'),
        'getReachableZonesOfControl': new CompletionItem('getReachableZonesOfControl', 'function', {}, 'Get reachable control zones', 'unitID: number', 'Plot[]'),

        // Unit tag management
        'hasTag': new CompletionItem('hasTag', 'function', {}, 'Check if unit has tag', 'unitID: number, tag: string', 'boolean'),
        'getUnitTypesUnlockedWithTag': new CompletionItem('getUnitTypesUnlockedWithTag', 'function', {}, 'Get unlocked unit types with tag', 'tag: string', 'string[]'),
        'getUnitTypesWithTag': new CompletionItem('getUnitTypesWithTag', 'function', {}, 'Get unit types with tag', 'tag: string', 'string[]'),

        // Shadow units
        'getUnitShadows': new CompletionItem('getUnitShadows', 'function', {}, 'Get unit shadows', '', 'UnitShadow[]'),
        'getShadowIndexClosestToLocation': new CompletionItem('getShadowIndexClosestToLocation', 'function', {}, 'Get closest shadow index', 'location: Location, domain: string', 'number'),
        'removeUnitShadowAtLocation': new CompletionItem('removeUnitShadowAtLocation', 'function', {}, 'Remove shadow at location', 'location: Location', 'void')
    }, 'Unit management'),

    //Camera
    'Camera': new CompletionItem('Camera', 'object', {
        // State management
        'getState': new CompletionItem('getState', 'function', {}, 'Get current camera state', '', 'CameraState'),
        'isWorldDragging': new CompletionItem('isWorldDragging', 'attribute', {}, 'Whether camera is being dragged', '', 'boolean'),
        'reset': new CompletionItem('reset', 'function', {}, 'Reset camera to default state', '', 'void'),
        'restoreDefaults': new CompletionItem('restoreDefaults', 'function', {}, 'Restore default camera settings', '', 'void'),
        'setId': new CompletionItem('setId', 'function', {}, 'Set camera ID', 'id: string', 'void'),

        // Movement and Focus
        'lookAt': new CompletionItem('lookAt', 'function', {}, 'Look at world position', 'x: number, y: number, z: number', 'void'),
        'lookAtPlot': new CompletionItem('lookAtPlot', 'function', {}, 'Look at map plot', 'x: number, y: number', 'void'),
        'panFocus': new CompletionItem('panFocus', 'function', {}, 'Pan camera focus', 'x: number, y: number, z: number', 'void'),
        'dragFocus': new CompletionItem('dragFocus', 'function', {}, 'Drag camera focus', 'x: number, y: number', 'void'),
        'rotate': new CompletionItem('rotate', 'function', {}, 'Rotate camera', 'angle: number', 'void'),

        // Zoom Control
        'zoom': new CompletionItem('zoom', 'function', {}, 'Zoom camera', 'delta: number', 'void'),
        'saveCameraZoom': new CompletionItem('saveCameraZoom', 'function', {}, 'Save current zoom level', '', 'void'),
        'restoreCameraZoom': new CompletionItem('restoreCameraZoom', 'function', {}, 'Restore saved zoom level', '', 'void'),

        // Animation
        'beginAnimation': new CompletionItem('beginAnimation', 'function', {}, 'Start camera animation', '', 'void'),
        'endAnimation': new CompletionItem('endAnimation', 'function', {}, 'End camera animation', '', 'void'),
        'clearAnimation': new CompletionItem('clearAnimation', 'function', {}, 'Clear current animation', '', 'void'),
        'addKeyframe': new CompletionItem('addKeyframe', 'function', {}, 'Add animation keyframe', 'time: number, state: CameraState', 'void'),
        'addDeltaKeyframe': new CompletionItem('addDeltaKeyframe', 'function', {}, 'Add delta animation keyframe', 'time: number, deltaState: CameraState', 'void'),
        'addKeyframe_Translate': new CompletionItem('addKeyframe_Translate', 'function', {}, 'Add translation keyframe', 'time: number, x: number, y: number, z: number', 'void'),

        // Camera Stack
        'pushCamera': new CompletionItem('pushCamera', 'function', {}, 'Push camera state', '', 'void'),
        'pushDynamicCamera': new CompletionItem('pushDynamicCamera', 'function', {}, 'Push dynamic camera state', 'settings: CameraSettings', 'void'),
        'popCamera': new CompletionItem('popCamera', 'function', {}, 'Pop camera state', '', 'void'),

        // Plot Selection
        'pickPlot': new CompletionItem('pickPlot', 'function', {}, 'Pick plot at screen position', 'screenX: number, screenY: number', 'Plot'),
        'pickPlotFromPoint': new CompletionItem('pickPlotFromPoint', 'function', {}, 'Pick plot from world point', 'x: number, y: number, z: number', 'Plot'),

        // Utilities
        'calculateCameraFocusAndZoom': new CompletionItem('calculateCameraFocusAndZoom', 'function', {}, 'Calculate focus and zoom for area', 'minX: number, minY: number, maxX: number, maxY: number', 'CameraSettings'),
        'findDynamicCameraSettings': new CompletionItem('findDynamicCameraSettings', 'function', {}, 'Find dynamic camera settings', '', 'CameraSettings'),
        'setPreventMouseCameraMovement': new CompletionItem('setPreventMouseCameraMovement', 'function', {}, 'Prevent mouse camera movement', 'prevent: boolean', 'void')
    }, 'Camera control system'),

    //ComponentID
    'ComponentID': new CompletionItem('ComponentID', 'object', {
        // Enums and Constants
        'UITypes': new CompletionItem('UITypes', 'object', {
            'IndependentBanner': new CompletionItem('IndependentBanner', 'attribute', {}, 'UI-only independent banner type', '', 'number')
        }, 'UI-specific component types'),
        'cid_type': new CompletionItem('cid_type', 'attribute', {}, 'Component ID type value', '', 'number'),

        // String Conversion
        'toString': new CompletionItem('toString', 'function', {}, 'Convert ComponentID to string', 'id: ComponentID', 'string'),
        'fromString': new CompletionItem('fromString', 'function', {}, 'Create ComponentID from string', 'str: string', 'ComponentID'),
        'toLogString': new CompletionItem('toLogString', 'function', {}, 'Convert ComponentID to debug string', 'id: ComponentID', 'string'),

        // Comparison Functions
        'isMatch': new CompletionItem('isMatch', 'function', {}, 'Check if two ComponentIDs match', 'id1: ComponentID, id2: ComponentID', 'boolean'),
        'isMatchInArray': new CompletionItem('isMatchInArray', 'function', {}, 'Check if ComponentID exists in array', 'ids: ComponentID[], id: ComponentID', 'boolean'),
        'isInstanceOf': new CompletionItem('isInstanceOf', 'function', {}, 'Check if object is ComponentID', 'thing: any', 'boolean'),

        // Array Operations
        'addToArray': new CompletionItem('addToArray', 'function', {}, 'Add ComponentID to array if unique', 'ids: ComponentID[], id: ComponentID', 'boolean'),
        'removeFromArray': new CompletionItem('removeFromArray', 'function', {}, 'Remove ComponentID from array', 'ids: ComponentID[], id: ComponentID', 'boolean'),

        // Validation
        'isInvalid': new CompletionItem('isInvalid', 'function', {}, 'Check if ComponentID is invalid', 'id: ComponentID', 'boolean'),
        'isValid': new CompletionItem('isValid', 'function', {}, 'Check if ComponentID is valid', 'id: ComponentID', 'boolean'),
        'getInvalidID': new CompletionItem('getInvalidID', 'function', {}, 'Get invalid ComponentID', '', 'ComponentID'),

        // Bitfield Operations
        'toBitfield': new CompletionItem('toBitfield', 'function', {}, 'Convert ComponentID to bitfield', 'componentID: ComponentID', 'number'),
        'fromBitfield': new CompletionItem('fromBitfield', 'function', {}, 'Create ComponentID from bitfield', 'bitfield: number', 'ComponentID'),
        'fromPlot': new CompletionItem('fromPlot', 'function', {}, 'Create ComponentID from plot coordinates', 'owner: number, coordinates: PlotCoord, type: number', 'ComponentID'),

        // UI Checks
        'isUI': new CompletionItem('isUI', 'function', {}, 'Check if ComponentID is UI-specific', 'cid: ComponentID', 'boolean'),

        // Creation
        'make': new CompletionItem('make', 'function', {}, 'Create new ComponentID', 'owner: number, type: number, id: number', 'ComponentID')
    }, 'Component ID management system'),

    //Cities
    'Cities': new CompletionItem('Cities', 'object', {
        // Collection operations
        'addEventListener': new CompletionItem('addEventListener', 'function', {}, 'Add event listener for cities', 'event: string, callback: Function', 'void'),
        'find': new CompletionItem('find', 'function', {}, 'Find first matching city', 'predicate: (city: City) => boolean', 'City'),
        'findIndex': new CompletionItem('findIndex', 'function', {}, 'Find index of first matching city', 'predicate: (city: City) => boolean', 'number'),
        'forEach': new CompletionItem('forEach', 'function', {}, 'Iterate over cities', 'callback: (city: City) => void', 'void'),
        'length': new CompletionItem('length', 'attribute', {}, 'Number of cities', '', 'number'),
        'push': new CompletionItem('push', 'function', {}, 'Add city to collection', 'city: City', 'void'),
        'setAttribute': new CompletionItem('setAttribute', 'function', {}, 'Set city attribute', 'cityID: ComponentID, attribute: string, value: any', 'void'),

        // City retrieval
        'get': new CompletionItem('get', 'function', {}, 'Get city by ID', 'cityID: ComponentID', 'City'),
        'getAtLocation': new CompletionItem('getAtLocation', 'function', {}, 'Get city at location', 'x: number, y: number', 'City'),
        'getCapital': new CompletionItem('getCapital', 'function', {}, 'Get capital city', '', 'City'),
        'getCities': new CompletionItem('getCities', 'function', {}, 'Get all cities', '', 'City[]'),
        'getCity': new CompletionItem('getCity', 'function', {}, 'Get city by index', 'index: number', 'City'),
        'getCityIds': new CompletionItem('getCityIds', 'function', {}, 'Get all city IDs', '', 'ComponentID[]'),
        'getDistrict': new CompletionItem('getDistrict', 'function', {}, 'Get district in city', 'cityID: ComponentID, districtType: string', 'District')
    }, 'City management system'),

    //MapCities
    'MapCities': new CompletionItem('MapCities', 'object', {
        // City retrieval
        'getCity': new CompletionItem('getCity', 'function', {}, 'Get city at map location', 'x: number, y: number', 'City'),
        'getDistrict': new CompletionItem('getDistrict', 'function', {}, 'Get district at map location', 'x: number, y: number', 'District')
    }, 'Map-based city lookup system'),

    //MapFeatures
    'MapFeatures': new CompletionItem('MapFeatures', 'object', {
        // Collection properties
        'length': new CompletionItem('length', 'attribute', {}, 'Number of map features', '', 'number'),

        // Feature queries
        'getFeatureInfoAt': new CompletionItem('getFeatureInfoAt', 'function', {}, 'Get feature info at location', 'x: number, y: number', 'Feature'),
        'getNaturalWonders': new CompletionItem('getNaturalWonders', 'function', {}, 'Get all natural wonders', '', 'Feature[]'),

        // Volcano checks
        'canSufferEruptionAt': new CompletionItem('canSufferEruptionAt', 'function', {}, 'Check if location can have eruption', 'x: number, y: number', 'boolean'),
        'isVolcanoActiveAt': new CompletionItem('isVolcanoActiveAt', 'function', {}, 'Check if volcano is active at location', 'x: number, y: number', 'boolean')
    }, 'Map features management system'),

    

    
};