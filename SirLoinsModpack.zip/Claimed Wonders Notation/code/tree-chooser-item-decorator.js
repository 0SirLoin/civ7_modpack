/**
 * Decorate the tree-chooser-item control per https://forums.civfanatics.com/threads/additive-ui-elements.695406/
 */

// force import of tree-chooser-item so we can update its control styles
import '/base-standard/ui/tree-chooser-item/tree-chooser-item.js';

import { WonderTrackerInstance } from '/claimed-wonders-notation/code/wonder-tracker.js';

export class TechWonder_TreeChooserItemDecorator {
    constructor(val) {
        this._item = val;
    }

    beforeAttach() {
    }

    afterAttach() {
        // Find all icon elements with a src that is a completed wonder
        let unlockElements = this._item.Root.getElementsByClassName('tree-chooser-item__details-unlocks');
        for (let e of unlockElements)
        {
            let imageElements = e.getElementsByTagName('img');
            for (let i of imageElements)
            {
                const icon = i.getAttribute('src');
                if (WonderTrackerInstance.IsCompletedIcon(icon))
                {
                    i.classList.add('completed-wonder-icon');
                }
                else if (WonderTrackerInstance.IsConstructingIcon(icon))
                {
                    i.classList.add('constructing-wonder-icon');
                }
            }
        }
    }


    beforeDetach() { }

    afterDetach() { }

    onAttributeChanged(name, prev, next) { }
}

Controls.decorate('tree-chooser-item', (val) => new TechWonder_TreeChooserItemDecorator(val));

if (!Controls.getDefinition('tree-chooser-item').hasOwnProperty('styles'))
{
    Controls.getDefinition('tree-chooser-item').styles = [];
}
Controls.getDefinition('tree-chooser-item').styles.push("fs://game/claimed-wonders-notation/data/wonder-icon.css");