import ActionHandler from "/core/ui/input/action-handler.js";
import ContextManager from '/core/ui/context-manager/context-manager.js';
import Cursor from '/core/ui/input/cursor.js';
import DebugInput from '/core/ui/input/debug-input-handler.js';
import { AnalogInput, InputEngineEvent, InputEngineEventName, NavigateInputEvent, NavigateInputEventName } from '/core/ui/input/input-support.js';
import { InterfaceMode } from '/core/ui/interface-modes/interface-modes.js';
console.warn("NASULOG: Script loaded and executing!");
const originalOnEngineInput = ActionHandler.onEngineInput;

ActionHandler.onEngineInput = function(name, status, x, y) {
    if (Cursor.softCursorEnabled && this.handleSoftCursorInput(name, status, x, y)) {
        return;
    }
    if (!this.handleTunerAction(name, status)) {
        return;
    }
    if (name === "mousebutton-left") {
        switch (status) {
            case InputActionStatuses.FINISH: {
                let clickedElement = document.elementFromPoint(x, y);
                if (clickedElement?.tagName === "HTML") {
                    if (this.hasBeenDragged) {
                        this.hasBeenDragged = false;
                        return;
                    }
                    let selectedUnit = UI.Player.getHeadSelectedUnit();
                    if (selectedUnit && InterfaceMode.getCurrent() == "INTERFACEMODE_UNIT_SELECTED") {
                        InterfaceMode.switchTo("INTERFACEMODE_DEFAULT");
                    }
                }
                this.hasBeenDragged = false;
                break;
            }
            case InputActionStatuses.DRAG: {
                this.hasBeenDragged = true;
                return;
            }
            case InputActionStatuses.UPDATE: {
                if (!this.hasBeenDragged) {
                    return;
                }
                break;
            }
            case InputActionStatuses.START: {
                this.hasBeenDragged = false;
                break;
            }
        }
    }
    originalOnEngineInput.call(this, name, status, x, y);
};

ActionHandler.hasBeenDragged = false;
