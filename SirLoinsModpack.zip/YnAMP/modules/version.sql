/*
	YnAMP for Civ VII
	Gedemon (2025)
	
*/

INSERT OR REPLACE INTO GlobalParameters (Name, Value) VALUES ('YNAMP_VERSION', '1.0.2');