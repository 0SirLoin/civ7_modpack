/**
 * @file utilities-textprovider.ts			// TODO: Re-evaluate what is a generic text provider and what is specific for a type of file (e.g., trees), break out functions.
 * @copyright 2020-2022, Firaxis Games
 *
 * Helpers for finding, composing, and formatting text for all purposes.
 */
import { composeConstructibleDescription, getModifierTextByContext } from '/core/ui/utilities/utilities-core-textprovider.js';
import { Icon } from '/core/ui/utilities/utilities-image.js';

// ff: added. from '/base-standard/data/icons/modifier-icons.xml'
// ------
const MODIFIER_ICONS = {
    "MOD_TECH_AQ_FLAT_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_AQ_PLANTATION_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_AQ_WET_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_AQ_CAMP_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_AQ_PASTURE_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_AQ_FISHING_BOAT_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_AQ_TECH_CULTURE_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_AQ_TECH_FOOD_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_AQ_TECH_GOLD_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_AQ_TECH_HAPPINESS_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_AQ_TECH_MILITARY_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_AQ_TECH_PRODUCTION_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_AQ_TECH_SCIENCE_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_SAILING_EMBARKATION": "MOD_UNIT_UPGRADE",
    "MOD_AQ_CODEX": "MOD_GREATWORK_CODEX",
    "MOD_AQ_CODEX_CIVIC": "MOD_GREATWORK_CODEX",
    "MOD_AQ_MATHEMATICS_CODEX": "MOD_GREATWORK_CODEX",
    "DIPLOMACY_ACTION_ESPIONAGE_STEAL_TECH": "MOD_ESPIONAGE_UNLOCK",
    "MOD_AQ_SETTLEMENT_CAP_INCREASE": "MOD_SETTLEMENT_LIMIT",
    "MOD_TECH_AQ_MINE_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_AQ_SPECIALIST_CAP_INCREASE": "MOD_SPECILAIST_CAP",
    "MOD_AQ_TECH_WALL_STRENGTH": "MOD_GENERIC_BONUS",
    "MOD_AQ_TECH_INFANTRY_STRENGTH": "MOD_UNIT_UPGRADE",
    "DIPLOMACY_ACTION_ESPIONAGE_MILITARY_INFILTRATION": "MOD_ESPIONAGE_UNLOCK",
    "MOD_AQ_TECH_SIEGE_MOVEMENT": "MOD_UNIT_UPGRADE",
    "MOD_AQ_TECH_NAVAL_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_AQ_TECH_UNLOCK_UNIT_FLANKING": "MOD_UNIT_UPGRADE",
    "MOD_AQ_TECH_RANGED_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_AQ_TECH_SIEGE_STRENGTH": "MOD_UNIT_UPGRADE",

    "MOD_FUTURE_TECH_BOOST": "MOD_TECH_BOOST",

    "MOD_PANTHEON_UNLOCK": "MOD_RELIGION_BELIEF",
    "MOD_DISCIPLINE_FREE_COMMANDER": "MOD_GENERIC_BONUS",
    "MOD_AQ_FREE_MERCHANT": "MOD_GENERIC_BONUS",
    "MOD_AQ_TRADITION_SLOT": "MOD_POLICY_SLOT",

    "MOD_FUTURE_CIVIC_BOOST": "MOD_CIVIC_BOOST",


    "MOD_PERIPLUS_OF_THE_ERYTHRAEAN_SEA_RESOURCE_CAP": "MOD_GENERIC_BONUS",
    "MOD_PERIPLUS_OF_THE_ERYTHRAEAN_SEA_COASTAL_URBAN_GOLD": "MOD_TILE_YIELD_BONUS",
    "MOD_MONUMENTUM_ADULITANUM_ALTAR_HAWELT": "MOD_TILE_YIELD_BONUS",
    "MOD_HIMYARITES_DHOW_SWIFT": "MOD_UNIT_UPGRADE",
    "MOD_HAPI_UNITS_IGNORE_MINOR_RIVER": "MOD_UNIT_UPGRADE",
    "MOD_ANUBIS_MEDJAY_GENERATE_GOLD": "MOD_UNIT_UPGRADE",
    "MOD_AMUN_RA_PALACE_GOLD": "MOD_TILE_YIELD_BONUS",
    "MOD_EKKLESIA_CULTURE_ENDEAVOR": "KIND_DIPLOMATIC_ACTION_UNLOCK",
    "MOD_EKKLESIA_CULTURE_SANCTION": "KIND_DIPLOMATIC_ACTION_UNLOCK",
    "MOD_EKKLESIA_CULTURE_PROJECT": "KIND_PROJECT_UNLOCK",
    "MOD_AGOGE_HOPLITE_ABILITY_FRIENDLY_INDEPENDENT": "MOD_UNIT_UPGRADE",
    "MOD_SYMMACHIA_CULTURE_PER_FRIENDLY_INDEPENDENT": "MOD_GENERIC_BONUS",
    "MOD_ZHI_SCIENCE_BUILDING_URBAN_ADJACENCY": "MOD_TILE_YIELD_BONUS",
    "MOD_LI_DIPLOMACY_YIELD": "MOD_TILE_YIELD_BONUS",
    "MOD_YI_ABILITY": "MOD_UNIT_UPGRADE",
    "MOD_JUNZI_CAPITAL_SCIENCE": "MOD_TILE_YIELD_BONUS",
    "MOD_MOUSONG_FLOOD_IMMUNITY": "MOD_GENERIC_BONUS",
    "MOD_AMNACH_DANTINAS_TATHA_MOVEMENT_BONUS": "MOD_UNIT_UPGRADE",
    "MOD_CHAKRAVARTI_CAPITAL_GROWTH": "MOD_GENERIC_BONUS",
    "MOD_CHAKRAVARTI_CITY_HAPPINESS_PENALTY": "MOD_GENERIC_BONUS",
    "MOD_AYURVEDA_PURABHETTARAH_HEAL_ABILITY": "MOD_UNIT_UPGRADE",
    "MOD_MANTRIPARISHAD_OCCUPIED_CITY_YIELD": "MOD_TILE_YIELD_BONUS",
    "MOD_XIBALBA_HULCHE_STEALTH": "MOD_UNIT_UPGRADE",
    "MOD_CALENDAR_ROUND_CULTURE_FOR_TECH": "MOD_TECH_BOOST",
    "MOD_CALENDAR_ROUND_SCIENCE_FOR_CIVIC": "MOD_CIVIC_BOOST",
    "MOD_EARTHWORKS_BUILDING_PRODUCTION_MODIFIER": "MOD_TILE_YIELD_BONUS",
    "MOD_WAAHIH_BURNING_ARROW_PILLAGE_ABILITY": "MOD_UNIT_UPGRADE",
    "MOD_SPADA_UNIT_MAINTENANCE": "MOD_UNIT_UPGRADE",
    "MOD_SATRAPIES_PAIRIDAEZA_URBAN_ADJACENCY": "MOD_TILE_YIELD_BONUS",
    "MOD_ACHAEMENID_EMPIRE_CAPTURED_CITY_GOLD": "MOD_GENERIC_BONUS",
    "MOD_EXERCITUS_ROMANUS_LEGATUS_PROMOTION": "MOD_UNIT_UPGRADE",
    "MOD_CIVIS_ROMANUS_CAPITAL_GOLD_PER_TOWN": "MOD_GENERIC_BONUS",
    "MOD_LEGATUS_PRO_PRAETORE_INFANTRY": "MOD_GENERIC_BONUS",
    "MOD_SENATUS_POPULUSQUE_ROMANUS_TRADITION_SLOTS": "MOD_POLICY_UNLOCK",


    "MOD_TECH_EX_FISHING_BOAT_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_EX_CAMP_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_EX_MINE_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_EX_SETTLEMENT_CAP_INCREASE": "MOD_SETTLEMENT_LIMIT",
    "MOD_TECH_EX_PASTURE_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_EX_TECH_INFANTRY_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_TECH_EX_QUARRY_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_EX_TECH_WALL_STRENGTH": "MOD_GENERIC_BONUS",
    "MOD_EX_SPECIALIST_CAP_INCREASE": "MOD_SPECILAIST_CAP",
    "MOD_TECH_EX_NO_OCEAN_DAMAGE": "MOD_UNIT_UPGRADE",
    "MOD_EX_TECH_NAVAL_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_OCEAN_EXPLORER": "MOD_UNIT_UPGRADE",
    "MOD_EX_TECH_SIEGE_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_EX_TECH_RANGED_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_EX_TECH_CULTURE_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_EX_TECH_FOOD_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_EX_TECH_GOLD_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_EX_TECH_HAPPINESS_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_EX_TECH_MILITARY_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_EX_TECH_PRODUCTION_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_EX_TECH_SCIENCE_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_EX_RELIC": "MOD_GREATWORK_RELIC",
    "MOD_TECH_OCEAN_TRAVEL_EMBARKED": "MOD_UNIT_UPGRADE",
    "MOD_EX_TECH_CAVALRY_STRENGTH": "MOD_UNIT_UPGRADE",


    "MOD_PIETY_RELIC": "MOD_GREATWORK_RELIC",
    "MOD_EX_TRADITION_SLOT": "MOD_POLICY_SLOT",


    "MOD_WAYANG_OVERBUILD_PRODUCTION": "MOD_GENERIC_BONUS",
    "MOD_ALIRAN_KEPERCAYAAN_CONVERT_EXTRA_CULTURE": "MOD_GENERIC_BONUS",
    "MOD_NUSUNTARA_CULTURE_COAST": "MOD_TILE_YIELD_BONUS",
    "MOD_NUSUNTARA_SEA_VS_LAND": "MOD_UNIT_UPGRADE",
    "MOD_GAMELAN_CULTURE_BUILDINGS_THIS_AGE": "MOD_TILE_YIELD_BONUS",
    "MOD_ROUND_CITY_BUILDING_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_ROUND_CITY_SCIENCE_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_MAWLA_TEMPLE_WAREHOUSE_RESOURCE": "MOD_TILE_YIELD_BONUS",
    "MOD_MAWLA_TRADE_GOLD_TO_SCIENCE": "MOD_GENERIC_BONUS",
    "MOD_MAWLA_MAMLUK_ABILITY_SKIRMISH": "MOD_UNIT_UPGRADE",
    "MOD_AL_JABR_URBAN_SCIENCE": "MOD_TILE_YIELD_BONUS",
    "MOD_AL_JABR_WORKER_MAINTENANCE": "MOD_GENERIC_BONUS",
    "MOD_KANAKAM_GOLD_PER_ENVOY": "MOD_GENERIC_BONUS",
    "MOD_NAGARAM_FREE_TOKEN": "MOD_GENERIC_BONUS",
    "MOD_NAGARAM_RSOURCE_CAP": "MOD_GENERIC_BONUS",
    "MOD_DIGVIJAYA_KALAM_SIGHT": "MOD_UNIT_UPGRADE",
    "MOD_DIGVIJAYA_KALAM_MOVEMENT": "MOD_UNIT_UPGRADE",
    "MONSOON_WINDS_MOD_OTTRU_CONVOYS": "MOD_UNIT_UPGRADE",
    "MOD_MANA_CULTURE_DISASTERS": "MOD_GENERIC_BONUS",
    "MOD_OHANA_PAVILION_WAREHOUSE_LOL_KALO": "MOD_TILE_YIELD_BONUS",
    "MOD_HE_E_NALU_TWO_RELICS": "MOD_GREATWORK_RELIC",
    "MOD_RELIGION_MARINE_TILE_CULTURE": "MOD_TILE_YIELD_BONUS",
    "MOD_KAHUNA_CHARGES": "MOD_UNIT_UPGRADE",
    "MOD_MITA_MOUNTAIN_HAPPINESS": "MOD_TILE_YIELD_BONUS",
    "MOD_AYLLU_GRANARY_TERRACE_FARM": "MOD_TILE_YIELD_BONUS",
    "MOD_AYLLU_TERRACE_FARM_MOUNTAIN": "MOD_TILE_YIELD_BONUS",
    "MOD_AYLLU_FARM_MOUNTAIN": "MOD_TILE_YIELD_BONUS",
    "MOD_QHAPAQ_NAN_HILL_MOVEMENT": "MOD_UNIT_UPGRADE",
    "MOD_QHAPAQ_NAN_WARAKAQ_POISONOUS": "MOD_UNIT_UPGRADE",
    "MOD_NINE_GARRISONS_BANK_MING_GREAT_WALL": "MOD_TILE_YIELD_BONUS",
    "MOD_NINE_GARRISONS_XUNLEICHONG_RANGED": "MOD_UNIT_UPGRADE",
    "MOD_LIJIA_TOWN_BUILDING_PURCHASE": "MOD_GENERIC_BONUS",
    "MOD_LIJIA_CAP_RESOURCE_CAP": "MOD_GENERIC_BONUS",
    "MOD_DA_MING_LU_MANDARIN_ABILITY": "MOD_UNIT_UPGRADE",
    "MOD_CONQUERED_TOWN_UPGRADE_DISCOUNT": "MOD_GENERIC_BONUS",
    "MOD_GRANT_NOYAN": "MOD_GENERIC_BONUS",
    "MOD_YASSA_ORTOO_MORE_GOLD": "MOD_TILE_YIELD_BONUS",
    "MOD_CONSUETUDINES_ET_JUSTICIE_CHEVELAR_ABILITY": "MOD_UNIT_UPGRADE",
    "MOD_COMMON_LAW_TRADITION_SLOTS": "MOD_GENERIC_BONUS",
    "MOD_DOMESDAY_BOOK_FARM_GOLD": "MOD_TILE_YIELD_BONUS",
    "MOD_DOMESDAY_BOOK_FARM_GOLD_GOLDEN_AGE": "MOD_TILE_YIELD_BONUS",
    "MOD_SHIPS_OF_THE_DESERT_BAZAAR_CARAVANSARI": "MOD_TILE_YIELD_BONUS",
    "MOD_HI_KOI_RIVER_COMBAT": "MOD_UNIT_UPGRADE",
    "MOD_HI_KOI_MINOR_RIVER_MOVEMENT": "MOD_UNIT_UPGRADE",
    "MOD_HI_KOI_NAVIGABLE_RIVER_MOVEMENT": "MOD_UNIT_UPGRADE",
    "MOD_KANTA_TAJIRO_ABILITY": "MOD_UNIT_UPGRADE",
    "MOD_KANTA_AUTO_TREASURE_FLEET": "MOD_GENERIC_BONUS",
    "MOD_COUNCIL_OF_THE_INDIES_TREASURE_FLEET_MOVEMENT": "MOD_UNIT_UPGRADE",
    "MOD_ARMADA_FLEET_COMMANDER_CAPACITY": "MOD_UNIT_UPGRADE",
    "MOD_NEW_WORLD_RICHES_FOREIGN_CITIES_PRODUCTION_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_ARMADA_EMBARK_MOVEMENT": "MOD_UNIT_UPGRADE",


    "MOD_TECH_MO_PLANTATION_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_DESERT_FLOODPLAIN_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_GRASSLAND_FLOODPLAIN_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_PLAINS_FLOODPLAIN_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_TROPICAL_FLOODPLAIN_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_TUNDRA_FLOODPLAIN_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_FLAT_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_QUARRY_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_WET_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_MO_TECH_CAVALRY_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_TECH_MO_CAMP_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_MO_TECH_INFANTRY_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_TECH_MO_MINE_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_ROUGH_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_WOODCUTTER_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_VEGETATED_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_MO_TECH_INTERCEPT_RANGE": "MOD_UNIT_UPGRADE",
    "MOD_MO_TECH_CULTURE_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_MO_TECH_FOOD_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_MO_TECH_GOLD_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_MO_TECH_HAPPINESS_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_MO_TECH_MILITARY_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_MO_TECH_PRODUCTION_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_MO_TECH_SCIENCE_BUILDING": "MOD_GENERIC_BONUS",
    "MOD_TECH_MO_FISHING_BOAT_RESOURCE_FOOD": "MOD_GENERIC_BONUS",
    "MOD_TECH_MO_COAST_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_REEF_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_COLD_REEF_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_TECH_MO_NAVIGABLE_RIVER_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_MO_TECH_NAVAL_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_MO_TECH_RANGED_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_MO_TECH_SIEGE_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_MO_TECH_AIRCRAFT_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_FUTURE_TECH_ATTRIBUTE": "MOD_ATTRIBUTE",
    "MOD_FUTURE_TECH_AGE_PROGRESS": "MOD_GENERIC_BONUS",


    "MOD_MO_OPEN_EXPLORATION_ARCHAEOLOGY": "MOD_GENERIC_BONUS",
    "MOD_MO_TRADITION_SLOT": "MOD_GENERIC_BONUS",
    "MOD_MO_UNLOCK_IDEOLOGIES": "MOD_UNLOCK_IDEOLOGY",
    "MOD_MO_OPEN_ANTIQUITY_ARCHAEOLOGY": "MOD_GENERIC_BONUS",
    "MOD_MO_SPECIALIST_CAP_INCREASE": "MOD_SPECILAIST_CAP",
    "MOD_FUTURE_CIVIC_ATTRIBUTE": "MOD_ATTRIBUTE",
    "MOD_FUTURE_CIVIC_AGE_PROGRESS": "MOD_GENERIC_BONUS",
    "MOD_DEMOCRACY_RIFLEMEN": "MOD_GENERIC_BONUS",
    "MOD_DEMOCRACY_CULTURAL_ATTRIBUTE": "MOD_ATTRIBUTE",
    "MOD_DEMOCRACY_POLITICAL_ATTRIBUTE": "MOD_ATTRIBUTE",
    "MOD_FASCISM_LANDSHIP": "MOD_GENERIC_BONUS",
    "MOD_FASCISM_ECONOMIC_ATTRIBUTE": "MOD_ATTRIBUTE",
    "MOD_FASCISM_MILITARISTIC_ATTRIBUTE": "MOD_ATTRIBUTE",
    "MOD_COMMUNISM_AT_GUNS": "MOD_GENERIC_BONUS",
    "MOD_COMMUNISM_EXPANSIONIST_ATTRIBUTE": "MOD_ATTRIBUTE",
    "MOD_COMMUNISM_SCIENTIFIC_ATTRIBUTE": "MOD_ATTRIBUTE",


    "MOD_YANKEE_INGENUITY_PROSPECTOR_DISCOUNT": "MOD_GENERIC_BONUS",
    "MOD_CAPTAINS_OF_INDUSTRY_PRODUCTION_ON_RESOURCES": "MOD_TILE_YIELD_BONUS",
    "MOD_MO_SETTLEMENT_CAP_INCREASE": "MOD_SETTLEMENT_LIMIT",
    "MOD_WARTIME_MANUFACTURING_COMBAT_STRENGTH_PER_ADJACENT_ENEMY_UNIT": "MOD_UNIT_UPGRADE",
    "MOD_WARTIME_MANUFACTURING_UNIT_PRODUCTION_RATE": "MOD_TILE_YIELD_BONUS",
    "MOD_NNALUBAALE_LAKE_NAVIGABLE_RIVER_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_NNALUBAALE_LAKE_NAVIGABLE_RIVER_CULTURE": "MOD_TILE_YIELD_BONUS",
    "MOD_NNALUBAALE_EMBARKED_UNITS_MOVEMENT_BONUS": "MOD_UNIT_UPGRADE",
    "MOD_BLUTABAALO_PILLAGING_BUILDING_YIELDS": "MOD_TILE_YIELD_BONUS",
    "MOD_BLUTABAALO_PILLAGING_IMPROVEMENT_YIELDS": "MOD_TILE_YIELD_BONUS",
    "MOD_BLUTABAALO_COMMANDER_EXP_YIELDS": "MOD_UNIT_UPGRADE",
    "MOD_NYANZA_LAKE_RIVERS_URBAN_HAPPINESS": "MOD_TILE_YIELD_BONUS",
    "MOD_NYANZA_LAKE_RIVERS_URBAN_CULTURE": "MOD_TILE_YIELD_BONUS",
    "MOD_BELLE_EPOQUE_CULTURE_ON_HAPPINESS_BUILDINGS": "MOD_TILE_YIELD_BONUS",
    "MOD_BELLE_EPOQUE_CULTURE_ON_WONDERS": "MOD_TILE_YIELD_BONUS",
    "MOD_VOIE_TRIOMPHALE_HAPPINESS_ON_MILITARY_BUILDINGS": "MOD_TILE_YIELD_BONUS",
    "MOD_VOIE_TRIOMPHALE_HAPPINESS_ON_WONDERS": "MOD_TILE_YIELD_BONUS",
    "MOD_GRANDE_ARMEE_COMMANDER_PROMOTION": "MOD_UNIT_UPGRADE",
    "MOD_GRANDE_ARMEE_UNIT_ABILITY": "MOD_UNIT_UPGRADE",
    "MOD_CODE_CIVIL_CULTURE_PER_ACTIVE_TRADITION": "MOD_GENERIC_BONUS",
    "MOD_BUNMEI_KAIKA_MILITARY_BUILDING_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_BUNMEI_KAIKA_PRODUCTION_BUILDING_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_OATH_IN_FIVE_ARTICLES_SCIENCE_BUILDING_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_SUPREME_WAR_COUNCIL_AIRCRAFT_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_SUPREME_WAR_COUNCIL_NAVAL_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_GASHINSHOUTAN_ADJUST_COMBAT_STRENGTH_ON_COAST": "MOD_TILE_YIELD_BONUS",
    "MOD_PLANES_POLITICOS_TRADITION_SLOT": "MOD_POLICY_SLOT",
    "MOD_PLAN_OF_IGUALA_GOLDEN_AGE": "MOD_GENERIC_BONUS",
    "MOD_PLAN_OF_AYUTLA_GOLDEN_AGE": "MOD_GENERIC_BONUS",
    "MOD_PLAN_OF_TUXTEPEC_GOLDEN_AGE": "MOD_GENERIC_BONUS",
    "MOD_ZABT_FARM_GOLD": "MOD_TILE_YIELD_BONUS",
    "MOD_JAGIR_FARM_HAPPINESS": "MOD_TILE_YIELD_BONUS",
    "MOD_MANSABDARI_INFANTRY_PURCHASE_COST": "MOD_GENERIC_BONUS",
    "MOD_GARDENS_OF_PARADISE_PURCHASE_ABILITY": "MOD_GENERIC_BONUS",
    "MOD_RUHR_CONSTRUCTIBLE_RIVER_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_ZOLLVEREIN_TRADE_DURING_WAR": "MOD_GENERIC_BONUS",
    "MOD_ZOLLVEREIN_STAATSEISENBAHN_TRADE_YIELD": "MOD_GENERIC_BONUS",
    "MOD_EMS_DISPATCH_RELATIONSHIPS": "MOD_GENERIC_BONUS",
    "MOD_BEWEGUNGSKRIEG_HEAVY_CAVALRY_SKIRMISH_ABILITY": "MOD_UNIT_UPGRADE",
    "MOD_BEWEGUNGSKRIEG_LIGHT_CAVALRY_FLANKING_BONUS": "MOD_UNIT_UPGRADE",
    "MOD_TEN_GREAT_CAMPAIGNS_ADJUST_COMBAT_STRENGTH": "MOD_UNIT_UPGRADE",
    "MOD_OPEN_CUSTOMS_CULTURE_PER_IMPORTED_RESOURCE": "MOD_TILE_YIELD_BONUS",
    "MOD_KANG_XI_TAX_REFORMATION_ASSIGNED_RESOURCE_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_STABILIZING_FRONTIER_ASSIGNED_RESOURCE_HAPPINESS": "MOD_TILE_YIELD_BONUS",
    "MOD_SERFDOM_FARM_FOOD": "MOD_TILE_YIELD_BONUS",
    "MOD_SERFDOM_TUNDRA_FARM_PRODUCTION": "MOD_TILE_YIELD_BONUS",
    "MOD_TABLE_OF_RANKS_URBAN_GOLD": "MOD_TILE_YIELD_BONUS",
    "MOD_TABLE_OF_RANKS_TUNDRA_URBAN_CULTURE": "MOD_TILE_YIELD_BONUS",
    "MOD_SAMODERZHAVIYE_ENEMY_BLIZZARD_VULNERABILITY": "MOD_UNIT_UPGRADE",
    "MOD_SAMODERZHAVIYE_FRIENDLY_BLIZZARD_IMMUNITY": "MOD_UNIT_UPGRADE",
    "MOD_SAMODERZHAVIYE_CITY_CULTURE": "MOD_TILE_YIELD_BONUS",
    "MOD_SAMODERZHAVIYE_TUNDRA_CITY_CULTURE": "MOD_TILE_YIELD_BONUS",
    "MOD_NINE_GEMS_CULTURE_PER_FRIENDLY": "MOD_GENERIC_BONUS",
    "MOD_NINE_GEMS_CULTURE_PER_HELPFUL": "MOD_GENERIC_BONUS",
    "MOD_NINE_GEMS_INFLUENCE_PER_FRIENDLY": "MOD_GENERIC_BONUS",
    "MOD_NINE_GEMS_INFLUENCE_PER_HELPFUL": "MOD_GENERIC_BONUS",
    "MOD_MANDALA_CHANG_BEUN_COMBAT_STRENGTH_IN_CITY_STATE_ALLY": "MOD_UNIT_UPGRADE",
    "MOD_MANDALA_PALACE_CULTURE_PER_CITY_STATE_ALLY": "MOD_GENERIC_BONUS",
    "MOD_SRIWILAI_CULTURE_PER_AGREEMENT_ENDEAVOR": "MOD_GENERIC_BONUS",
    "MOD_SRIWILAI_CULTURE_PER_AGREEMENT_SANCTION": "MOD_GENERIC_BONUS",
    "MOD_SRIWILAI_TRADE_ROUTE_CULTURE": "MOD_GENERIC_BONUS",
    "MOD_SRIWILAI_TRADE_ROUTE_GOLD": "MOD_GENERIC_BONUS",
}
// ------

/** ================================================================
 *  Unlock Name/Desc Helpers
 * =============================================================== */
export function getUnlockTargetName(targetType, targetKind) {
    // Target is a MODIFIER
    if (targetKind == "KIND_MODIFIER") {
        const modInfo = GameInfo.Modifiers.find(o => o.ModifierId == targetType);
        if (modInfo) {
            let modifierName = getModifierTextByContext(modInfo.ModifierId, "Name");
            return Locale.compose(modifierName) ?? "";
        }
    }
    // Target is a CONSTRUCTIBLE
    if (targetKind == "KIND_CONSTRUCTIBLE") {
        const constructibleInfo = GameInfo.Constructibles.find(o => o.ConstructibleType == targetType);
        if (constructibleInfo) {
            return Locale.compose(constructibleInfo.Name);
        }
    }
    // Target is a UNIT
    if (targetKind == "KIND_UNIT") {
        const unitInfo = GameInfo.Units.find(o => o.UnitType == targetType);
        if (unitInfo) {
            return Locale.compose(unitInfo.Name);
        }
    }
    // Target is a TRADITION
    if (targetKind == "KIND_TRADITION") {
        const traditionInfo = GameInfo.Traditions.find(o => o.TraditionType == targetType);
        if (traditionInfo) {
            return Locale.compose(traditionInfo.Name);
        }
    }
    // Target is a DIPLOMATIC ACTION
    if (targetKind == "KIND_DIPLOMATIC_ACTION") {
        const diploActionInfo = GameInfo.DiplomacyActions.find(o => o.DiplomacyActionType == targetType);
        if (diploActionInfo) {
            return Locale.compose(diploActionInfo.Name);
        }
    }
    if (targetKind == "KIND_PROJECT") {
        const projectInfo = GameInfo.Projects.find(o => o.ProjectType == targetType);
        if (projectInfo) {
            return Locale.compose(projectInfo.Name);
        }
    }
    // Error case: this target is unhandled or the target did not match the kind
    return targetType;
}
//TODO: Move into utilties-image
//TODO: Does not need to be so specific by type, kind, etc
export function getUnlockTargetIcon(targetType, targetKind) {
    // Target is a CONSTRUCTIBLE
    if (targetKind == "KIND_CONSTRUCTIBLE") {
        const constructibleInfo = GameInfo.Constructibles.find(o => o.ConstructibleType == targetType);
        if (constructibleInfo) {
            return Icon.getConstructibleIconFromDefinition(constructibleInfo);
        }
    }
    // Target is a UNIT
    if (targetKind == "KIND_UNIT") {
        const unitInfo = GameInfo.Units.find(o => o.UnitType == targetType);
        if (unitInfo) {
            return Icon.getUnitIconFromDefinition(unitInfo);
        }
    }
    // ff: added
    // ------

    // Espionage actions got a diplomatic action icon except two antiquity tech unlocks. So I make them consistent.
    if (targetType.startsWith("DIPLOMACY_ACTION_ESPIONAGE_")) {
        return UI.getIconURL("MOD_ESPIONAGE_UNLOCK");
    }

    // const alias = UI.getIconAlias(targetType); // it doesn't work. alias.id is the same as targetType
    if (targetType in MODIFIER_ICONS) {
        let iconURL = UI.getIconURL(MODIFIER_ICONS[targetType]);
        if (iconURL != "") {
            return iconURL;
        }
    }
    // ------
    let iconURL = UI.getIcon(targetKind + "_UNLOCK");
    if (iconURL != "") {
        return iconURL;
    }
    else {
        iconURL = UI.getIconURL(targetType);
        if (iconURL != "") {
            return iconURL;
        }
    }
    console.warn("cannot get icon for unhandled targetType: ", targetType, ",  target kind: ", targetKind);
    return UI.getIconURL("MOD_GENERIC_BONUS");
}
export function getUnlockTargetDescriptions(targetType, targetKind) {
    let locStrings = [];
    // Target is a MODIFIER
    if (targetKind == "KIND_MODIFIER") {
        const modInfo = GameInfo.Modifiers.find(o => o.ModifierId == targetType);
        if (modInfo) {
            const modifierDesc = getModifierTextByContext(modInfo.ModifierId, "Description");
            if (modifierDesc) {
                locStrings.push(modifierDesc);
            }
        }
    }
    // Target is a CONSTRUCTIBLE
    else if (targetKind == "KIND_CONSTRUCTIBLE") {
        const desc = composeConstructibleDescription(targetType);
        if (desc) {
            locStrings.push(desc);
        }
    }
    // Target is a UNIT
    else if (targetKind == "KIND_UNIT") {
        const unitInfo = GameInfo.Units.find(o => o.UnitType == targetType);
        if (unitInfo) {
            if (unitInfo.Description) {
                locStrings.push(Locale.compose(unitInfo.Description));
            }
        }
    }
    // Target is a TRADITION
    else if (targetKind == "KIND_TRADITION") {
        locStrings = getTraditionDescriptions(targetType);
    }
    // Target is a DIPLOMATIC ACTION
    else if (targetKind == "KIND_DIPLOMATIC_ACTION") {
        const diploActionInfo = GameInfo.DiplomacyActions.find(o => o.DiplomacyActionType == targetType);
        if (diploActionInfo) {
            locStrings.push(Locale.compose(diploActionInfo.Description));
        }
    }
    else if (targetKind == "KIND_PROJECT") {
        const projectInfo = GameInfo.Projects.find(o => o.ProjectType == targetType);
        if (projectInfo) {
            locStrings.push(Locale.compose(projectInfo.Description));
        }
    }
    return locStrings;
}
// Traditions can have 1+ modifiers associated with them, return all modifier descriptions as the Tradition description
export function getTraditionDescriptions(traditionType) {
    let descStrings = [];
    const traditionInfo = GameInfo.Traditions.lookup(traditionType);
    if (traditionInfo) {
        for (let modifier of GameInfo.TraditionModifiers) {
            if (modifier.TraditionType == traditionInfo.TraditionType) {
                const modifierDesc = getModifierTextByContext(modifier.ModifierId, "Description");
                if (modifierDesc) {
                    descStrings.push(modifierDesc);
                }
            }
        }
        // No descriptions from modifiers on this tradition, use the tradition's own description instead
        if (descStrings.length == 0) {
            if (traditionInfo.Description) {
                descStrings.push(Locale.compose(traditionInfo.Description));
            }
        }
    }
    return descStrings;
}
export function getNodeName(nodeData) {
    if (!nodeData) {
        return "";
    }
    const nodeInfo = GameInfo.ProgressionTreeNodes.lookup(nodeData.nodeType);
    if (!nodeInfo) {
        return "";
    }
    let nodeName = Locale.compose(nodeInfo.Name ?? nodeInfo.ProgressionTreeNodeType);
    if (nodeData.depthUnlocked >= 1) {
        let depthNumeral = Locale.toRomanNumeral(nodeData.depthUnlocked + 1);
        if (depthNumeral) {
            nodeName += " " + depthNumeral;
        }
    }
    return nodeName;
}
export function getUnlockDepthPrefix(iCurDepth, iMaxDepth) {
    // If all unlocks are at base depth, no prefix required
    if (iMaxDepth <= 1) {
        return "";
    }
    return (iCurDepth + 1) + "/" + iMaxDepth;
}

//# sourceMappingURL=file:///base-standard/ui/utilities/utilities-textprovider.js.map
