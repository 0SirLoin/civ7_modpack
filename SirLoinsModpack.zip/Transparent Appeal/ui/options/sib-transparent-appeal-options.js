import '/core/ui/options/options.js';  // make sure this loads first
import { CategoryType } from '/core/ui/options/options-helpers.js';
import { Options, OptionType } from '/core/ui/options/model-options.js';
import ModSettings from '/sib-transparent-appeal/ui/options/mod-options-decorator.js';


const MOD_ID = "sib-transparent-appeal";

export var SibTransparentAppealTheme;
(function (SibTransparentAppealTheme) {
    SibTransparentAppealTheme["CIV6"] = "civ6";
    SibTransparentAppealTheme["BASEGAME"] = "base_game";
})(SibTransparentAppealTheme || (SibTransparentAppealTheme = {}));

export const sibTransparentAppealOptions = new class {
    data = {
        theme: SibTransparentAppealTheme.C6,
    };
    constructor() {
        this.changeListeners = [];

        const modSettings = ModSettings.load(MOD_ID);
        if (modSettings)
        {
            this.data = modSettings;
        }
    }
    save() {
        ModSettings.save(MOD_ID, this.data);
        this.changeListeners.forEach(listener => { listener.method?.call(listener?.scope) });
    }
    get AppealTheme() {
        return this.data.theme;
    }
    set AppealTheme(value)
    {
        this.data.theme = value;
        this.save();
    }
    addChangeListener(method, scope)
    {
        this.changeListeners.push({ method: method, scope: scope });
    }
};


const onInitAppealTheme = (info) => {
    if (!info.dropdownItems)
        return;
    for (let i = 0; i < info.dropdownItems.length; i++) {
        const item = info.dropdownItems[i];
        if (item.value == sibTransparentAppealOptions.AppealTheme) {
            info.selectedItemIndex = i;
            break;
        }
    }
}
const onUpdateAppealTheme = (info, selectedIndex) => {
    const selectedItem = info.dropdownItems[selectedIndex];
    sibTransparentAppealOptions.AppealTheme = selectedItem.value;
}
const themeOptions = [
    { label: 'LOC_OPTIONS_SIB_TA_THEME_CIV6_LABEL', value: SibTransparentAppealTheme.CIV6 },
    { label: 'LOC_OPTIONS_SIB_TA_THEME_BASEGAME_LABEL', value: SibTransparentAppealTheme.BASEGAME },
]
Options.addInitCallback(() => {
    Options.addOption({
        category: CategoryType.Mods,
        // @ts-ignore
        group: "sib_mods",
        type: OptionType.Dropdown,
        id: "sib-transparent-appeal-theme",
        initListener: onInitAppealTheme,
        updateListener: onUpdateAppealTheme,
        label: "LOC_OPTIONS_SIB_TA_DROPDOWN_LABEL",
        description: "LOC_OPTIONS_SIB_TA_DROPDOWN_DESCRIPTION",
		dropdownItems: themeOptions
    });
});

export { sibTransparentAppealOptions as default };