// Class to track which wonders have been completed

import { Icon } from '/core/ui/utilities/utilities-image.js';

export class WonderTracker
{
    constructor() {
        this._wonderModel = null;
        this.completedWonders = [];
        this.completedWondersIcons = [];
        this.wonderCompletedListener = this.onWonderCompleted.bind(this);
    }
    /**
     * Singleton accessor
     */
    static getInstance() {
        if (!WonderTracker._Instance) {
            WonderTracker._Instance = new WonderTracker();
        }
        return WonderTracker._Instance;
    }

    Initialize()
    {
        if (!this._wonderModel)
        {
            console.log(`claimed-wonders-notation: WonderTracker::Initialize - Noting all completed wonders`);
            const width = GameplayMap.getGridWidth();
            const height = GameplayMap.getGridHeight();
            for (let x = 0; x < width; x++) {
                for (let y = 0; y < height; y++) {
                    let wonder = this.HasWonder(x, y);
                    if (wonder != null)
                    {
                        console.log(`claimed-wonders-notation: WonderTracker::Initialize Wonder at (${x}, ${y}) => ${wonder.info.ConstructibleType}`);
                        this.completedWonders.push(wonder.info.ConstructibleType);
                        let icon = Icon.getConstructibleIconFromDefinition(wonder.info);
                        this.completedWondersIcons.push(icon);
                    }
                }
            }

            engine.on("WonderCompleted", this.wonderCompletedListener, this);
        }
        else
        {
            console.log(`claimed-wonders-notation: WonderTracker::Initialize - Using wonder-screen's model for data.`);
        }
    }

    onWonderCompleted(data) {
        const wonder = GameInfo.Wonders.lookup(data.constructibleType);
        console.log(`claimed-wonders-notation: WonderTracker::onWonderCompleted Noting wonder completion: ${JSON.stringify(wonder.ConstructibleType)}`);
        this.completedWonders.push(wonder.ConstructibleType);

        let constructibleDef = GameInfo.Constructibles.lookup(data.constructibleType);
        let icon = Icon.getConstructibleIconFromDefinition(constructibleDef);
        this.completedWondersIcons.push(icon);
    }

    IsCompletedIcon(wonderIcon)
    {
        if (this._wonderModel)
        {
            const data = this._wonderModel.wonderData;
            for (const w of data)
            {
                if (w.icon == wonderIcon)
                {
                    return w.completed;
                }
            }
            return false;
        }
        else
        {
            return this.completedWondersIcons.includes(wonderIcon);
        }
    }

    IsCompletedIconUrl(wonderIconUrl)
    {
        let strSplit = wonderIconUrl.split(/[\(\)]/);
        return strSplit.length == 3 && this.IsCompletedIcon(strSplit[1]);
    }

    IsConstructingIcon(wonderIcon)
    {
        // Constructing information only available with wonders screen mod's data model
        if (!this._wonderModel)
        {
            return false;
        }

        
        const data = this._wonderModel.wonderData;
        for (const w of data)
        {
            if (w.icon == wonderIcon)
            {
                return w.isNonPlayerConstructing;
            }
        }
        return false;
    }

    IsConstructingIconUrl(wonderIconUrl)
    {
        let strSplit = wonderIconUrl.split(/[\(\)]/);
        return strSplit.length == 3 && this.IsConstructingIcon(strSplit[1]);
    }
    
    HasWonder(x, y)
    {
        const constructibles = MapConstructibles.getConstructibles(x, y);
        for (let i = 0; i < constructibles.length; i++) {
            const constructibleID = constructibles[i];
            const existingConstructible = Constructibles.getByComponentID(constructibleID);
    
            let constructibleDef = GameInfo.Constructibles.lookup(existingConstructible.type);
            if (constructibleDef != null && constructibleDef.ConstructibleClass == "WONDER" && existingConstructible.complete) {
                return {constructible: existingConstructible, info: constructibleDef};
            }
        }
    
        return null;
    }

    AttachToGame(wonderModel = null)
    {
        this._wonderModel = wonderModel;
        this.Initialize();
    }
}

export const WonderTrackerInstance = WonderTracker.getInstance();

engine.whenReady.then(() => {
    import('/wonders-screen/code/wonders-screen-model.js').then(module => {
        if (module.default._version && module.default._version >= 2)
        {
            WonderTrackerInstance.AttachToGame(module.default);
        }
        else
        {
            WonderTrackerInstance.AttachToGame();
        }
    }).catch((_err) => {
        WonderTrackerInstance.AttachToGame();
    });
});