import { enhancedDiploBannersSettings } from 'fs://game/enhanced-diplomacy-banners/ui/settings/settings.js';

// Export the settings to the global scope
window.edpSettings = {
    edpSettings: enhancedDiploBannersSettings
};
