import { DebugUtils } from '/scripts/debug-utils.js';
export class ProductionTracker {
    static instance = null;
    constructor() {
        if (ProductionTracker.instance) {
            return ProductionTracker.instance;
        }
        this.completedProductions = new Map();
        this.cityProductionCompletedListener = (data) => this.onCityProductionCompleted(data);
        ProductionTracker.instance = this;
    }

    static getInstance() {
        return this.instance ?? new ProductionTracker();
    }

    attachToGame() {
        engine.on('CityProductionCompleted', this.cityProductionCompletedListener);
    }

    getCompletedProductionForCity(cityId) {
        return this.completedProductions.get(cityId) ?? null;
    }

    getCompletedProductionForCityTest() {
        return {
            productionItem: "TEST_ITEM",
            productionKind: "BUILDING",
            productionName: Locale.compose("LOC_BUILDING_BRICKYARD_NAME"),
            productionIcon: "BUILDING_BRICKYARD",
            turn: Game.turn
        };
    }

    onCityProductionCompleted(data) {
        if (data?.cityID?.owner === GameContext.localPlayerID && !data?.canceled) {
            const lookupTable = {
                [ProductionKind.UNIT]: GameInfo.Units,
                [ProductionKind.PROJECT]: GameInfo.Projects,
                [ProductionKind.CONSTRUCTIBLE]: GameInfo.Constructibles
            };
            const definition = lookupTable[data?.productionKind]?.lookup(data?.productionItem);
            var obj = {
                productionItem: data?.productionItem,
                productionKind: data?.productionKind,
                productionName: definition.Name,
                productionIcon: definition.ConstructibleType || definition.UnitType || definition.ProjectType
            };
            this.completedProductions.set(data?.cityID?.id, obj);
        }
    }
}

export const ProductionTrackerInstance = ProductionTracker.getInstance();

engine.whenReady.then(() => {
    ProductionTrackerInstance.attachToGame();
});