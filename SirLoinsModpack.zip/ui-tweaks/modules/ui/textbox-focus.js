import '/core/ui/components/fxs-textbox.js';

const definition = Controls.getDefinition('fxs-textbox');
definition.styles ??= [];
definition.styles.push('fs://game/bobobunicorn-ui-tweaks/modules/ui/textbox-focus.css')

