# What does this mod do?
- You need 40 yields for research milestone, so this mod tells you how many specialists you need to reach that and 
if it can be reached with this tile. 
- The tooltip will be updated when you select the "+" to growth your city that can have specialists

# How to use
Simply copy the extracted directory into:
- Windows: `%localappdata%\Firaxis Games\Sid Meier's Civilization VII\Mods`
- MacOS: `~/Library/Application Support/Civilization VII/Mods`
- Steam Deck\Linux: `~/My Games/Sid Meier's Civilization VII/Mods/`

## Compatability issues
If you have compatibility issues with other mods, check if they modify `ui/tooltips/plot-tooltip.js`, do this to fix it: 
  - Add import `import ModExtension from '/mod/mod-extension.js';` to that modified `plot-tooltip.js` from the other mod
  - Add line `ModExtension.invokeAction("plot-tooltip-yields-flexbox", this);` after `this.addPlotYields` is called.
  - In this mod `WolfsSpecialistHelper.modinfo` file comment the line that imports the `plot-tooltip.js` from my project
    - Add these in front `<!--` and after `-->` to comment that line should look like this afterwords: `<!--<Item>ui/tooltips/plot-tooltip.js</Item>-->`
  - Launch the game and activate my mod first, activate other mod second, should work.

# Language Support
de_De and en_US see text directory
