
import '/core/ui/options/options.js';  // make sure this loads first
import { CategoryType } from '/core/ui/options/options-helpers.js';
import { Options, OptionType } from '/core/ui/options/model-options.js';
import ModSettings from '/sib-transparent-appeal/ui/options/mod-options-decorator.js';

const MOD_ID = "sib-transparent-appeal";

export var sibTransparentAppealTheme;
(function (sibTransparentAppealTheme) {
    sibTransparentAppealTheme["CIV6"] = "civ6";
    sibTransparentAppealTheme["BASEGAME"] = "base_game";
})(sibTransparentAppealTheme || (sibTransparentAppealTheme = {}));

const themeOptions = [
    { label: 'LOC_OPTIONS_SIB_TA_THEME_CIV6_LABEL', value: sibTransparentAppealTheme.CIV6 },
    { label: 'LOC_OPTIONS_SIB_TA_THEME_BASEGAME_LABEL', value: sibTransparentAppealTheme.BASEGAME },
];

const SIB_TA_DEFAULT_OPTIONS = {
    theme: sibTransparentAppealTheme.CIV6,
    showResources: true,
	showWonders: true,
	showVolcanoes: true,
	showNavigableRivers: true,
};

const sibTransparentAppealOptions = new function() {
    var self = this;

    self.data = ModSettings.load(MOD_ID) || { ...SIB_TA_DEFAULT_OPTIONS };

    self.save = function() {
        ModSettings.save(MOD_ID, self.data);
    };

    Object.defineProperty(self, 'theme', {
		get: function() {
			var value = self.data.theme;

			// Handle legacy true/false
			if (value === true) return sibTransparentAppealTheme.CIV6;
			if (value === false) return sibTransparentAppealTheme.BASEGAME;

			// Handle legacy 0/1 index values
			if (typeof value === "number" && themeOptions[value]) {
				return themeOptions[value].value;
			}

			// Use value as-is or fallback to default
			return value != null ? value : SIB_TA_DEFAULT_OPTIONS.theme;
		},
		set: function(value) {
			// Convert index (from dropdown) to value
			if (typeof value === "number" && themeOptions[value]) {
				self.data.theme = themeOptions[value].value;
			} else {
				self.data.theme = value;
			}
			self.save();
		}
	});

    // Checkbox options
    var checkboxKeys = ['showResources', 'showWonders', 'showVolcanoes', 'showNavigableRivers'];

    for (var i = 0; i < checkboxKeys.length; i++) {
        (function(key) {
            Object.defineProperty(self, key, {
                get: function() {
                    var val = self.data[key];
                    return val != null ? val : SIB_TA_DEFAULT_OPTIONS[key];
                },
                set: function(flag) {
                    self.data[key] = !!flag;
                    self.save();
                }
            });
        })(checkboxKeys[i]);
    }
};

//Checkbox and dropdown handlers
function createInitCheckboxHandler(key) {
    return function(info) {
        info.currentValue = sibTransparentAppealOptions[key];
    };
}

function createUpdateCheckboxHandler(key) {
    return function(_info, flag) {
        sibTransparentAppealOptions[key] = flag;
    };
}


function createInitDropdownHandler(key) {
    return function(info) {
        var value = sibTransparentAppealOptions[key]; 
        var index = 0;
        for (var i = 0; i < themeOptions.length; i++) { //Convert index to string
            if (themeOptions[i].value === value) {
                index = i;
                break;
            }
        }
        info.selectedItemIndex = index;
    };
}

function createUpdateDropdownHandler(key) {
    return function(_info, value) {
        sibTransparentAppealOptions[key] = value;
    };
}

//Generate localization key
function toLocalizationKey(id, suffix) {
    // 'sib-transparent-appeal-show-volcanoes' becomes 'LOC_OPTIONS_SIB_TA_SHOW_VOLCANOES_LABEL/DESCRIPTION'
    return "LOC_OPTIONS_" + id
        .replace("sib-transparent-appeal-", "SIB_TA_")
        .toUpperCase()
        .replace(/-/g, "_") + "_" + suffix;
}

//Create dropdown options
function addDropdownOption(id, key, dropdownItems) {
    Options.addOption({
        category: CategoryType.Mods,
        group: "sib_mods",
        type: OptionType.Dropdown,
        id: id,
        initListener: createInitDropdownHandler(key),
        updateListener: createUpdateDropdownHandler(key),
        label: toLocalizationKey(id, "LABEL"),
        description: toLocalizationKey(id, "DESCRIPTION"),
        dropdownItems: dropdownItems
    });
}

//Create checkbox options
function addCheckboxOption(id, key) {
    Options.addOption({
        category: CategoryType.Mods,
        group: "sib_mods",
        type: OptionType.Checkbox,
        id: id,
        initListener: createInitCheckboxHandler(key),
        updateListener: createUpdateCheckboxHandler(key),
        label: toLocalizationKey(id, "LABEL"),
        description: toLocalizationKey(id, "DESCRIPTION")
    });
}

Options.addInitCallback(function() {
    addDropdownOption(
        "sib-transparent-appeal-theme",
        "theme",
        themeOptions
    );

    addCheckboxOption("sib-transparent-appeal-show-resources", "showResources");
    addCheckboxOption("sib-transparent-appeal-show-wonders", "showWonders");
    addCheckboxOption("sib-transparent-appeal-show-volcanoes", "showVolcanoes");
	addCheckboxOption("sib-transparent-appeal-show-navigable-rivers", "showNavigableRivers");
});

export { sibTransparentAppealOptions as default };