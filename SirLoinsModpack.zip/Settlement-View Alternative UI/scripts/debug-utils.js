﻿export class DebugUtils {
    static inspectObject(obj, label = "Object") {
        console.warn(`NASUDEBUG: ! ------------------ inspectObject BEGINNING ------------------ !`);
        if (!obj) {
            console.warn(`NASUDEBUG: ${label} is null or undefined`);
            return;
        }

        console.warn(`NASUDEBUG: ${label} exists, type:`, typeof obj);

        const ownProps = Object.getOwnPropertyNames(obj);
        console.warn(`NASUDEBUG: ${label} own properties count:`, ownProps.length);
        if (ownProps.length > 0) {
            ownProps.forEach(prop => {
                const value = obj[prop];
                const valueType = typeof value;
                const paramCount = valueType === 'function' ? `(${value.length} params)` : '';
                console.warn(`NASUDEBUG: ${label} own property: ${prop} (${valueType}${paramCount})`, value);
            });
        } else {
            console.warn(`NASUDEBUG: No own properties found in ${label}`);
        }

        const proto = Object.getPrototypeOf(obj);
        if (proto) {
            const protoProps = Object.getOwnPropertyNames(proto);
            console.warn(`NASUDEBUG: ${label} prototype properties count:`, protoProps.length);
            if (protoProps.length > 0) {
                protoProps.forEach(prop => {
                    const value = proto[prop];
                    const valueType = typeof value;
                    const paramCount = valueType === 'function' ? `(${value.length} params)` : '';
                    console.warn(`NASUDEBUG: ${label} proto property: ${prop} (${valueType}${paramCount})`, value);
                });
            } else {
                console.warn(`NASUDEBUG: No prototype properties found in ${label}`);
            }
        } else {
            console.warn(`NASUDEBUG: ${label} has no prototype`);
        }
        console.warn(`NASUDEBUG: ! ------------------ inspectObject END ------------------ !`);
    }
}