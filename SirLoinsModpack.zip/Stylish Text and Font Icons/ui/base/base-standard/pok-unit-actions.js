const style = document.createElement('style');
style.textContent = `
.unit-actions__hit-points-icon {
    display: flex;
    width: pixels(28);
    height: pixels(28);
    background-image: url("blp:chat_heart") !important;
    background-size: contain;
    background-repeat: no-repeat;
}
`;
document.head.appendChild(style);