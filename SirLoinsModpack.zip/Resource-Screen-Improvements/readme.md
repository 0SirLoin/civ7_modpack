Adds a sort function to the Trade Panel, so you can filter by the number of a specific resource.
It does a secondary filter on number of generic resources, similar to the default sort 

Now go, get those fifty Tea resources, you magnificent beast, you.

version 1.22