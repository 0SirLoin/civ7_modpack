// Class to track which wonders have been completed

import { Icon } from '/core/ui/utilities/utilities-image.js';

export class WonderTracker
{
    constructor() {
        this.completedWonders = [];
        this.completedWondersIcons = [];
        this.wonderCompletedListener = this.onWonderCompleted.bind(this);
    }
    /**
     * Singleton accessor
     */
    static getInstance() {
        if (!WonderTracker._Instance) {
            WonderTracker._Instance = new WonderTracker();
        }
        return WonderTracker._Instance;
    }

    Initialize()
    {
        console.log(`claimed-wonders-notation: WonderTracker::Initialize - Noting all completed wonders`)
        const width = GameplayMap.getGridWidth();
        const height = GameplayMap.getGridHeight();
        for (let x = 0; x < width; x++) {
            for (let y = 0; y < height; y++) {
                let wonder = this.HasWonder(x, y);
                if (wonder != null)
                {
                    console.log(`claimed-wonders-notation: WonderTracker::Initialize Wonder at (${x}, ${y}) => ${wonder.info.ConstructibleType}`);
                    this.completedWonders.push(wonder.info.ConstructibleType);
                    let icon = Icon.getConstructibleIconFromDefinition(wonder.info);
                    this.completedWondersIcons.push(icon);
                }
            }
        }

        engine.on("WonderCompleted", this.wonderCompletedListener, this);
    }

    onWonderCompleted(data) {
        const wonder = GameInfo.Wonders.lookup(data.constructibleType);
        console.log(`claimed-wonders-notation: WonderTracker::onWonderCompleted Noting wonder completion: ${JSON.stringify(wonder.ConstructibleType)}`);
        this.completedWonders.push(wonder.ConstructibleType);

        let constructibleDef = GameInfo.Constructibles.lookup(data.constructibleType);
        let icon = Icon.getConstructibleIconFromDefinition(constructibleDef);
        this.completedWondersIcons.push(icon);
    }

    IsCompleted(wonderType)
    {
        return this.completedWonders.includes(wonderType);
    }

    IsCompletedIcon(wonderIcon)
    {
        return this.completedWondersIcons.includes(wonderIcon);
    }

    IsCompletedIconUrl(wonderIconUrl)
    {
        let strSplit = wonderIconUrl.split(/[\(\)]/);
        return strSplit.length == 3 && this.IsCompletedIcon(strSplit[1]);
    }
    
    HasWonder(x, y)
    {
        const constructibles = MapConstructibles.getConstructibles(x, y);
        for (let i = 0; i < constructibles.length; i++) {
            const constructibleID = constructibles[i];
            const existingConstructible = Constructibles.getByComponentID(constructibleID);
    
            let constructibleDef = GameInfo.Constructibles.lookup(existingConstructible.type);
            if (constructibleDef != null && constructibleDef.ConstructibleClass == "WONDER" && existingConstructible.complete) {
                return {constructible: existingConstructible, info: constructibleDef};
            }
        }
    
        return null;
    }

    AttachToGame()
    {
        this.Initialize();
    }
}

export const WonderTrackerInstance = WonderTracker.getInstance();

engine.whenReady.then(() => {
    WonderTrackerInstance.AttachToGame();
});