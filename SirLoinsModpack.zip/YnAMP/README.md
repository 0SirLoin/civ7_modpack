# Civ7-YnAMP
YnAMP for Civilization 7
