--=============================================================================================================
-- Better Text and Font Icons
-- Change some key words for consistency
--=============================================================================================================
-- CHARGE
---------------------------------------------------------------------------------------------------------------
-- Capitalize to reflect that it is a key word
---------------------------------------------------------------------------------------------------------------
UPDATE 	LocalizedText
SET 	Text = replace(Text, " charge", " Charge")
WHERE	(Tag LIKE 		'%DESCRIPTION%'								
OR		Tag LIKE 		'%REWARD%'
OR		Tag LIKE 		'%TOOLTIP%')
-- Exceptions for edge cases where the UI doesn't render font icons
AND		Tag NOT LIKE 	'LOC_TRADE_LENS%%' 		-- Trade Route UI text
AND		Tag NOT LIKE 	'%PLOT_TOOLTIP%' 		-- Settler UI text
AND		Tag NOT LIKE 	'LOC_ABILITY%'			-- Bombard Preview UI text
AND    	Language = 'en_US';
---------------------------------------------------------------------------------------------------------------
-- TECHNOLOGIES
---------------------------------------------------------------------------------------------------------------
-- Replace "Tech" with "Technology"
-- "Tech" is irregularly used and doesn't look good 
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Tech ", "Technology ")
WHERE	Text NOT LIKE	"Technology"
AND    	Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "Techs ", "Technologies ")
WHERE	Text NOT LIKE	"Technology"
AND    	Language = 'en_US';

-- For edge cases where "Tech" ends a sentence
UPDATE 	LocalizedText
SET 	Text = replace(Text, "Tech.", "Technology.")
WHERE	Text NOT LIKE	"Technology"
AND    	Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "Techs.", "Technologies.")
WHERE	Text NOT LIKE	"Technology"
AND    	Language = 'en_US';
