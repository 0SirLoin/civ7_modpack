﻿import LensManager from '/core/ui/lenses/lens-manager.js';

class AutoYieldIconsMod {
    constructor() {
        this.init();
    }

    init() {
        console.warn("MOD: AutoYieldIcons initialized!");
        engine.on('GameStarted', this.onGameStarted.bind(this));
    }

    onGameStarted() {
        console.warn("Game has started!");
        // 産出アイコン (yields-layer) をオンにする
        this.enableYieldsLayer();
        // **MODの処理が完了したらインスタンスを削除**
        this.cleanup();
    }

    enableYieldsLayer() {
        console.warn("Displaying yield icons...");
        LensManager.toggleLayer('fxs-yields-layer');
    }

    cleanup() {
        console.warn("MOD process completed. Destroying instance...");
        engine.off('GameStarted', this.onGameStarted.bind(this));
        delete window.AutoYieldIconsMod;
    }
}

// **インスタンスを作成**
window.AutoYieldIconsMod = new AutoYieldIconsMod();
