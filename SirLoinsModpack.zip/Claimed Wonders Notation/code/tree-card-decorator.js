/**
 * Decorate the tree-card control per https://forums.civfanatics.com/threads/additive-ui-elements.695406/
 */
// force import of tree-card so we can update its control styles
import '/base-standard/ui/tree-grid/tree-card.js';

import { WonderTrackerInstance } from '/claimed-wonders-notation/code/wonder-tracker.js';

export class TechWonder_TreeCardItemDecorator {
    constructor(val) {
        this._item = val;
        this._item._wonderDecorator = this;
    }

    beforeAttach() {
    }

    afterAttach() {
        // Unlock items are added after creation in the updateUnlockData function
        // Patch that function so we can update the elements after its created
        if (!TechWonder_TreeCardItemDecorator.Patched)
        {
            const objPrototype = Object.getPrototypeOf(this._item);
            const prevFunction = objPrototype.updateUnlockData;
            const ourFunction = this.updateUnlockData;

            objPrototype.updateUnlockData = function (...args) {
                // Call the original function
                prevFunction.apply(this, args);
                return ourFunction.apply(this._wonderDecorator, args);
            };

            TechWonder_TreeCardItemDecorator.Patched = true;
        }
    }

    updateUnlockData()
    {
        // Find all icon elements with a background image that is a completed wonder
        let unlocks = this._item.Root.getElementsByClassName('unlock-item');
        for (let e of unlocks)
        {
            let src = e.style.backgroundImage;
            if (WonderTrackerInstance.IsCompletedIconUrl(src))
            {
                e.classList.add('completed-wonder-icon');
            }
            else if (WonderTrackerInstance.IsConstructingIconUrl(src))
            {
                e.classList.add('constructing-wonder-icon');
            }
        }
    }

    beforeDetach() { }

    afterDetach() { }

    onAttributeChanged(name, prev, next) { }
}
TechWonder_TreeCardItemDecorator.Patched = false;

Controls.decorate('tree-card', (val) => new TechWonder_TreeCardItemDecorator(val));

if (!Controls.getDefinition('tree-card').hasOwnProperty('styles'))
{
    Controls.getDefinition('tree-card').styles = [];
}
Controls.getDefinition('tree-card').styles.push("fs://game/claimed-wonders-notation/data/wonder-icon.css");