--=============================================================================================================
-- Better Text and Font Icons
-- Add points and spacing for Trait lists
--=============================================================================================================
UPDATE 	LocalizedText
SET 	Text = replace(Text, "[LIST]", "[BLIST]")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND    	Language = 'en_US';

UPDATE 	LocalizedText
SET 	Text = replace(Text, "[LI]", "[LI] ")
WHERE 	Tag LIKE 'LOC_TRAIT_%'
AND    	Language = 'en_US';